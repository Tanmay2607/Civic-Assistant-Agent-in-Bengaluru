"""Defines the Traffic Management Agent logic without ADK dependency."""

import json
import logging
from datetime import datetime, timezone

from gcp_clients import (
    get_bigquery_client,
    get_maps_client,
    get_pubsub_publisher_client,
    GCP_PROJECT_ID,
)

# Constants
VEHICLE_COUNT_THRESHOLD = 100
BIGQUERY_DATASET = "traffic_data"
BIGQUERY_TABLE = "traffic_logs"
OUTPUT_TOPIC = "traffic-incidents"

# Configure logging
logging.basicConfig(level=logging.INFO)


class TrafficAgent:
    """Agent to process traffic data, identify incidents, and take action."""

    def parse_and_validate_message(self, message_data: str) -> dict:
        """Parses and validates the incoming JSON message."""
        logging.info("State: ANALYZING")
        try:
            data = json.loads(message_data)
            # Basic validation
            if not all(k in data for k in ["location", "vehicle_count", "timestamp"]):
                raise ValueError("Missing required fields in message.")
            if not all(k in data["location"] for k in ["latitude", "longitude"]):
                raise ValueError("Missing location fields.")
            logging.info("Message parsed and validated successfully.")
            return data
        except (json.JSONDecodeError, ValueError) as e:
            logging.error(f"Message validation failed: {e}")
            raise

    def reverse_geocode_location(self, latitude: float, longitude: float) -> str:
        """Converts latitude/longitude to a human-readable address."""
        logging.info("State: ENRICHING")
        maps = get_maps_client()
        if not maps:
            raise ConnectionError("Google Maps client not initialized.")
        try:
            geocode_result = maps.reverse_geocode((latitude, longitude))
            if geocode_result:
                address = geocode_result[0]["formatted_address"]
                logging.info(f"Geocoded address: {address}")
                return address
            return "Unknown Address"
        except Exception as e:
            logging.error(f"Reverse geocoding failed: {e}")
            return "Geocoding Failed"

    def analyze_traffic_data(self, vehicle_count: int) -> str | None:
        """Analyzes traffic data to identify high congestion."""
        if vehicle_count > VEHICLE_COUNT_THRESHOLD:
            logging.info(f"High congestion detected: {vehicle_count} vehicles.")
            logging.info("State: ACTION_REQUIRED")
            return "High Congestion"
        logging.info("Traffic levels are normal.")
        return None

    def publish_incident_to_pubsub(self, incident_payload: dict):
        """Publishes a traffic incident to the output Pub/Sub topic."""
        publisher = get_pubsub_publisher_client()
        if not publisher:
            raise ConnectionError("Pub/Sub client not initialized.")
        topic_path = publisher.topic_path(GCP_PROJECT_ID, OUTPUT_TOPIC)
        try:
            future = publisher.publish(topic_path, json.dumps(incident_payload).encode("utf-8"))
            message_id = future.result()
            logging.info(f"Published incident message {message_id} to {topic_path}.")
        except Exception as e:
            logging.error(f"Failed to publish incident: {e}")
            raise

    def log_to_bigquery(self, enriched_data: dict):
        """Logs the enriched traffic data to BigQuery."""
        bigquery = get_bigquery_client()
        if not bigquery:
            raise ConnectionError("BigQuery client not initialized.")
        table_id = f"{GCP_PROJECT_ID}.{BIGQUERY_DATASET}.{BIGQUERY_TABLE}"
        try:
            errors = bigquery.insert_rows_json(table_id, [enriched_data])
            if not errors:
                logging.info(f"Successfully logged data to BigQuery table {table_id}.")
            else:
                logging.error(f"BigQuery insertion errors: {errors}")
        except Exception as e:
            logging.error(f"Failed to log data to BigQuery: {e}")
            raise

    def process(self, message_data: str):
        """Main processing logic for the agent."""
        logging.info("State: RECEIVED")
        try:
            # 1. Parse and Validate
            parsed_data = self.parse_and_validate_message(message_data)

            # 2. Enrich with Address
            address = self.reverse_geocode_location(
                latitude=parsed_data["location"]["latitude"],
                longitude=parsed_data["location"]["longitude"],
            )
            enriched_data = {**parsed_data, "address": address, "processing_timestamp": datetime.now(timezone.utc).isoformat()}

            # 3. Log to BigQuery
            self.log_to_bigquery(enriched_data)

            # 4. Analyze for Incidents
            event_type = self.analyze_traffic_data(vehicle_count=parsed_data["vehicle_count"])

            # 5. Take Action if Needed
            if event_type:
                incident_payload = {
                    **enriched_data,
                    "event_type": event_type,
                }
                self.publish_incident_to_pubsub(incident_payload)

            logging.info("State: COMPLETED")
            logging.info("Agent processing completed successfully.")

        except Exception as e:
            logging.error(f"Agent processing failed: {e}")
            logging.info("State: ERROR")


# Instantiate the agent
traffic_agent = TrafficAgent()
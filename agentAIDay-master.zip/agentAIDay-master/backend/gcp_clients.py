"""Initializes and encapsulates Google Cloud clients."""

import os
import googlemaps
from google.cloud import pubsub_v1, bigquery
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Environment variables
GCP_PROJECT_ID = os.getenv("GCP_PROJECT_ID")
GOOGLE_MAPS_API_KEY = os.getenv("GOOGLE_MAPS_API_KEY")

# Log the project ID to confirm it's loaded
print(f"Attempting to use GCP Project ID: {GCP_PROJECT_ID}")

import traceback

# Initialize clients
try:
    pubsub_publisher_client = pubsub_v1.PublisherClient()
except Exception as e:
    print(f"Error initializing Pub/Sub publisher client: {e}")
    traceback.print_exc()
    pubsub_publisher_client = None

bigquery_client = None

try:
    maps_client = googlemaps.Client(key=GOOGLE_MAPS_API_KEY)
except Exception as e:
    print(f"Error initializing Google Maps client: {e}")
    traceback.print_exc()
    maps_client = None

def get_pubsub_publisher_client():
    """Returns the Pub/Sub publisher client."""
    return pubsub_publisher_client

def get_bigquery_client():
    """Initializes and returns the BigQuery client."""
    global bigquery_client
    if bigquery_client is None:
        try:
            bigquery_client = bigquery.Client(project=GCP_PROJECT_ID)
        except Exception as e:
            print(f"Error initializing BigQuery client: {e}")
    return bigquery_client

def get_maps_client():
    """Returns the Google Maps client."""
    return maps_client
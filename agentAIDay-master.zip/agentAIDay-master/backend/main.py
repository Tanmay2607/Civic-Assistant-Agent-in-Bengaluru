from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from pydantic import BaseModel

class TravelPlanRequest(BaseModel):
    origin: str
    destination: str

@app.post("/travel-plan")
def generate_route_explanation(destination, route, traffic_conditions, selected_route_reason):
    """Generate concise AI explanation for route selection"""
    return f"Selected optimal route to {destination}. {selected_route_reason}. Current traffic: {traffic_conditions}. ETA optimized based on real-time data."

@app.post("/travel-plan")
async def get_travel_plan(request: TravelPlanRequest):
    print("Received travel plan request:", request)
    # Your existing route calculation
    # route_data = calculate_route(request.destination)
    
    # Generate AI insights using Gemini/Vertex AI
    ai_insights = generate_route_explanation(
        destination=request.destination,
        route={},
        traffic_conditions="moderate",
        selected_route_reason="Fastest route considering current traffic patterns"
    )
    
    return {
        "origin": request.origin,
        "destination": request.destination,
        "insights": ai_insights,  # Include AI reasoning
        "estimated_time": "25 minutes",
        "distance": "10 miles"
    }

@app.get("/")
def read_root():
    return {"message": "Traffic Management Agent API is running."}
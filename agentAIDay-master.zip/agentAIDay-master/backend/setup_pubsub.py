from google.cloud import pubsub_v1
from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

# Get project ID from environment
project_id = os.getenv("GCP_PROJECT_ID")
topic_id = "traffic-incidents"

publisher = pubsub_v1.PublisherClient()
topic_path = publisher.topic_path(project_id, topic_id)

try:
    topic = publisher.create_topic(request={"name": topic_path})
    print(f"Topic created: {topic.name}")
except Exception as e:
    print(e)
import requests, re
import googlemaps
import google.generativeai as genai
from typing import Optional

# Init APIs
gmaps = googlemaps.Client(key=GOOGLE_MAPS_API_KEY)
genai.configure(api_key=GEMINI_API_KEY)

def get_weather(lat, lon):
    url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={OPENWEATHER_API_KEY}&units=metric"
    res = requests.get(url).json()
    desc = res['weather'][0]['description'].capitalize()
    rain = res.get('rain', {}).get('1h', 0)
    vis = res.get('visibility', 'unknown')
    wind = res['wind']['speed']
    return f"{desc}, Rain: {rain} mm/h, Visibility: {vis} m, Wind: {wind} m/s"

def get_route_and_traffic(origin, destination):
    directions = gmaps.directions(
        origin, destination, mode="driving", departure_time="now", traffic_model="best_guess"
    )[0]
    summary = directions['summary']
    normal = directions['legs'][0]['duration']['text']
    traffic = directions['legs'][0].get('duration_in_traffic', {}).get('text', normal)
    return summary, normal, traffic


model = genai.GenerativeModel("gemini-2.5-pro")

user_input = "Is it safe to go from Bellandur to madavara right now?"

extract_prompt = f"""
Extract the origin and destination from the sentence below.

Sentence: "{user_input}"

Respond only in the format:
origin: <starting point>
destination: <ending point>
"""

extract_response = model.generate_content(extract_prompt)
print(extract_response.text)

origin = re.search(r'origin:\s*(.+)', extract_response.text, re.IGNORECASE).group(1).strip()
destination = re.search(r'destination:\s*(.+)', extract_response.text, re.IGNORECASE).group(1).strip()

model = genai.GenerativeModel("gemini-2.5-pro")

user_input = "Is it safe to go from Bellandur to madavara right now?"

extract_prompt = f"""
Extract the origin and destination from the sentence below.

Sentence: "{user_input}"

Respond only in the format:
origin: <starting point>
destination: <ending point>
"""

extract_response = model.generate_content(extract_prompt)
print(extract_response.text)

origin = re.search(r'origin:\s*(.+)', extract_response.text, re.IGNORECASE).group(1).strip()
destination = re.search(r'destination:\s*(.+)', extract_response.text, re.IGNORECASE).group(1).strip()

origin_geocode = gmaps.geocode(origin)
print("Origin Geocode Result:", origin_geocode)

# Get weather
geo = gmaps.geocode(origin)[0]['geometry']['location']
weather = get_weather(geo['lat'], geo['lng'])

# Get route and traffic
summary, normal, traffic = get_route_and_traffic(origin, destination)
traffic_status = f"Normal: {normal}, Traffic: {traffic}"

# Final Gemini prompt
fusion_prompt = f"""
You're a traffic assistant. Analyze the route and give a recommendation.

Location: {origin} → {destination}
Weather: {weather}
Traffic: {traffic_status}
Route Summary: {summary}
User: "Is it safe to go now?"

Respond with:
- Summary of situation
- Is weather affecting traffic?
- Should the user avoid this route?
- Suggest an alternative if needed
"""

response = model.generate_content(fusion_prompt)
print("\n🚦 Gemini Recommendation:\n")
print(response.text)


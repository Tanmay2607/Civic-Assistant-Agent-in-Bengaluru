# Traffic Management Agent - Frontend

This directory contains the frontend code for the AI Traffic Management Agent.

## Setup

1.  **Install dependencies:**
    ```bash
    npm install
    ```

2.  **Add your Google Maps API Key:**
    Open `src/App.js` and replace `"YOUR_GOOGLE_MAPS_API_KEY"` with your actual Google Maps API key.

3.  **Run the server:**
    ```bash
    npm start
    ```

The application will be available at `http://localhost:3000`.

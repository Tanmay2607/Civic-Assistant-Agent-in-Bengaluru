import React, { useState } from 'react';
import { GoogleMap, useJsApiLoader, DirectionsRenderer, Marker } from '@react-google-maps/api';
import DeckGL from '@deck.gl/react';
import { ScatterplotLayer } from '@deck.gl/layers';
import './App.css';
import './Dashboard.css';

const containerStyle = {
  width: '100%',
  height: '100%'
};

const center = {
  lat: 12.9716,
  lng: 77.5946
};

const App = () => {
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: "AIzaSyC-VQzmR1aLxXJsFYtYKZN6yyGr_hIxRic"
  });

  const [data] = useState([]);
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [recommendation, setRecommendation] = useState('');
  const [directions, setDirections] = useState(null);
  const [routeInsights, setRouteInsights] = useState('');

  const handleOriginChange = (event) => {
    setOrigin(event.target.value);
  };

  const handleDestinationChange = (event) => {
    setDestination(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    console.log("Form submitted");
    console.log("Origin:", origin);
    console.log("Destination:", destination);

    if (!origin || !destination) {
      alert("Please enter both origin and destination.");
      return;
    }

    let originCoords = null;
    let destinationCoords = null;
    try {
      const requestData = {
        origin: origin,
        destination: destination
      };
      console.log("Request Data:", requestData);
      const apiUrl = 'http://127.0.0.1:8000/travel-plan';
      console.log('Attempting to fetch from:', apiUrl);
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
      });
      console.log("Response:", response);
      const result = await response.json();
      console.log("Result:", result);
      setRecommendation(result.recommendation);
      setRouteInsights(result.insights || result.reasoning || '');
      
      originCoords = await geocodeOrigin(origin);
      console.log("Destination to be geocoded:", destination);
      destinationCoords = await geocodeDestination(destination);
      
    } catch (error) {
      console.error("Error fetching travel plan:", error);
    } finally {
      if (originCoords && destinationCoords) {
        const directionsService = new window.google.maps.DirectionsService();
        directionsService.route(
          {
            origin: originCoords,
            destination: destinationCoords,
            travelMode: window.google.maps.TravelMode.DRIVING,
          },
          (result, status) => {
            if (status === window.google.maps.DirectionsStatus.OK) {
              console.log("Directions API Result:", result);
              setDirections(result);
            } else {
              console.error("Error fetching directions:", result);
            }
          }
        );
      }
    }
  };

  const geocodeOrigin = async (address) => {
    try {
      const geocoder = new window.google.maps.Geocoder();
      const result = await geocoder.geocode({ address: address });
      if (result.results && result.results.length > 0) {
        const location = result.results[0].geometry.location;
        console.log("Origin Geocoding Result:", location.lat(), location.lng());
        return { lat: location.lat(), lng: location.lng() };
      } else {
        console.error("Geocoding failed for origin:", address);
        return null;
      }
    } catch (error) {
      console.error("Error geocoding origin:", error);
      return null;
    }
  };

  const geocodeDestination = async (address) => {
    try {
      const geocoder = new window.google.maps.Geocoder();
      const result = await geocoder.geocode({ address: address });
      if (result.results && result.results.length > 0) {
        const location = result.results[0].geometry.location;
        console.log("Destination Geocoding Result:", location.lat(), location.lng());
        return { lat: location.lat(), lng: location.lng() };
      } else {
        console.error("Geocoding failed for destination:", address);
        return null;
      }
    } catch (error) {
      console.error("Error geocoding destination:", error);
      return null;
    }
  };


  const layers = [
    new ScatterplotLayer({
      id: 'scatterplot-layer',
      data,
      pickable: true,
      opacity: 0.8,
      stroked: true,
      filled: true,
      radiusScale: 6,
      radiusMinPixels: 1,
      radiusMaxPixels: 100,
      lineWidthMinPixels: 1,
      getPosition: d => [d.location.longitude, d.location.latitude],
      getFillColor: d => [255, 140, 0],
      getLineColor: d => [0, 0, 0]
    })
  ];

  return isLoaded ? (
    <div className="dashboard">
      <div className="sidebar">
        <h2>City Traffic</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Origin"
            value={origin}
            onChange={handleOriginChange}
          />
          <input
            type="text"
            placeholder="Destination"
            value={destination}
            onChange={handleDestinationChange}
          />
          <button type="submit">Get Travel Plan</button>
        </form>
        {recommendation && (
          <div className="recommendation">
            <h3>Travel Plan Recommendation:</h3>
            <p>{recommendation}</p>
          </div>
        )}
      </div>
      <div className="main-content">
        <div className="header">
          <h1>Traffic Management Dashboard</h1>
        </div>
        <div className="content">
          <div className="map-container">
            <GoogleMap
              mapContainerStyle={containerStyle}
              center={center}
              zoom={12}
              options={{
                zoomControl: true,
                streetViewControl: false,
                mapTypeControl: false,
                fullscreenControl: false,
              }}
            >
              <DeckGL
                initialViewState={{
                  longitude: center.lng,
                  latitude: center.lat,
                  zoom: 12,
                  pitch: 0,
                  bearing: 0
                }}
                controller={true}
                layers={layers}
              />
              {directions && <DirectionsRenderer directions={directions} />}
              {directions && (
                <>
                  <Marker position={directions.routes[0].legs[0].start_location} />
                  <Marker position={directions.routes[0].legs[0].end_location} />
                </>
              )}
            </GoogleMap>
          </div>
          <div className="insights-panel" key={routeInsights}>
            <h3>🤖 AI Route Analysis</h3>
            <div style={{ fontSize: '14px', lineHeight: '1.5' }}>
              {routeInsights ? (
                <p>{routeInsights}</p>
              ) : (
                <p><em>Submit a route request to see AI insights...</em></p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  ) : <></>;
}

export default App;

import logging
import requests
import os
from datetime import datetime
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AirQualityAgent:
    def __init__(self):
        logger.info("Initializing Air Quality Agent...")
        self.name = "air_quality_agent"
        
        # Using Google Air Quality API
        self.google_api_key = os.getenv('GOOGLE_MAPS_API_KEY', 'AIzaSyDwtWrBw3YAjEo55GY0jxlhZto8vV3XiAA')
        self.base_url = "https://airquality.googleapis.com/v1"
        
        # Air quality thresholds for different transport modes
        self.aqi_thresholds = {
            'bike': {
                'good': 50,
                'moderate': 100,
                'unhealthy_sensitive': 150,
                'unhealthy': 200,
                'very_unhealthy': 300
            },
            'walking': {
                'good': 100,
                'moderate': 150,
                'unhealthy_sensitive': 200,
                'unhealthy': 250,
                'very_unhealthy': 350
            },
            'car': {
                'good': 150,
                'moderate': 200,
                'unhealthy_sensitive': 300,
                'unhealthy': 400,
                'very_unhealthy': 500
            }
        }
        
        logger.info("✓ Air Quality Agent initialized with Google Air Quality API")
    
    async def get_air_quality_data(self, location, transport_mode='bike'):
        """Get comprehensive air quality data for a location"""
        try:
            logger.info(f"Fetching air quality for {location} (transport: {transport_mode})")
            
            # Get coordinates for the location first (simplified)
            coordinates = self._get_location_coordinates(location)
            
            # Get air quality data
            air_quality_data = await self._fetch_google_air_quality(coordinates, transport_mode)
            
            if air_quality_data:
                logger.info("✓ Air quality data retrieved successfully")
                return air_quality_data
            else:
                logger.info("Falling back to mock air quality data")
                return self._get_mock_air_quality_data(location, transport_mode)
            
        except Exception as e:
            logger.error(f"✗ Failed to get air quality data: {e}")
            return self._get_fallback_air_quality_data(location, transport_mode)
    
    async def get_route_air_quality_analysis(self, origin, destination, route_points, transport_mode='bike'):
        """Analyze air quality along the entire route"""
        try:
            logger.info(f"Analyzing air quality along route: {origin} -> {destination}")
            
            route_analysis = []
            overall_risk_level = 'low'
            
            # Analyze air quality at key points along the route
            for i, point in enumerate([origin] + route_points + [destination]):
                air_quality = await self.get_air_quality_data(point, transport_mode)
                
                segment_analysis = {
                    'segment_id': i + 1,
                    'location': point,
                    'air_quality': air_quality,
                    'health_risk': self._assess_health_risk(air_quality, transport_mode),
                    'recommendations': self._get_segment_recommendations(air_quality, transport_mode)
                }
                
                route_analysis.append(segment_analysis)
                
                # Update overall risk level
                if segment_analysis['health_risk']['risk_level'] == 'high':
                    overall_risk_level = 'high'
                elif segment_analysis['health_risk']['risk_level'] == 'medium' and overall_risk_level != 'high':
                    overall_risk_level = 'medium'
            
            return {
                'route': f"{origin} -> {destination}",
                'transport_mode': transport_mode,
                'route_segments': route_analysis,
                'overall_risk_level': overall_risk_level,
                'route_suitable': overall_risk_level != 'high',
                'alternative_needed': overall_risk_level == 'high',
                'health_recommendations': self._generate_route_health_recommendations(route_analysis, transport_mode),
                'analysis_timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Route air quality analysis failed: {e}")
            return self._get_fallback_route_analysis(origin, destination, transport_mode)
    
    async def suggest_cleaner_routes(self, origin, destination, transport_mode='bike'):
        """Suggest alternative routes with better air quality"""
        try:
            logger.info(f"Finding cleaner routes for {transport_mode} travel")
            
            # Generate alternative route suggestions
            alternatives = []
            
            # Strategy 1: Avoid main roads and highways (usually more polluted)
            alternatives.append({
                'route_name': 'Residential Route',
                'route_type': 'residential_roads',
                'air_quality_benefit': 'Avoids main traffic corridors',
                'estimated_aqi_reduction': '15-25%',
                'additional_time': '5-10 minutes',
                'health_benefit': 'Lower vehicle exhaust exposure',
                'suitability_score': 8.5
            })
            
            # Strategy 2: Park and green corridor routes
            alternatives.append({
                'route_name': 'Green Corridor Route',
                'route_type': 'parks_and_green_spaces',
                'air_quality_benefit': 'Passes through parks and tree-lined roads',
                'estimated_aqi_reduction': '20-35%',
                'additional_time': '10-15 minutes',
                'health_benefit': 'Cleaner air, natural oxygen boost',
                'suitability_score': 9.2
            })
            
            # Strategy 3: Early morning/late evening timing
            alternatives.append({
                'route_name': 'Off-Peak Timing',
                'route_type': 'time_optimization',
                'air_quality_benefit': 'Travel during low traffic hours',
                'estimated_aqi_reduction': '25-40%',
                'additional_time': 'No additional time',
                'health_benefit': 'Significantly reduced pollution exposure',
                'suitability_score': 9.5
            })
            
            return {
                'origin': origin,
                'destination': destination,
                'transport_mode': transport_mode,
                'cleaner_alternatives': alternatives,
                'recommendation': alternatives[2],  # Best alternative (off-peak timing)
                'air_quality_priority': True,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to suggest cleaner routes: {e}")
            return self._get_fallback_cleaner_routes(origin, destination, transport_mode)
    
    async def _fetch_google_air_quality(self, coordinates, transport_mode):
        """Fetch air quality data from Google Air Quality API"""
        try:
            # Construct API request
            url = f"{self.base_url}/currentConditions:lookup"
            
            payload = {
                "location": {
                    "latitude": coordinates['lat'],
                    "longitude": coordinates['lng']
                },
                "extraComputations": [
                    "HEALTH_RECOMMENDATIONS",
                    "DOMINANT_POLLUTANT",
                    "POLLUTANT_CONCENTRATION",
                    "LOCAL_AQI",
                    "POLLUTANT_ADDITIONAL_INFO"
                ]
            }
            
            headers = {
                'Content-Type': 'application/json',
            }
            
            # For demo purposes, return enhanced mock data
            # In production, make actual API call:
            # response = requests.post(url, json=payload, headers=headers, params={'key': self.google_api_key})
            
            return self._get_enhanced_mock_air_quality_data(coordinates, transport_mode)
            
        except Exception as e:
            logger.warning(f"Google Air Quality API call failed: {e}")
            return None
    
    def _get_location_coordinates(self, location):
        """Get coordinates for a location (simplified for Bengaluru areas)"""
        # Simplified coordinate mapping for common Bengaluru locations
        location_coords = {
            'koramangala': {'lat': 12.9352, 'lng': 77.6245},
            'electronic city': {'lat': 12.8456, 'lng': 77.6603},
            'whitefield': {'lat': 12.9698, 'lng': 77.7500},
            'hsr layout': {'lat': 12.9116, 'lng': 77.6440},
            'marathahalli': {'lat': 12.9591, 'lng': 77.6974},
            'sarjapur': {'lat': 12.8988, 'lng': 77.6922},
            'bannerghatta': {'lat': 12.9034, 'lng': 77.5946}
        }
        
        location_key = location.lower().replace(' ', '').replace('blr', '').replace('airport', '').strip()
        
        # Find closest match
        for key, coords in location_coords.items():
            if key in location_key or location_key in key:
                return coords
        
        # Default to Bengaluru center
        return {'lat': 12.9716, 'lng': 77.5946}
    
    def _get_enhanced_mock_air_quality_data(self, coordinates, transport_mode):
        """Generate realistic air quality data based on time patterns"""
        current_hour = datetime.now().hour
        
        # Air quality varies predictably by time of day in Bengaluru
        if 7 <= current_hour <= 10 or 17 <= current_hour <= 20:  # Peak hours
            base_aqi = 150  # Moderate to unhealthy during traffic hours
        elif 22 <= current_hour <= 6:  # Night/early morning
            base_aqi = 95   # Better air quality at night
        else:  # Off-peak
            base_aqi = 110  # Moderate during day
        
        # Realistic pollutant data for Bengaluru
        pollutants = {
            'pm2_5': min(base_aqi, 120),  # PM2.5 is major concern
            'pm10': base_aqi + 20,        # PM10 usually higher
            'no2': 45,                    # Vehicle emissions
            'so2': 25,                    # Industrial
            'co': 1.8,                    # Traffic-related
            'o3': 85                      # Photochemical
        }
        
        dominant_pollutant = 'pm2_5'  # Most common in Bengaluru
        
        return {
            'location': coordinates,
            'aqi': base_aqi,
            'aqi_category': self._get_aqi_category(base_aqi),
            'dominant_pollutant': dominant_pollutant,
            'pollutants': pollutants,
            'health_recommendations': self._generate_health_recommendations(base_aqi, transport_mode),
            'visibility_impact': 'Reduced' if base_aqi > 150 else 'Good',
            'transport_suitability': self._assess_transport_suitability(base_aqi, transport_mode),
            'forecast_trend': 'stable',  # Conservative estimate
            'last_updated': datetime.now().isoformat(),
            'source': 'Time-based Air Quality Estimation (Bengaluru patterns)'
        }
    
    def _get_mock_air_quality_data(self, location, transport_mode):
        """Generate basic mock air quality data"""
        import random
        
        # Typical Bengaluru AQI ranges
        aqi_value = random.randint(80, 160)
        
        return {
            'location': location,
            'aqi': aqi_value,
            'aqi_category': self._get_aqi_category(aqi_value),
            'dominant_pollutant': 'pm2_5',
            'health_recommendations': self._generate_health_recommendations(aqi_value, transport_mode),
            'transport_suitability': self._assess_transport_suitability(aqi_value, transport_mode),
            'last_updated': datetime.now().isoformat(),
            'source': 'Mock Air Quality Data'
        }
    
    def _get_aqi_category(self, aqi_value):
        """Convert AQI value to category"""
        if aqi_value <= 50:
            return 'Good'
        elif aqi_value <= 100:
            return 'Moderate'
        elif aqi_value <= 150:
            return 'Unhealthy for Sensitive Groups'
        elif aqi_value <= 200:
            return 'Unhealthy'
        elif aqi_value <= 300:
            return 'Very Unhealthy'
        else:
            return 'Hazardous'
    
    def _assess_transport_suitability(self, aqi_value, transport_mode):
        """Assess if transport mode is suitable given air quality"""
        thresholds = self.aqi_thresholds.get(transport_mode, self.aqi_thresholds['bike'])
        
        if aqi_value <= thresholds['good']:
            return {
                'suitable': True,
                'recommendation': 'Excellent for outdoor activity',
                'risk_level': 'low'
            }
        elif aqi_value <= thresholds['moderate']:
            return {
                'suitable': True,
                'recommendation': 'Acceptable with minor precautions',
                'risk_level': 'low'
            }
        elif aqi_value <= thresholds['unhealthy_sensitive']:
            return {
                'suitable': False,
                'recommendation': 'Consider alternative transport or timing',
                'risk_level': 'medium'
            }
        else:
            return {
                'suitable': False,
                'recommendation': 'Strongly recommend alternative transport',
                'risk_level': 'high'
            }
    
    def _assess_health_risk(self, air_quality_data, transport_mode):
        """Assess health risk based on air quality and transport mode"""
        aqi = air_quality_data.get('aqi', 100)
        suitability = air_quality_data.get('transport_suitability', {})
        
        return {
            'risk_level': suitability.get('risk_level', 'medium'),
            'health_impact': self._get_health_impact_description(aqi, transport_mode),
            'precautions': self._get_health_precautions(aqi, transport_mode)
        }
    
    def _get_health_impact_description(self, aqi, transport_mode):
        """Get health impact description"""
        if transport_mode == 'bike':
            if aqi <= 50:
                return "Minimal health impact - ideal for cycling"
            elif aqi <= 100:
                return "Low impact - some individuals may experience minor respiratory irritation"
            elif aqi <= 150:
                return "Moderate impact - may cause discomfort for sensitive individuals"
            else:
                return "High impact - significant respiratory and cardiovascular stress"
        
        return "Health impact varies by individual sensitivity"
    
    def _get_health_precautions(self, aqi, transport_mode):
        """Get specific health precautions"""
        precautions = []
        
        if transport_mode in ['bike', 'walking']:
            if aqi > 100:
                precautions.extend([
                    "Consider wearing an N95 mask",
                    "Take frequent breaks if feeling unwell",
                    "Stay hydrated"
                ])
            
            if aqi > 150:
                precautions.extend([
                    "Limit outdoor exposure time",
                    "Avoid strenuous physical activity",
                    "Consider indoor alternatives"
                ])
        
        return precautions
    
    def _generate_health_recommendations(self, aqi, transport_mode):
        """Generate health recommendations based on AQI and transport mode"""
        recommendations = []
        
        if transport_mode == 'bike':
            if aqi <= 50:
                recommendations.append("Perfect conditions for cycling - enjoy your ride!")
            elif aqi <= 100:
                recommendations.append("Good for cycling with normal precautions")
            elif aqi <= 150:
                recommendations.append("Consider shorter routes or alternative timing")
            else:
                recommendations.append("Not recommended for cycling - use enclosed transport")
        
        return recommendations
    
    def _get_segment_recommendations(self, air_quality, transport_mode):
        """Get recommendations for a specific route segment"""
        aqi = air_quality.get('aqi', 100)
        recommendations = []
        
        if aqi > 150:
            recommendations.append("High pollution zone - minimize exposure time")
            recommendations.append("Consider alternative route through this area")
        elif aqi > 100:
            recommendations.append("Moderate pollution - maintain steady pace")
        
        return recommendations
    
    def _generate_route_health_recommendations(self, route_analysis, transport_mode):
        """Generate overall health recommendations for the route"""
        recommendations = []
        high_risk_segments = [seg for seg in route_analysis if seg['health_risk']['risk_level'] == 'high']
        
        if high_risk_segments:
            recommendations.append(f"⚠️ {len(high_risk_segments)} high-risk pollution zones detected")
            recommendations.append("🔄 Consider alternative route or transport mode")
            
        if transport_mode == 'bike':
            recommendations.append("😷 Consider wearing a pollution mask")
            recommendations.append("💧 Stay well hydrated during the journey")
            recommendations.append("⏰ Early morning (6-8 AM) has cleaner air")
        
        return recommendations
    
    def _get_fallback_air_quality_data(self, location, transport_mode):
        """Fallback air quality data when API fails"""
        return {
            'location': location,
            'aqi': 120,
            'aqi_category': 'Moderate',
            'transport_suitability': {'suitable': True, 'recommendation': 'Use with normal precautions', 'risk_level': 'low'},
            'health_recommendations': ['Monitor air quality regularly'],
            'last_updated': datetime.now().isoformat(),
            'source': 'Fallback Air Quality Data'
        }
    
    def _get_fallback_route_analysis(self, origin, destination, transport_mode):
        """Fallback route analysis when detailed analysis fails"""
        return {
            'route': f"{origin} -> {destination}",
            'transport_mode': transport_mode,
            'overall_risk_level': 'medium',
            'route_suitable': True,
            'alternative_needed': False,
            'health_recommendations': ['Monitor air quality during travel'],
            'analysis_timestamp': datetime.now().isoformat(),
            'source': 'Fallback Analysis'
        }
    
    def _get_fallback_cleaner_routes(self, origin, destination, transport_mode):
        """Fallback cleaner routes when suggestion fails"""
        return {
            'origin': origin,
            'destination': destination,
            'transport_mode': transport_mode,
            'cleaner_alternatives': [{
                'route_name': 'Standard Route',
                'route_type': 'main_roads',
                'air_quality_benefit': 'Monitor air quality',
                'health_benefit': 'Use standard precautions'
            }],
            'timestamp': datetime.now().isoformat(),
            'source': 'Fallback Suggestions'
        }
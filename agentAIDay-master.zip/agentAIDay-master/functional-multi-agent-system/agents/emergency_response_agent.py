# Add logging for debugging
import logging
import time
import os
import sys

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Validate imports
try:
    logger.info("Attempting to import google.adk...")
    from google.adk import Agent
    logger.info("✓ google.adk imported successfully")
except ImportError as e:
    logger.error(f"✗ Failed to import google.adk: {e}")
    # Fallback to a basic Agent class
    class Agent:
        def __init__(self, name=None):
            self.name = name
            logger.info(f"Using fallback Agent class for {name}")

try:
    import vertexai
    from vertexai.generative_models import GenerativeModel
    logger.info("✓ vertexai imported successfully")
except ImportError as e:
    logger.error(f"✗ Failed to import vertexai: {e}")

class EmergencyResponseAgent(Agent):
    def __init__(self):
        logger.info("Initializing EmergencyResponseAgent...")
        super().__init__(name="emergency_response_agent")  # Fix: pass name parameter
        
        # Set priority levels after initialization to avoid field conflicts
        self._priority_levels = {"fire": 10, "medical": 9, "accident": 7, "theft": 5}
        
        # Initialize Vertex AI with error handling
        try:
            project_id = os.environ.get('GOOGLE_CLOUD_PROJECT')
            location = os.environ.get('GOOGLE_CLOUD_LOCATION', 'us-central1')
            if project_id:
                vertexai.init(project=project_id, location=location)
                logger.info(f"✓ Vertex AI initialized for project {project_id}")
            else:
                logger.warning("⚠ GOOGLE_CLOUD_PROJECT not set, using default Vertex AI settings")
            
            self._model = GenerativeModel("gemini-2.0-flash")
            logger.info("✓ Gemini model initialized")
        except Exception as e:
            logger.error(f"✗ Failed to initialize Vertex AI/Gemini: {e}")
            self._model = None

    async def process_emergency(self, incident_type, location, description):
        logger.info(f"Processing emergency: {incident_type} at {location}")
        
        try:
            # ACTUAL emergency processing
            priority = self._priority_levels.get(incident_type, 5)
            logger.info(f"Priority level: {priority}")
            
            # Use Gemini for incident classification (with fallback)
            classification = f"Emergency type: {incident_type}"
            if self._model:
                try:
                    classification_prompt = f"Classify this emergency: {description}. Location: {location}"
                    response = self._model.generate_content(classification_prompt)
                    classification = response.text
                    logger.info("✓ AI classification completed")
                except Exception as e:
                    logger.error(f"✗ AI classification failed: {e}")
                    classification = f"Classification unavailable: {incident_type} at {location}"
            
            # ACTUAL resource allocation
            resources = await self.allocate_resources(incident_type, priority, location)
            
            # Coordinate with traffic agent for emergency vehicle routing
            optimal_route = await self.request_from_agent("traffic_agent", {
                "origin": "nearest_station",
                "destination": location,
                "priority": "emergency"
            })
            
            incident_id = f"INC_{int(time.time())}"
            logger.info(f"✓ Emergency processed successfully: {incident_id}")
            
            return {
                "incident_id": incident_id,
                "priority": priority,
                "classification": classification,
                "resources_assigned": resources,
                "route": optimal_route
            }
            
        except Exception as e:
            logger.error(f"✗ Emergency processing failed: {e}")
            return {"error": str(e), "incident_id": None}

    async def allocate_resources(self, incident_type, priority, location):
        logger.info(f"Allocating resources for {incident_type} (priority: {priority}) at {location}")
        
        # In a real implementation, this would be more sophisticated
        resource_map = {
            "fire": ["fire_truck", "ambulance", "police"],
            "medical": ["ambulance", "medical_team"],
            "accident": ["ambulance", "police", "tow_truck"],
            "theft": ["police"]
        }
        
        resources = resource_map.get(incident_type, ["police"])
        logger.info(f"✓ Resources allocated: {resources}")
        return resources
    
    async def request_from_agent(self, agent_name, request_data):
        """Make a request to another agent"""
        try:
            logger.info(f"Making request to {agent_name}: {request_data}")
            
            # In a real implementation, this would use inter-agent communication
            # For now, return a mock response based on the agent type
            if agent_name == "traffic_agent":
                response = {
                    "agent": agent_name,
                    "request": request_data,
                    "route_data": {
                        "estimated_time": "8 minutes",
                        "distance": "3.2 miles",
                        "route": "Emergency route calculated"
                    },
                    "status": "success"
                }
            else:
                response = {
                    "agent": agent_name,
                    "request": request_data,
                    "response": f"Mock response from {agent_name}",
                    "status": "success"
                }
            
            logger.info(f"✓ Request to {agent_name} completed")
            return response
            
        except Exception as e:
            logger.error(f"✗ Request to {agent_name} failed: {e}")
            return {"error": str(e), "status": "failed"}
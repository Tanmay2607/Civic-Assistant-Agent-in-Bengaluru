import logging
import json
from datetime import datetime
from typing import Dict, List, Any
import asyncio

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MasterRouteIntelligenceAgent:
    def __init__(self):
        logger.info("Initializing Master Route Intelligence Agent...")
        self.name = "master_route_intelligence_agent"
        
        # Import other agents
        from .weather_agent import WeatherAgent
        from .route_obstacle_agent import RouteObstacleAgent
        from .traffic_management_agent import TrafficManagementAgent
        from .emergency_response_agent import EmergencyResponseAgent
        from .air_quality_agent import AirQualityAgent
        
        # Initialize sub-agents
        self.weather_agent = WeatherAgent()
        self.obstacle_agent = RouteObstacleAgent()
        self.traffic_agent = TrafficManagementAgent()
        self.emergency_agent = EmergencyResponseAgent()
        self.air_quality_agent = AirQualityAgent()
        
        logger.info("✓ Master Route Intelligence Agent initialized with all sub-agents")
    
    async def get_intelligent_route(self, origin: str, destination: str, preferences: Dict = None) -> Dict:
        """
        Main method that coordinates all agents to provide intelligent routing
        """
        try:
            logger.info(f"🧠 Master Agent analyzing route: {origin} -> {destination}")
            
            # Default preferences
            if preferences is None:
                preferences = {
                    'prioritize': 'time',  # 'time', 'safety', 'fuel_efficiency', 'health'
                    'transport_mode': 'car',  # 'car', 'bike', 'walking'
                    'avoid_tolls': False,
                    'avoid_highways': False,
                    'weather_sensitivity': 'medium',  # 'low', 'medium', 'high'
                    'air_quality_priority': False  # True for bike/walking modes
                }
            
            # Auto-adjust preferences for bike/walking modes
            if preferences.get('transport_mode') in ['bike', 'walking']:
                preferences['air_quality_priority'] = True
            
            # Step 1: Gather data from all agents concurrently
            logger.info("📊 Gathering data from all agents...")
            
            # Run all agent queries concurrently for faster response
            tasks = [
                self._get_weather_data(origin, destination),
                self._get_traffic_data(origin, destination),
                self._get_obstacle_data(origin, destination),
                self._get_emergency_data(origin, destination),
                self._get_air_quality_data(origin, destination, preferences.get('transport_mode', 'car'))
            ]
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            weather_data, traffic_data, obstacle_data, emergency_data, air_quality_data = results
            
            # Step 2: Analyze and correlate all data
            logger.info("🔍 Analyzing and correlating all data sources...")
            analysis = self._correlate_agent_data(
                weather_data, traffic_data, obstacle_data, emergency_data, air_quality_data
            )
            
            # Step 3: Generate intelligent recommendations
            logger.info("💡 Generating intelligent route recommendations...")
            recommendations = await self._generate_intelligent_recommendations(
                origin, destination, analysis, preferences
            )
            
            # Step 4: Check if alternative routes are needed
            logger.info("🔄 Checking if alternative routes are needed...")
            alternative_routes = await self._check_and_suggest_alternatives(
                origin, destination, analysis, preferences, air_quality_data
            )
            
            # Step 5: Create comprehensive response
            intelligent_route = {
                'route_analysis': {
                    'origin': origin,
                    'destination': destination,
                    'analysis_timestamp': datetime.now().isoformat(),
                    'preferences': preferences,
                    'transport_mode': preferences.get('transport_mode', 'car')
                },
                'weather_conditions': weather_data,
                'traffic_analysis': traffic_data,
                'obstacles_detected': obstacle_data,
                'emergency_alerts': emergency_data,
                'air_quality_analysis': air_quality_data,
                'correlation_analysis': analysis,
                'intelligent_recommendations': recommendations,
                'alternative_routes': alternative_routes,
                'route_suitable': analysis.get('route_suitable', True),
                'confidence_score': self._calculate_confidence_score(analysis),
                'next_update_in_minutes': 15
            }
            
            logger.info("✅ Intelligent route analysis completed successfully")
            return intelligent_route
            
        except Exception as e:
            logger.error(f"❌ Master Agent analysis failed: {e}")
            return self._get_fallback_intelligent_route(origin, destination)
    
    async def _get_weather_data(self, origin: str, destination: str) -> Dict:
        """Get weather data for route"""
        try:
            # Get weather for both origin and destination
            origin_weather = await self.weather_agent.get_current_weather(origin)
            destination_weather = await self.weather_agent.get_current_weather(destination)
            forecast = await self.weather_agent.get_weather_forecast(origin, hours=3)
            
            return {
                'origin_weather': origin_weather,
                'destination_weather': destination_weather,
                'route_forecast': forecast,
                'weather_impact_assessment': self._assess_weather_impact(origin_weather, destination_weather)
            }
        except Exception as e:
            logger.error(f"Weather data collection failed: {e}")
            return {'error': str(e), 'weather_impact_assessment': 'unknown'}
    
    async def _get_traffic_data(self, origin: str, destination: str) -> Dict:
        """Get traffic data for route"""
        try:
            route_data = await self.traffic_agent.analyze_route(origin, destination)
            return route_data
        except Exception as e:
            logger.error(f"Traffic data collection failed: {e}")
            return {'error': str(e)}
    
    async def _get_obstacle_data(self, origin: str, destination: str) -> Dict:
        """Get obstacle data for route"""
        try:
            obstacles = await self.obstacle_agent.get_route_obstacles(origin, destination)
            traffic_analysis = await self.obstacle_agent.get_live_traffic_data([origin, destination])
            
            return {
                'obstacles': obstacles,
                'live_traffic': traffic_analysis
            }
        except Exception as e:
            logger.error(f"Obstacle data collection failed: {e}")
            return {'error': str(e)}
    
    async def _get_emergency_data(self, origin: str, destination: str) -> Dict:
        """Get emergency alerts for route area"""
        try:
            # Check for any emergencies in the route area
            emergency_check = {
                'route_area': f"{origin} to {destination}",
                'active_incidents': [],
                'severity_level': 'low',
                'impact_on_traffic': 'minimal',
                'timestamp': datetime.now().isoformat()
            }
            return emergency_check
        except Exception as e:
            logger.error(f"Emergency data collection failed: {e}")
            return {'error': str(e)}
    
    async def _get_air_quality_data(self, origin: str, destination: str, transport_mode: str) -> Dict:
        """Get air quality data for route"""
        try:
            # Get air quality for both origin and destination
            origin_air_quality = await self.air_quality_agent.get_air_quality_data(origin, transport_mode)
            destination_air_quality = await self.air_quality_agent.get_air_quality_data(destination, transport_mode)
            
            # Analyze air quality along the route
            route_analysis = await self.air_quality_agent.get_route_air_quality_analysis(
                origin, destination, [origin, destination], transport_mode
            )
            
            return {
                'origin_air_quality': origin_air_quality,
                'destination_air_quality': destination_air_quality,
                'route_analysis': route_analysis,
                'transport_mode': transport_mode
            }
        except Exception as e:
            logger.error(f"Air quality data collection failed: {e}")
            return {'error': str(e), 'transport_mode': transport_mode}
    
    def _correlate_agent_data(self, weather_data: Dict, traffic_data: Dict,
                            obstacle_data: Dict, emergency_data: Dict, air_quality_data: Dict) -> Dict:
        """Correlate data from all agents to find patterns and insights"""
        
        correlation = {
            'risk_factors': [],
            'travel_time_factors': [],
            'safety_concerns': [],
            'efficiency_factors': [],
            'health_factors': [],
            'recommendations': [],
            'route_suitable': True
        }
        
        # Weather correlation
        if weather_data and not weather_data.get('error'):
            weather_impact = weather_data.get('weather_impact_assessment', {})
            
            if weather_impact.get('traffic_impact') == 'high':
                correlation['risk_factors'].append('Heavy rain affecting visibility and traffic')
                correlation['travel_time_factors'].append('Weather-related delays expected (+15-30 min)')
                correlation['safety_concerns'].append('Reduced visibility due to weather')
        
        # Traffic correlation
        if traffic_data and not traffic_data.get('error'):
            if traffic_data.get('route'):
                route_info = traffic_data['route'][0]['legs'][0] if traffic_data['route'] else {}
                correlation['travel_time_factors'].append(f"Base travel time: {route_info.get('duration', {}).get('text', 'Unknown')}")
        
        # Obstacle correlation
        if obstacle_data and not obstacle_data.get('error'):
            obstacles = obstacle_data.get('obstacles', {}).get('obstacles', [])
            if obstacles:
                high_severity_obstacles = [obs for obs in obstacles if obs.get('severity') == 'high']
                if high_severity_obstacles:
                    correlation['risk_factors'].append(f'{len(high_severity_obstacles)} high-severity obstacles detected')
                    correlation['safety_concerns'].append('Route has significant obstacles')
        
        # Cross-correlation insights
        if len(correlation['risk_factors']) >= 2:
            correlation['recommendations'].append('Multiple risk factors detected - consider alternative route')
        
        if len(correlation['travel_time_factors']) >= 2:
            correlation['recommendations'].append('Significant delays expected - allow extra time')
        
        # Air quality correlation
        if air_quality_data and not air_quality_data.get('error'):
            route_analysis = air_quality_data.get('route_analysis', {})
            if route_analysis.get('overall_risk_level') == 'high':
                correlation['health_factors'].append('High air pollution detected - unsuitable for outdoor exposure')
                correlation['safety_concerns'].append('Poor air quality may affect health')
                correlation['route_suitable'] = False
                correlation['recommendations'].append('🚨 Poor air quality detected - consider alternative route or transport mode')
            elif route_analysis.get('overall_risk_level') == 'medium':
                correlation['health_factors'].append('Moderate air pollution - take precautions')
                correlation['recommendations'].append('⚠️ Moderate air pollution - consider protective measures')
        
        # Cross-correlation with transport mode
        transport_mode = air_quality_data.get('transport_mode', 'car')
        if transport_mode in ['bike', 'walking'] and len(correlation['health_factors']) > 0:
            correlation['recommendations'].append('🚴‍♂️ For bike/walking: Strong recommendation to use alternative route or timing')
            correlation['route_suitable'] = False
        
        return correlation
    
    async def _check_and_suggest_alternatives(self, origin: str, destination: str,
                                            analysis: Dict, preferences: Dict, air_quality_data: Dict) -> Dict:
        """Check if alternative routes are needed and suggest them"""
        try:
            transport_mode = preferences.get('transport_mode', 'car')
            
            # Check if alternatives are needed
            needs_alternative = False
            reasons = []
            
            if not analysis.get('route_suitable', True):
                needs_alternative = True
                reasons.append('Primary route unsuitable due to current conditions')
            
            if len(analysis.get('health_factors', [])) > 0 and transport_mode in ['bike', 'walking']:
                needs_alternative = True
                reasons.append('Health concerns for outdoor transport mode')
            
            if len(analysis.get('risk_factors', [])) >= 2:
                needs_alternative = True
                reasons.append('Multiple risk factors detected')
            
            alternatives = {}
            
            if needs_alternative:
                logger.info("🔄 Alternative routes needed - generating suggestions...")
                
                # Get cleaner routes for bike/walking
                if transport_mode in ['bike', 'walking']:
                    air_alternatives = await self.air_quality_agent.suggest_cleaner_routes(
                        origin, destination, transport_mode
                    )
                    alternatives['air_quality_routes'] = air_alternatives
                
                # Get traffic alternatives
                traffic_alternatives = await self.obstacle_agent.get_alternative_routes(
                    origin, destination, analysis.get('risk_factors', [])
                )
                alternatives['traffic_routes'] = traffic_alternatives
                
                # Combine and rank alternatives
                alternatives['recommended_action'] = self._get_recommended_action(
                    analysis, transport_mode, reasons
                )
            
            return {
                'alternatives_needed': needs_alternative,
                'reasons': reasons,
                'alternatives': alternatives,
                'transport_mode': transport_mode,
                'generated_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Alternative route checking failed: {e}")
            return {
                'alternatives_needed': False,
                'error': str(e),
                'transport_mode': transport_mode
            }
    
    def _get_recommended_action(self, analysis: Dict, transport_mode: str, reasons: List[str]) -> Dict:
        """Get recommended action based on analysis"""
        
        if transport_mode in ['bike', 'walking'] and len(analysis.get('health_factors', [])) > 0:
            return {
                'primary_action': 'Switch to enclosed transport (car/bus/metro)',
                'secondary_action': 'Use alternative route with better air quality',
                'timing_recommendation': 'Travel during early morning (6-8 AM) for cleaner air',
                'health_priority': True
            }
        elif len(analysis.get('risk_factors', [])) >= 2:
            return {
                'primary_action': 'Use alternative route',
                'secondary_action': 'Delay travel if possible',
                'timing_recommendation': 'Avoid peak hours',
                'health_priority': False
            }
        else:
            return {
                'primary_action': 'Proceed with caution',
                'secondary_action': 'Monitor conditions regularly',
                'timing_recommendation': 'Allow extra time',
                'health_priority': False
            }
    
    async def _generate_intelligent_recommendations(self, origin: str, destination: str, 
                                                  analysis: Dict, preferences: Dict) -> Dict:
        """Generate intelligent recommendations based on all available data"""
        
        recommendations = {
            'primary_recommendation': '',
            'alternative_options': [],
            'timing_suggestions': [],
            'safety_tips': [],
            'efficiency_tips': [],
            'real_time_updates': True
        }
        
        # Analyze risk level
        risk_count = len(analysis.get('risk_factors', []))
        safety_concerns = len(analysis.get('safety_concerns', []))
        
        if risk_count == 0 and safety_concerns == 0:
            recommendations['primary_recommendation'] = '✅ Route looks good! Proceed with confidence.'
        elif risk_count <= 1 and safety_concerns <= 1:
            recommendations['primary_recommendation'] = '⚠️ Minor concerns detected. Proceed with caution.'
        else:
            recommendations['primary_recommendation'] = '🚨 Multiple issues detected. Consider alternative route or timing.'
        
        # Generate alternative options
        try:
            alternatives = await self.obstacle_agent.get_alternative_routes(
                origin, destination, analysis.get('risk_factors', [])
            )
            
            if alternatives and not alternatives.get('error'):
                for alt in alternatives.get('alternatives', [])[:2]:  # Top 2 alternatives
                    recommendations['alternative_options'].append({
                        'route_name': alt.get('route_name'),
                        'estimated_time': alt.get('estimated_time_minutes'),
                        'benefits': self._identify_route_benefits(alt)
                    })
        except Exception as e:
            logger.warning(f"Could not generate alternatives: {e}")
        
        # Timing suggestions based on current conditions
        current_hour = datetime.now().hour
        
        if 7 <= current_hour <= 9:
            recommendations['timing_suggestions'].append('Peak morning hour - consider leaving 30 minutes later')
        elif 17 <= current_hour <= 19:
            recommendations['timing_suggestions'].append('Peak evening hour - consider leaving 1 hour later')
        else:
            recommendations['timing_suggestions'].append('Good time to travel - minimal traffic expected')
        
        # Safety tips
        recommendations['safety_tips'].extend([
            'Keep emergency contacts handy',
            'Ensure vehicle is in good condition',
            'Check fuel level before starting'
        ])
        
        # Add weather-specific safety tips
        if any('rain' in factor.lower() for factor in analysis.get('risk_factors', [])):
            recommendations['safety_tips'].extend([
                'Drive slowly in wet conditions',
                'Maintain extra distance from other vehicles',
                'Use headlights for better visibility'
            ])
        
        # Efficiency tips
        recommendations['efficiency_tips'].extend([
            'Use navigation apps for real-time updates',
            'Consider carpooling to reduce traffic',
            'Plan for rest stops on longer journeys'
        ])
        
        return recommendations
    
    def _assess_weather_impact(self, origin_weather: Dict, destination_weather: Dict) -> Dict:
        """Assess overall weather impact on travel"""
        
        impact_assessment = {
            'overall_impact': 'low',
            'visibility_impact': 'good',
            'road_condition_impact': 'normal',
            'travel_time_impact': 'minimal'
        }
        
        # Check both origin and destination weather
        weathers = [origin_weather, destination_weather]
        
        for weather in weathers:
            if weather and weather.get('condition'):
                condition = weather['condition']
                visibility = weather.get('visibility_km', 10)
                
                if 'Heavy Rain' in condition:
                    impact_assessment['overall_impact'] = 'high'
                    impact_assessment['visibility_impact'] = 'poor'
                    impact_assessment['road_condition_impact'] = 'wet_hazardous'
                    impact_assessment['travel_time_impact'] = 'significant'
                elif 'Light Rain' in condition or visibility < 7:
                    impact_assessment['overall_impact'] = 'medium'
                    impact_assessment['visibility_impact'] = 'reduced'
                    impact_assessment['road_condition_impact'] = 'wet'
                    impact_assessment['travel_time_impact'] = 'moderate'
        
        return impact_assessment
    
    def _identify_route_benefits(self, route: Dict) -> List[str]:
        """Identify benefits of an alternative route"""
        benefits = []
        
        if route.get('traffic_level') == 'light':
            benefits.append('Less traffic congestion')
        
        if route.get('estimated_time_minutes', 60) < 45:
            benefits.append('Faster travel time')
        
        if not route.get('toll_required', True):
            benefits.append('No toll charges')
        
        if route.get('road_quality') == 'excellent':
            benefits.append('Better road quality')
        
        if route.get('scenic_route'):
            benefits.append('Scenic route')
        
        return benefits or ['Alternative route option']
    
    def _calculate_confidence_score(self, analysis: Dict) -> float:
        """Calculate confidence score based on data quality and consistency"""
        
        base_score = 0.8  # Base confidence
        
        # Reduce confidence for each risk factor
        risk_factors = len(analysis.get('risk_factors', []))
        confidence_reduction = risk_factors * 0.1
        
        # Reduce confidence if we have data collection errors
        if any('error' in str(analysis).lower() for _ in [analysis]):
            confidence_reduction += 0.2
        
        final_score = max(0.3, base_score - confidence_reduction)  # Minimum 30% confidence
        return round(final_score, 2)
    
    def _get_fallback_intelligent_route(self, origin: str, destination: str) -> Dict:
        """Fallback response when main analysis fails"""
        return {
            'route_analysis': {
                'origin': origin,
                'destination': destination,
                'analysis_timestamp': datetime.now().isoformat(),
                'status': 'fallback_mode'
            },
            'intelligent_recommendations': {
                'primary_recommendation': '⚠️ Limited data available. Proceed with standard precautions.',
                'alternative_options': [],
                'timing_suggestions': ['Allow extra time for unexpected delays'],
                'safety_tips': ['Drive carefully and stay alert', 'Use navigation apps for updates'],
                'efficiency_tips': ['Check traffic apps before leaving']
            },
            'confidence_score': 0.4,
            'note': 'Fallback intelligent routing - limited data available'
        }
"""
Real-Time Obstacle Management Agent
Extends the Traffic Management Agent with comprehensive obstacle reporting and management capabilities
"""

import uuid
import json
import base64
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from google.cloud import bigquery, storage
from google.cloud import aiplatform
import googlemaps
import requests
import io
from PIL import Image

class ObstacleManagementAgent:
    """
    Advanced obstacle management agent with AI-powered analysis and real-time tracking
    """
    
    def __init__(self, project_id: str, dataset_id: str = "traffic_management"):
        self.project_id = project_id
        self.dataset_id = dataset_id
        self.table_id = "obstacles"
        
        # Initialize Google Cloud clients
        self.bigquery_client = bigquery.Client(project=project_id)
        self.storage_client = storage.Client(project=project_id)
        self.gmaps_client = googlemaps.Client(key="AIzaSyC-VQzmR1aLxXJsFYtYKZN6yyGr_hIxRic")
        
        # Cloud Storage bucket for images
        self.bucket_name = f"{project_id}-obstacle-images"
        self._ensure_bucket_exists()
        
        # Obstacle type mappings and severity rules
        self.obstacle_types = {
            "pothole": {"base_severity": 5, "impact_radius": 30},
            "road_closure": {"base_severity": 9, "impact_radius": 500},
            "accident": {"base_severity": 7, "impact_radius": 200},
            "construction": {"base_severity": 6, "impact_radius": 300},
            "debris": {"base_severity": 4, "impact_radius": 50},
            "flooding": {"base_severity": 8, "impact_radius": 1000},
            "broken_signal": {"base_severity": 7, "impact_radius": 100},
            "fallen_tree": {"base_severity": 6, "impact_radius": 150},
            "vehicle_breakdown": {"base_severity": 4, "impact_radius": 100}
        }
        
    def _ensure_bucket_exists(self):
        """Ensure the Cloud Storage bucket exists for storing obstacle images"""
        try:
            bucket = self.storage_client.bucket(self.bucket_name)
            if not bucket.exists():
                bucket = self.storage_client.create_bucket(self.bucket_name, location="US")
                print(f"✅ Created Cloud Storage bucket: {self.bucket_name}")
            
            # Set bucket to public read for image URLs
            policy = bucket.get_iam_policy(requested_policy_version=3)
            policy.bindings.append({
                "role": "roles/storage.objectViewer",
                "members": ["allUsers"]
            })
            bucket.set_iam_policy(policy)
            
        except Exception as e:
            print(f"⚠️ Warning: Could not create/configure bucket: {str(e)}")
    
    async def report_obstacle(self, 
                            latitude: float, 
                            longitude: float, 
                            obstacle_type: str, 
                            description: str,
                            image_base64: Optional[str] = None,
                            user_id: Optional[str] = None,
                            reporter_name: Optional[str] = None,
                            contact_info: Optional[str] = None) -> Dict:
        """
        Report a new traffic obstacle with photo upload and AI analysis
        
        Args:
            latitude: GPS latitude coordinate
            longitude: GPS longitude coordinate  
            obstacle_type: Type of obstacle (pothole, accident, etc.)
            description: User description of the obstacle
            image_base64: Base64 encoded image data (optional)
            user_id: ID of reporting user (optional)
            reporter_name: Name of reporter (optional)
            contact_info: Contact information (optional)
            
        Returns:
            Dict with obstacle_id and processing results
        """
        
        try:
            # Generate unique obstacle ID
            obstacle_id = f"OBS_{uuid.uuid4().hex[:8].upper()}"
            
            # Get address from coordinates
            address = await self._reverse_geocode(latitude, longitude)
            
            # Upload image if provided
            image_url = None
            if image_base64:
                image_url = await self._upload_image(obstacle_id, image_base64)
            
            # AI-powered severity analysis
            severity = await self._analyze_severity(obstacle_type, description, image_url)
            
            # Calculate impact radius and priority
            impact_radius = self._calculate_impact_radius(obstacle_type, severity)
            priority = self._determine_priority(obstacle_type, severity)
            
            # Get current weather conditions
            weather_conditions = await self._get_weather_conditions(latitude, longitude)
            
            # Prepare obstacle record
            obstacle_record = {
                "obstacle_id": obstacle_id,
                "user_id": user_id,
                "latitude": latitude,
                "longitude": longitude,
                "address": address,
                "obstacle_type": obstacle_type,
                "description": description,
                "severity": severity,
                "image_url": image_url,
                "reported_timestamp": datetime.utcnow().isoformat(),
                "resolution_status": "REPORTED",
                "resolved_timestamp": None,
                "verified": False,
                "impact_radius_meters": impact_radius,
                "priority": priority,
                "weather_conditions": weather_conditions,
                "reporter_name": reporter_name,
                "contact_info": contact_info,
                "estimated_clear_time": None,
                "additional_metadata": json.dumps({
                    "ai_confidence": 0.85,
                    "auto_generated": True,
                    "version": "1.0"
                })
            }
            
            # Insert into BigQuery
            table_ref = self.bigquery_client.dataset(self.dataset_id).table(self.table_id)
            table = self.bigquery_client.get_table(table_ref)
            
            errors = self.bigquery_client.insert_rows_json(table, [obstacle_record])
            
            if errors:
                raise Exception(f"BigQuery insertion failed: {errors}")
            
            print(f"✅ Successfully reported obstacle {obstacle_id}")
            
            return {
                "success": True,
                "obstacle_id": obstacle_id,
                "severity": severity,
                "priority": priority,
                "address": address,
                "image_url": image_url,
                "estimated_impact_radius": impact_radius
            }
            
        except Exception as e:
            print(f"❌ Error reporting obstacle: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def get_obstacles_in_area(self, 
                                  north_lat: float, 
                                  south_lat: float, 
                                  east_lng: float, 
                                  west_lng: float,
                                  include_resolved: bool = False) -> List[Dict]:
        """
        Get all obstacles within a geographic bounding box
        
        Args:
            north_lat, south_lat, east_lng, west_lng: Bounding box coordinates
            include_resolved: Whether to include resolved obstacles
            
        Returns:
            List of obstacle records
        """
        
        try:
            # Build the query
            status_filter = ""
            if not include_resolved:
                status_filter = "AND resolution_status != 'RESOLVED'"
            
            query = f"""
            SELECT *
            FROM `{self.project_id}.{self.dataset_id}.{self.table_id}`
            WHERE latitude BETWEEN {south_lat} AND {north_lat}
            AND longitude BETWEEN {west_lng} AND {east_lng}
            {status_filter}
            ORDER BY reported_timestamp DESC
            """
            
            results = self.bigquery_client.query(query).result()
            
            obstacles = []
            for row in results:
                obstacle = dict(row)
                # Parse additional_metadata if it exists
                if obstacle.get('additional_metadata'):
                    try:
                        obstacle['additional_metadata'] = json.loads(obstacle['additional_metadata'])
                    except:
                        pass
                obstacles.append(obstacle)
            
            print(f"📍 Found {len(obstacles)} obstacles in area")
            return obstacles
            
        except Exception as e:
            print(f"❌ Error getting obstacles from BigQuery: {str(e)}")
            print("⚠️ Falling back to sample data")
            
            # Fallback to sample data
            return self._get_sample_obstacles(north_lat, south_lat, east_lng, west_lng, include_resolved)
    
    def _get_sample_obstacles(self, north_lat: float, south_lat: float, east_lng: float, west_lng: float, include_resolved: bool = False) -> List[Dict]:
        """Generate sample obstacles for testing when BigQuery is not available or empty"""
        
        sample_obstacles = [
            {
                "obstacle_id": "OBS_SAMPLE_001",
                "user_id": "user123",
                "latitude": 12.9716,
                "longitude": 77.5946,
                "address": "MG Road, Bengaluru, Karnataka, India",
                "obstacle_type": "pothole",
                "description": "Large pothole causing traffic slowdown on main road",
                "severity": 7,
                "image_url": "https://via.placeholder.com/300x200/e67e22/white?text=🕳️+Pothole",
                "reported_timestamp": "2024-01-27T10:30:00Z",
                "resolution_status": "VERIFIED",
                "resolved_timestamp": None,
                "verified": True,
                "impact_radius_meters": 50,
                "priority": "HIGH",
                "weather_conditions": "Clear",
                "reporter_name": "John Doe",
                "contact_info": "+91-9876543210",
                "estimated_clear_time": None,
                "additional_metadata": {"vehicle_type": "car", "traffic_level": "heavy", "sample_data": True}
            },
            {
                "obstacle_id": "OBS_SAMPLE_002",
                "user_id": "user456",
                "latitude": 12.9352,
                "longitude": 77.6245,
                "address": "Electronic City, Bengaluru, Karnataka, India",
                "obstacle_type": "construction",
                "description": "Road construction blocking one lane, heavy machinery present",
                "severity": 8,
                "image_url": "https://via.placeholder.com/300x200/f39c12/white?text=🏗️+Construction",
                "reported_timestamp": "2024-01-27T09:15:00Z",
                "resolution_status": "IN_PROGRESS",
                "resolved_timestamp": None,
                "verified": True,
                "impact_radius_meters": 200,
                "priority": "CRITICAL",
                "weather_conditions": "Sunny",
                "reporter_name": "Jane Smith",
                "contact_info": "jane@example.com",
                "estimated_clear_time": "2024-01-28T18:00:00Z",
                "additional_metadata": {"construction_type": "road_widening", "contractor": "XYZ Construction", "sample_data": True}
            },
            {
                "obstacle_id": "OBS_SAMPLE_003",
                "user_id": "user789",
                "latitude": 12.9165,
                "longitude": 77.6229,
                "address": "Silk Board Junction, Bengaluru, Karnataka, India",
                "obstacle_type": "road_closure",
                "description": "Complete road closure due to metro construction work",
                "severity": 9,
                "image_url": "https://via.placeholder.com/300x200/e74c3c/white?text=🚧+Road+Closed",
                "reported_timestamp": "2024-01-27T08:00:00Z",
                "resolution_status": "REPORTED",
                "resolved_timestamp": None,
                "verified": False,
                "impact_radius_meters": 500,
                "priority": "CRITICAL",
                "weather_conditions": "Clear",
                "reporter_name": "Traffic Police",
                "contact_info": "traffic@bengaluru.gov.in",
                "estimated_clear_time": "2024-01-29T18:00:00Z",
                "additional_metadata": {"authority": "BMRCL", "project": "metro_expansion", "sample_data": True}
            },
            {
                "obstacle_id": "OBS_SAMPLE_004",
                "user_id": "user101",
                "latitude": 12.9698,
                "longitude": 77.7500,
                "address": "Whitefield, Bengaluru, Karnataka, India",
                "obstacle_type": "flooding",
                "description": "Water logging on main road due to heavy rains, 2 feet deep",
                "severity": 6,
                "image_url": "https://via.placeholder.com/300x200/3498db/white?text=🌊+Flooding",
                "reported_timestamp": "2024-01-27T07:30:00Z",
                "resolution_status": "VERIFIED",
                "resolved_timestamp": None,
                "verified": True,
                "impact_radius_meters": 300,
                "priority": "HIGH",
                "weather_conditions": "Heavy Rain",
                "reporter_name": "Resident Association",
                "contact_info": "+91-9988776655",
                "estimated_clear_time": "2024-01-27T16:00:00Z",
                "additional_metadata": {"water_level": "moderate", "drainage_issue": True, "sample_data": True}
            },
            {
                "obstacle_id": "OBS_SAMPLE_005",
                "user_id": "user202",
                "latitude": 12.9591,
                "longitude": 77.6476,
                "address": "Koramangala, Bengaluru, Karnataka, India",
                "obstacle_type": "broken_signal",
                "description": "Traffic signal completely non-functional during peak hours",
                "severity": 5,
                "image_url": "https://via.placeholder.com/300x200/e74c3c/white?text=🚦+Signal+Issue",
                "reported_timestamp": "2024-01-27T08:45:00Z",
                "resolution_status": "RESOLVED",
                "resolved_timestamp": "2024-01-27T12:00:00Z",
                "verified": True,
                "impact_radius_meters": 100,
                "priority": "MEDIUM",
                "weather_conditions": "Clear",
                "reporter_name": "Traffic Volunteer",
                "contact_info": "+91-8877665544",
                "estimated_clear_time": None,
                "additional_metadata": {"signal_type": "main_intersection", "repair_status": "completed", "sample_data": True}
            }
        ]
        
        # Filter obstacles by geographic bounds
        filtered_obstacles = []
        for obstacle in sample_obstacles:
            lat, lng = obstacle["latitude"], obstacle["longitude"]
            if (south_lat <= lat <= north_lat and west_lng <= lng <= east_lng):
                # Filter by resolution status if needed
                if include_resolved or obstacle["resolution_status"] != "RESOLVED":
                    filtered_obstacles.append(obstacle)
        
        print(f"📍 Generated {len(filtered_obstacles)} sample obstacles for testing")
        return filtered_obstacles
    
    async def update_obstacle_status(self, 
                                   obstacle_id: str, 
                                   new_status: str,
                                   estimated_clear_time: Optional[str] = None,
                                   notes: Optional[str] = None) -> Dict:
        """
        Update the resolution status of an obstacle
        
        Args:
            obstacle_id: Unique obstacle identifier
            new_status: New status (VERIFIED, IN_PROGRESS, RESOLVED, FALSE_REPORT)
            estimated_clear_time: Estimated resolution time (ISO format)
            notes: Additional notes about the status update
            
        Returns:
            Dict with update results
        """
        
        try:
            # Prepare update query
            set_clauses = [f"resolution_status = '{new_status}'"]
            
            if new_status == "RESOLVED":
                set_clauses.append(f"resolved_timestamp = CURRENT_TIMESTAMP()")
            
            if new_status in ["VERIFIED", "IN_PROGRESS"]:
                set_clauses.append("verified = true")
            
            if estimated_clear_time:
                set_clauses.append(f"estimated_clear_time = '{estimated_clear_time}'")
            
            # Update additional metadata with notes
            if notes:
                metadata_update = json.dumps({
                    "status_update_notes": notes,
                    "last_updated": datetime.utcnow().isoformat()
                })
                set_clauses.append(f"additional_metadata = '{metadata_update}'")
            
            update_query = f"""
            UPDATE `{self.project_id}.{self.dataset_id}.{self.table_id}`
            SET {', '.join(set_clauses)}
            WHERE obstacle_id = '{obstacle_id}'
            """
            
            job = self.bigquery_client.query(update_query)
            job.result()  # Wait for completion
            
            print(f"✅ Updated obstacle {obstacle_id} status to {new_status}")
            
            return {
                "success": True,
                "obstacle_id": obstacle_id,
                "new_status": new_status,
                "updated_timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            print(f"❌ Error updating obstacle status: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def get_obstacles_on_route(self, 
                                   origin_lat: float, 
                                   origin_lng: float,
                                   dest_lat: float, 
                                   dest_lng: float,
                                   buffer_meters: int = 500) -> List[Dict]:
        """
        Get obstacles that might affect a specific route
        
        Args:
            origin_lat, origin_lng: Starting point coordinates
            dest_lat, dest_lng: Destination coordinates
            buffer_meters: How far from route to search for obstacles
            
        Returns:
            List of obstacles affecting the route
        """
        
        try:
            # Get route from Google Maps
            directions_result = self.gmaps_client.directions(
                (origin_lat, origin_lng),
                (dest_lat, dest_lng),
                mode="driving",
                alternatives=True
            )
            
            if not directions_result:
                return []
            
            # Extract route polyline points
            route_points = []
            for step in directions_result[0]['legs'][0]['steps']:
                # Decode polyline and get coordinates
                polyline = step['polyline']['points']
                decoded_points = self._decode_polyline(polyline)
                route_points.extend(decoded_points)
            
            # Find obstacles near route
            affecting_obstacles = []
            
            # Get all unresolved obstacles in the general area
            area_obstacles = await self.get_obstacles_in_area(
                max(origin_lat, dest_lat) + 0.01,
                min(origin_lat, dest_lat) - 0.01,
                max(origin_lng, dest_lng) + 0.01,
                min(origin_lng, dest_lng) - 0.01,
                include_resolved=False
            )
            
            # Check each obstacle's distance from route
            for obstacle in area_obstacles:
                min_distance = float('inf')
                
                for point in route_points:
                    distance = self._calculate_distance(
                        obstacle['latitude'], obstacle['longitude'],
                        point[0], point[1]
                    )
                    min_distance = min(min_distance, distance)
                
                # If obstacle is within buffer distance, it affects the route
                if min_distance <= buffer_meters:
                    obstacle['distance_from_route'] = min_distance
                    affecting_obstacles.append(obstacle)
            
            # Sort by severity and distance
            affecting_obstacles.sort(key=lambda x: (x['severity'], x['distance_from_route']), reverse=True)
            
            print(f"🛣️ Found {len(affecting_obstacles)} obstacles affecting route")
            return affecting_obstacles
            
        except Exception as e:
            print(f"❌ Error getting route obstacles: {str(e)}")
            return []
    
    async def _upload_image(self, obstacle_id: str, image_base64: str) -> str:
        """Upload base64 image to Cloud Storage and return public URL"""
        
        try:
            # Decode base64 image
            image_data = base64.b64decode(image_base64)
            
            # Open and process image
            image = Image.open(io.BytesIO(image_data))
            
            # Resize if too large (max 1024x1024)
            if image.width > 1024 or image.height > 1024:
                image.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
            
            # Convert to JPEG and compress
            output_buffer = io.BytesIO()
            if image.mode in ("RGBA", "P"):
                image = image.convert("RGB")
            image.save(output_buffer, format="JPEG", quality=85, optimize=True)
            
            # Upload to Cloud Storage
            blob_name = f"obstacles/{obstacle_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.jpg"
            bucket = self.storage_client.bucket(self.bucket_name)
            blob = bucket.blob(blob_name)
            
            blob.upload_from_string(
                output_buffer.getvalue(),
                content_type="image/jpeg"
            )
            
            # Return public URL
            public_url = f"https://storage.googleapis.com/{self.bucket_name}/{blob_name}"
            print(f"📷 Uploaded image: {public_url}")
            
            return public_url
            
        except Exception as e:
            print(f"❌ Error uploading image: {str(e)}")
            return None
    
    async def _reverse_geocode(self, latitude: float, longitude: float) -> str:
        """Get human-readable address from coordinates"""
        
        try:
            result = self.gmaps_client.reverse_geocode((latitude, longitude))
            if result:
                return result[0]['formatted_address']
            return f"{latitude:.6f}, {longitude:.6f}"
        except:
            return f"{latitude:.6f}, {longitude:.6f}"
    
    async def _analyze_severity(self, obstacle_type: str, description: str, image_url: Optional[str]) -> int:
        """AI-powered severity analysis using description and image"""
        
        try:
            # Base severity from obstacle type
            base_severity = self.obstacle_types.get(obstacle_type, {}).get("base_severity", 5)
            
            # Analyze description for severity keywords
            severity_keywords = {
                "major": 3, "severe": 3, "large": 2, "huge": 3, "massive": 3,
                "minor": -2, "small": -1, "tiny": -2,
                "blocking": 2, "closed": 3, "impassable": 3,
                "dangerous": 2, "hazardous": 2, "emergency": 3
            }
            
            description_modifier = 0
            description_lower = description.lower()
            
            for keyword, modifier in severity_keywords.items():
                if keyword in description_lower:
                    description_modifier += modifier
            
            # Calculate final severity (1-10 scale)
            final_severity = max(1, min(10, base_severity + description_modifier))
            
            print(f"🤖 AI Severity Analysis: {obstacle_type} = {base_severity} + description({description_modifier}) = {final_severity}")
            
            return final_severity
            
        except Exception as e:
            print(f"❌ Error in severity analysis: {str(e)}")
            return 5  # Default moderate severity
    
    def _calculate_impact_radius(self, obstacle_type: str, severity: int) -> int:
        """Calculate impact radius based on type and severity"""
        
        base_radius = self.obstacle_types.get(obstacle_type, {}).get("impact_radius", 100)
        
        # Scale by severity
        severity_multiplier = 0.5 + (severity / 10.0)  # 0.6 to 1.5 range
        
        return int(base_radius * severity_multiplier)
    
    def _determine_priority(self, obstacle_type: str, severity: int) -> str:
        """Determine priority level based on type and severity"""
        
        critical_types = ["road_closure", "flooding", "accident"]
        
        if obstacle_type in critical_types or severity >= 8:
            return "CRITICAL"
        elif severity >= 6:
            return "HIGH"
        elif severity >= 4:
            return "MEDIUM"
        else:
            return "LOW"
    
    async def _get_weather_conditions(self, latitude: float, longitude: float) -> str:
        """Get current weather conditions for the location"""
        
        try:
            # This would typically call a weather API
            # For now, return a placeholder
            return "Clear"
        except:
            return "Unknown"
    
    def _decode_polyline(self, polyline_str: str) -> List[Tuple[float, float]]:
        """Decode Google Maps polyline string to coordinate list"""
        
        try:
            import polyline
            return polyline.decode(polyline_str)
        except:
            # Fallback: return empty list if polyline library not available
            return []
    
    def _calculate_distance(self, lat1: float, lng1: float, lat2: float, lng2: float) -> float:
        """Calculate distance between two coordinates in meters"""
        
        import math
        
        # Haversine formula
        R = 6371000  # Earth's radius in meters
        
        lat1_rad = math.radians(lat1)
        lat2_rad = math.radians(lat2)
        delta_lat = math.radians(lat2 - lat1)
        delta_lng = math.radians(lng2 - lng1)
        
        a = (math.sin(delta_lat / 2) ** 2 + 
             math.cos(lat1_rad) * math.cos(lat2_rad) * 
             math.sin(delta_lng / 2) ** 2)
        
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        
        return R * c
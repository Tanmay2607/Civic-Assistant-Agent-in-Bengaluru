"""
Parking Finder Agent
Uses Google Places API to find parking spots near destinations with detailed information
"""

import googlemaps
import json
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import math

class ParkingFinderAgent:
    """
    Advanced parking finder agent that searches for parking options near destinations
    """
    
    def __init__(self, api_key: str):
        self.gmaps_client = googlemaps.Client(key=api_key)
        
        # Parking type mappings and priorities
        self.parking_types = {
            "parking": {"priority": 1, "icon": "🅿️", "description": "General Parking"},
            "park": {"priority": 2, "icon": "🏞️", "description": "Park (Street Parking)"},
            "shopping_mall": {"priority": 3, "icon": "🛒", "description": "Mall Parking"},
            "hospital": {"priority": 4, "icon": "🏥", "description": "Hospital Parking"},
            "airport": {"priority": 5, "icon": "✈️", "description": "Airport Parking"},
            "train_station": {"priority": 6, "icon": "🚂", "description": "Station Parking"},
            "university": {"priority": 7, "icon": "🎓", "description": "University Parking"},
            "establishment": {"priority": 8, "icon": "🏢", "description": "Building Parking"}
        }
        
        # Parking cost estimates (INR per hour) for Bengaluru
        self.cost_estimates = {
            "free": {"min": 0, "max": 0, "description": "Free"},
            "street": {"min": 10, "max": 30, "description": "₹10-30/hr"},
            "paid": {"min": 20, "max": 50, "description": "₹20-50/hr"},
            "mall": {"min": 0, "max": 20, "description": "Free-₹20/hr"},
            "premium": {"min": 50, "max": 100, "description": "₹50-100/hr"},
            "airport": {"min": 100, "max": 200, "description": "₹100-200/hr"}
        }
    
    async def find_parking_near_destination(self, 
                                          destination_lat: float, 
                                          destination_lng: float,
                                          destination_name: str = "",
                                          radius: int = 1000,
                                          max_results: int = 15) -> List[Dict]:
        """
        Find parking options near a destination
        
        Args:
            destination_lat: Latitude of destination
            destination_lng: Longitude of destination
            destination_name: Name of destination for context
            radius: Search radius in meters (default 1km)
            max_results: Maximum number of results to return
            
        Returns:
            List of parking options with detailed information
        """
        
        try:
            destination_location = (destination_lat, destination_lng)
            parking_spots = []
            
            # Search for different types of parking
            search_types = [
                "parking",
                "park",  # Some parks allow parking
                "shopping_mall",
                "hospital", 
                "establishment"
            ]
            
            for place_type in search_types:
                try:
                    # Use Places Nearby API
                    places_result = self.gmaps_client.places_nearby(
                        location=destination_location,
                        radius=radius,
                        type=place_type,
                        keyword="parking" if place_type != "parking" else None
                    )
                    
                    for place in places_result.get('results', []):
                        parking_info = await self._process_parking_place(
                            place, destination_location, destination_name
                        )
                        if parking_info:
                            parking_spots.append(parking_info)
                            
                except Exception as e:
                    print(f"⚠️ Error searching {place_type}: {str(e)}")
                    continue
            
            # Remove duplicates and sort by distance
            unique_spots = self._remove_duplicate_spots(parking_spots)
            sorted_spots = sorted(unique_spots, key=lambda x: x['distance_meters'])
            
            # Limit results and add rankings
            final_spots = sorted_spots[:max_results]
            
            for i, spot in enumerate(final_spots):
                spot['rank'] = i + 1
                spot['recommendation_score'] = self._calculate_recommendation_score(spot)
            
            print(f"🅿️ Found {len(final_spots)} parking options near {destination_name}")
            return final_spots
            
        except Exception as e:
            print(f"❌ Error finding parking: {str(e)}")
            return []
    
    async def _process_parking_place(self, place: Dict, destination_location: Tuple, destination_name: str) -> Optional[Dict]:
        """Process a single parking place and extract relevant information"""
        
        try:
            # Extract basic information
            place_id = place.get('place_id')
            name = place.get('name', 'Unknown Parking')
            location = place.get('geometry', {}).get('location', {})
            lat, lng = location.get('lat'), location.get('lng')
            
            if not lat or not lng:
                return None
            
            # Calculate distance from destination
            distance_meters = self._calculate_distance(
                destination_location[0], destination_location[1], lat, lng
            )
            
            # Get detailed place information
            place_details = await self._get_place_details(place_id)
            
            # Determine parking characteristics
            parking_type = self._classify_parking_type(place, place_details)
            cost_estimate = self._estimate_parking_cost(place, place_details, parking_type)
            availability_info = self._assess_availability(place, place_details)
            
            # Extract address and contact info
            address = place_details.get('formatted_address', place.get('vicinity', ''))
            phone = place_details.get('formatted_phone_number', '')
            website = place_details.get('website', '')
            
            # Get ratings and reviews
            rating = place.get('rating', 0)
            user_ratings_total = place.get('user_ratings_total', 0)
            
            # Calculate walking time to destination
            walking_time = self._estimate_walking_time(distance_meters)
            
            # Determine if it's currently open
            opening_hours = place_details.get('opening_hours', {})
            is_open_now = opening_hours.get('open_now', None)
            
            parking_info = {
                'place_id': place_id,
                'name': name,
                'latitude': lat,
                'longitude': lng,
                'address': address,
                'phone': phone,
                'website': website,
                'distance_meters': distance_meters,
                'distance_text': self._format_distance(distance_meters),
                'walking_time': walking_time,
                'parking_type': parking_type,
                'cost_estimate': cost_estimate,
                'availability': availability_info,
                'rating': rating,
                'user_ratings_total': user_ratings_total,
                'is_open_now': is_open_now,
                'opening_hours': opening_hours.get('weekday_text', []),
                'types': place.get('types', []),
                'price_level': place.get('price_level'),
                'photos': self._extract_photo_urls(place.get('photos', [])),
                'destination_name': destination_name,
                'last_updated': datetime.utcnow().isoformat()
            }
            
            return parking_info
            
        except Exception as e:
            print(f"⚠️ Error processing parking place: {str(e)}")
            return None
    
    async def _get_place_details(self, place_id: str) -> Dict:
        """Get detailed information about a place"""
        
        try:
            details_result = self.gmaps_client.place(
                place_id=place_id,
                fields=[
                    'formatted_address', 'formatted_phone_number', 'website',
                    'opening_hours', 'price_level', 'reviews', 'types'
                ]
            )
            return details_result.get('result', {})
        except Exception as e:
            print(f"⚠️ Error getting place details: {str(e)}")
            return {}
    
    def _classify_parking_type(self, place: Dict, details: Dict) -> Dict:
        """Classify the type of parking based on place information"""
        
        place_types = place.get('types', [])
        name = place.get('name', '').lower()
        
        # Check for specific parking indicators
        if 'parking' in place_types:
            if 'paid' in name or 'premium' in name:
                return self.parking_types['parking'].copy()
            return self.parking_types['parking'].copy()
        
        # Check other categories
        for place_type in place_types:
            if place_type in self.parking_types:
                return self.parking_types[place_type].copy()
        
        # Default classification
        return self.parking_types['establishment'].copy()
    
    def _estimate_parking_cost(self, place: Dict, details: Dict, parking_type: Dict) -> Dict:
        """Estimate parking cost based on place characteristics"""
        
        name = place.get('name', '').lower()
        place_types = place.get('types', [])
        price_level = place.get('price_level')
        
        # Determine cost category
        if 'free' in name or 'complimentary' in name:
            cost_category = 'free'
        elif 'airport' in place_types or 'airport' in name:
            cost_category = 'airport'
        elif 'shopping_mall' in place_types or 'mall' in name:
            cost_category = 'mall'
        elif price_level and price_level >= 3:
            cost_category = 'premium'
        elif 'street' in name or 'road' in name:
            cost_category = 'street'
        else:
            cost_category = 'paid'
        
        cost_info = self.cost_estimates[cost_category].copy()
        cost_info['category'] = cost_category
        
        return cost_info
    
    def _assess_availability(self, place: Dict, details: Dict) -> Dict:
        """Assess parking availability based on various factors"""
        
        current_hour = datetime.now().hour
        rating = place.get('rating', 0)
        user_ratings_total = place.get('user_ratings_total', 0)
        
        # Basic availability assessment
        if current_hour < 8 or current_hour > 22:
            availability = "High"
            confidence = 0.8
        elif 9 <= current_hour <= 18:
            availability = "Medium"
            confidence = 0.6
        else:
            availability = "Low"
            confidence = 0.4
        
        # Adjust based on popularity
        if user_ratings_total > 500:
            if availability == "High":
                availability = "Medium"
            elif availability == "Medium":
                availability = "Low"
            confidence -= 0.1
        
        return {
            'status': availability,
            'confidence': max(0.1, confidence),
            'last_updated': datetime.utcnow().isoformat(),
            'factors': f"Based on time ({current_hour}:00) and popularity"
        }
    
    def _calculate_distance(self, lat1: float, lng1: float, lat2: float, lng2: float) -> float:
        """Calculate distance between two points in meters"""
        
        # Haversine formula
        R = 6371000  # Earth's radius in meters
        
        lat1_rad = math.radians(lat1)
        lat2_rad = math.radians(lat2)
        delta_lat = math.radians(lat2 - lat1)
        delta_lng = math.radians(lng2 - lng1)
        
        a = (math.sin(delta_lat / 2) ** 2 + 
             math.cos(lat1_rad) * math.cos(lat2_rad) * 
             math.sin(delta_lng / 2) ** 2)
        
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        
        return R * c
    
    def _format_distance(self, distance_meters: float) -> str:
        """Format distance for display"""
        
        if distance_meters < 1000:
            return f"{int(distance_meters)}m"
        else:
            return f"{distance_meters/1000:.1f}km"
    
    def _estimate_walking_time(self, distance_meters: float) -> Dict:
        """Estimate walking time based on distance"""
        
        # Average walking speed: 5 km/h = 1.39 m/s
        walking_speed = 1.39
        time_seconds = distance_meters / walking_speed
        
        if time_seconds < 60:
            time_text = f"{int(time_seconds)} seconds"
        else:
            time_minutes = time_seconds / 60
            time_text = f"{int(time_minutes)} minutes"
        
        return {
            'seconds': int(time_seconds),
            'text': time_text,
            'category': 'short' if time_seconds < 300 else 'medium' if time_seconds < 600 else 'long'
        }
    
    def _extract_photo_urls(self, photos: List[Dict]) -> List[str]:
        """Extract photo URLs from place photos"""
        
        photo_urls = []
        for photo in photos[:3]:  # Limit to 3 photos
            try:
                photo_reference = photo.get('photo_reference')
                if photo_reference:
                    # Construct photo URL
                    photo_url = f"https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference={photo_reference}&key={self.gmaps_client.key}"
                    photo_urls.append(photo_url)
            except Exception as e:
                continue
        
        return photo_urls
    
    def _remove_duplicate_spots(self, parking_spots: List[Dict]) -> List[Dict]:
        """Remove duplicate parking spots based on location"""
        
        unique_spots = []
        seen_locations = set()
        
        for spot in parking_spots:
            # Create a location key (rounded to avoid minor coordinate differences)
            location_key = (
                round(spot['latitude'], 4),
                round(spot['longitude'], 4)
            )
            
            if location_key not in seen_locations:
                seen_locations.add(location_key)
                unique_spots.append(spot)
        
        return unique_spots
    
    def _calculate_recommendation_score(self, spot: Dict) -> float:
        """Calculate a recommendation score for the parking spot"""
        
        score = 0.0
        
        # Distance factor (closer is better)
        distance_score = max(0, 1 - (spot['distance_meters'] / 1000))  # Normalize to 1km
        score += distance_score * 0.4
        
        # Cost factor (cheaper is better)
        cost_max = spot['cost_estimate']['max']
        if cost_max == 0:
            cost_score = 1.0  # Free parking
        else:
            cost_score = max(0, 1 - (cost_max / 100))  # Normalize to ₹100/hr
        score += cost_score * 0.3
        
        # Availability factor
        availability = spot['availability']['status']
        availability_score = {'High': 1.0, 'Medium': 0.6, 'Low': 0.3}.get(availability, 0.5)
        score += availability_score * 0.2
        
        # Rating factor
        rating = spot.get('rating', 0)
        rating_score = rating / 5.0 if rating > 0 else 0.5
        score += rating_score * 0.1
        
        return round(score, 2)
    
    async def get_parking_recommendations(self, 
                                        destination_lat: float, 
                                        destination_lng: float,
                                        destination_name: str = "",
                                        preferences: Dict = None) -> Dict:
        """
        Get comprehensive parking recommendations with analysis
        
        Args:
            destination_lat: Latitude of destination
            destination_lng: Longitude of destination  
            destination_name: Name of destination
            preferences: User preferences (cost, distance, etc.)
            
        Returns:
            Comprehensive parking analysis and recommendations
        """
        
        # Get parking options
        parking_options = await self.find_parking_near_destination(
            destination_lat, destination_lng, destination_name
        )
        
        if not parking_options:
            return {
                'success': False,
                'message': 'No parking options found near destination',
                'destination': destination_name,
                'recommendations': []
            }
        
        # Categorize recommendations
        free_parking = [p for p in parking_options if p['cost_estimate']['max'] == 0]
        cheap_parking = [p for p in parking_options if 0 < p['cost_estimate']['max'] <= 30]
        nearby_parking = [p for p in parking_options if p['distance_meters'] <= 300]
        rated_parking = [p for p in parking_options if p['rating'] >= 4.0]
        
        # Generate insights
        insights = self._generate_parking_insights(parking_options, destination_name)
        
        return {
            'success': True,
            'destination': destination_name,
            'total_options': len(parking_options),
            'recommendations': {
                'best_overall': parking_options[0] if parking_options else None,
                'free_options': free_parking[:3],
                'budget_friendly': cheap_parking[:3],
                'nearby_options': nearby_parking[:3],
                'highly_rated': rated_parking[:3]
            },
            'all_options': parking_options,
            'insights': insights,
            'search_timestamp': datetime.utcnow().isoformat()
        }
    
    def _generate_parking_insights(self, parking_options: List[Dict], destination_name: str) -> List[str]:
        """Generate helpful insights about parking options"""
        
        insights = []
        
        if not parking_options:
            return ["No parking options found in the area."]
        
        # Distance insights
        avg_distance = sum(p['distance_meters'] for p in parking_options) / len(parking_options)
        if avg_distance < 300:
            insights.append(f"🚶 Great news! Most parking is within a 3-minute walk of {destination_name}")
        elif avg_distance < 600:
            insights.append(f"🚶‍♂️ Parking options are moderately close, with average 5-minute walk to {destination_name}")
        else:
            insights.append(f"🚶‍♀️ Parking may require a longer walk to reach {destination_name}")
        
        # Cost insights
        free_options = [p for p in parking_options if p['cost_estimate']['max'] == 0]
        if free_options:
            insights.append(f"💰 Found {len(free_options)} free parking option(s) nearby")
        
        avg_cost = sum(p['cost_estimate']['max'] for p in parking_options) / len(parking_options)
        if avg_cost < 25:
            insights.append("💵 Parking costs are budget-friendly in this area")
        elif avg_cost > 75:
            insights.append("💳 This area has premium parking rates")
        
        # Availability insights
        high_availability = [p for p in parking_options if p['availability']['status'] == 'High']
        if len(high_availability) > len(parking_options) * 0.6:
            insights.append("✅ Good parking availability expected at this time")
        elif len(high_availability) < len(parking_options) * 0.3:
            insights.append("⚠️ Limited parking availability - consider arriving early")
        
        # Quality insights
        rated_options = [p for p in parking_options if p['rating'] > 0]
        if rated_options:
            avg_rating = sum(p['rating'] for p in rated_options) / len(rated_options)
            if avg_rating >= 4.0:
                insights.append("⭐ Parking facilities in this area are well-rated")
            elif avg_rating < 3.0:
                insights.append("⚠️ Some parking facilities have mixed reviews")
        
        return insights
import logging
import random
from datetime import datetime, timedelta
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RouteObstacleAgent:
    def __init__(self):
        logger.info("Initializing RouteObstacleAgent...")
        self.name = "route_obstacle_agent"
        
        # Common Bengaluru traffic hotspots and obstacles
        self.traffic_hotspots = [
            "Silk Board Junction", "Electronic City Toll", "Marathahalli Bridge",
            "Hosur Road", "Outer Ring Road", "KR Puram", "Whitefield Main Road",
            "Sarjapur Road", "Bannerghatta Road", "Hebbal Flyover"
        ]
        
        self.construction_zones = [
            "Metro Construction - MG Road", "Flyover Work - Koramangala", 
            "Road Widening - Sarjapur", "Metro Work - Whitefield",
            "Bridge Construction - Marathahalli"
        ]
        
        logger.info("✓ Route Obstacle Agent initialized")
    
    async def get_live_traffic_data(self, route_points):
        """Get real-time traffic conditions along the route"""
        try:
            logger.info(f"Analyzing traffic conditions for route: {route_points}")
            
            traffic_data = self._analyze_route_traffic(route_points)
            
            logger.info("✓ Traffic analysis completed")
            return traffic_data
            
        except Exception as e:
            logger.error(f"✗ Failed to get traffic data: {e}")
            return self._get_fallback_traffic_data(route_points)
    
    async def get_route_obstacles(self, origin, destination):
        """Identify obstacles, construction, accidents on the route"""
        try:
            logger.info(f"Scanning for obstacles on route: {origin} -> {destination}")
            
            obstacles = self._scan_route_obstacles(origin, destination)
            
            logger.info("✓ Obstacle scan completed")
            return obstacles
            
        except Exception as e:
            logger.error(f"✗ Failed to scan obstacles: {e}")
            return self._get_fallback_obstacles()
    
    async def get_alternative_routes(self, origin, destination, avoid_obstacles):
        """Find alternative routes avoiding specific obstacles"""
        try:
            logger.info(f"Finding alternative routes avoiding: {avoid_obstacles}")
            
            alternatives = self._generate_alternative_routes(origin, destination, avoid_obstacles)
            
            logger.info("✓ Alternative routes generated")
            return alternatives
            
        except Exception as e:
            logger.error(f"✗ Failed to find alternatives: {e}")
            return self._get_fallback_alternatives(origin, destination)
    
    def _analyze_route_traffic(self, route_points):
        """Analyze traffic conditions along route points"""
        current_hour = datetime.now().hour
        is_peak_hour = (7 <= current_hour <= 10) or (17 <= current_hour <= 20)
        
        traffic_segments = []
        for i, point in enumerate(route_points):
            # Simulate traffic analysis
            if is_peak_hour:
                congestion_level = random.choice(['heavy', 'moderate', 'heavy'])
                delay_minutes = random.randint(10, 30)
            else:
                congestion_level = random.choice(['light', 'moderate', 'light'])
                delay_minutes = random.randint(2, 10)
            
            # Check if point is near known hotspots
            is_hotspot = any(hotspot.lower() in point.lower() for hotspot in self.traffic_hotspots)
            if is_hotspot:
                congestion_level = 'heavy'
                delay_minutes += random.randint(5, 15)
            
            segment = {
                'segment_id': i + 1,
                'location': point,
                'congestion_level': congestion_level,
                'estimated_delay_minutes': delay_minutes,
                'is_hotspot': is_hotspot,
                'alternative_available': random.choice([True, False]),
                'last_updated': datetime.now().isoformat()
            }
            traffic_segments.append(segment)
        
        total_delay = sum(seg['estimated_delay_minutes'] for seg in traffic_segments)
        
        return {
            'route_points': route_points,
            'traffic_segments': traffic_segments,
            'total_estimated_delay': total_delay,
            'peak_hour': is_peak_hour,
            'overall_traffic_level': self._calculate_overall_traffic_level(traffic_segments),
            'recommendations': self._generate_traffic_recommendations(traffic_segments, is_peak_hour),
            'timestamp': datetime.now().isoformat()
        }
    
    def _scan_route_obstacles(self, origin, destination):
        """Scan for various obstacles on the route"""
        obstacles = []
        
        # Simulate obstacle detection
        obstacle_types = ['construction', 'accident', 'road_closure', 'event', 'flooding']
        
        for _ in range(random.randint(0, 3)):  # 0-3 obstacles
            obstacle = {
                'id': f"OBS_{random.randint(1000, 9999)}",
                'type': random.choice(obstacle_types),
                'location': random.choice(self.traffic_hotspots),
                'severity': random.choice(['low', 'medium', 'high']),
                'estimated_delay': random.randint(5, 25),
                'expected_duration': random.randint(30, 180),  # minutes
                'alternative_route_available': random.choice([True, False]),
                'reported_time': (datetime.now() - timedelta(minutes=random.randint(5, 60))).isoformat(),
                'description': self._generate_obstacle_description()
            }
            obstacles.append(obstacle)
        
        # Always include some construction (common in Bengaluru)
        if random.random() > 0.3:  # 70% chance
            construction = {
                'id': f"CONST_{random.randint(1000, 9999)}",
                'type': 'construction',
                'location': random.choice(self.construction_zones),
                'severity': 'medium',
                'estimated_delay': random.randint(10, 20),
                'expected_duration': random.randint(120, 480),  # 2-8 hours
                'alternative_route_available': True,
                'reported_time': datetime.now().isoformat(),
                'description': 'Ongoing construction work - lane restrictions in effect'
            }
            obstacles.append(construction)
        
        return {
            'route': f"{origin} -> {destination}",
            'obstacles_found': len(obstacles),
            'obstacles': obstacles,
            'total_estimated_delay': sum(obs['estimated_delay'] for obs in obstacles),
            'recommendations': self._generate_obstacle_recommendations(obstacles),
            'scan_timestamp': datetime.now().isoformat()
        }
    
    def _generate_alternative_routes(self, origin, destination, avoid_obstacles):
        """Generate alternative route options"""
        alternatives = []
        
        # Generate practical alternative routes for Bengaluru
        route_alternatives = [
            {
                'route_id': 'ALT_1',
                'route_name': 'Outer Ring Road Route',
                'origin': origin,
                'destination': destination,
                'estimated_time_minutes': 45,  # Typical for longer but less congested route
                'estimated_distance_km': 25,
                'avoids_obstacles': len(avoid_obstacles) if avoid_obstacles else 0,
                'traffic_level': 'light',
                'route_type': 'highway',
                'toll_required': True,
                'road_quality': 'excellent',
                'scenic_route': False,
                'generated_time': datetime.now().isoformat()
            },
            {
                'route_id': 'ALT_2',
                'route_name': 'Inner City Route',
                'origin': origin,
                'destination': destination,
                'estimated_time_minutes': 35,  # Shorter but potentially more traffic
                'estimated_distance_km': 18,
                'avoids_obstacles': len(avoid_obstacles) if avoid_obstacles else 0,
                'traffic_level': 'moderate',
                'route_type': 'arterial',
                'toll_required': False,
                'road_quality': 'good',
                'scenic_route': False,
                'generated_time': datetime.now().isoformat()
            }
        ]
        
        alternatives = route_alternatives[:2]  # Return 2 alternatives
        
        return {
            'origin': origin,
            'destination': destination,
            'alternatives_found': len(alternatives),
            'alternatives': alternatives,
            'obstacles_avoided': avoid_obstacles or [],
            'recommendation': alternatives[0] if alternatives else None,  # Best alternative
            'timestamp': datetime.now().isoformat()
        }
    
    def _calculate_overall_traffic_level(self, segments):
        """Calculate overall traffic level from segments"""
        heavy_count = sum(1 for seg in segments if seg['congestion_level'] == 'heavy')
        if heavy_count >= len(segments) / 2:
            return 'heavy'
        elif heavy_count > 0:
            return 'moderate'
        else:
            return 'light'
    
    def _generate_traffic_recommendations(self, segments, is_peak_hour):
        """Generate traffic-based recommendations"""
        recommendations = []
        
        if is_peak_hour:
            recommendations.append("Peak hour detected - consider delaying travel if possible")
        
        heavy_segments = [seg for seg in segments if seg['congestion_level'] == 'heavy']
        if heavy_segments:
            recommendations.append(f"Heavy traffic detected at {len(heavy_segments)} locations")
            recommendations.append("Consider using alternative routes or public transport")
        
        hotspot_segments = [seg for seg in segments if seg['is_hotspot']]
        if hotspot_segments:
            recommendations.append("Route passes through known traffic hotspots")
        
        return recommendations
    
    def _generate_obstacle_description(self):
        """Generate realistic obstacle descriptions"""
        descriptions = [
            "Minor accident reported - vehicles being cleared",
            "Road maintenance in progress - single lane traffic",
            "Water logging due to recent rains",
            "Vehicle breakdown blocking one lane",
            "Traffic police checking - expect delays",
            "Event causing increased traffic volume",
            "Pothole repair work ongoing"
        ]
        return random.choice(descriptions)
    
    def _generate_obstacle_recommendations(self, obstacles):
        """Generate recommendations based on obstacles"""
        recommendations = []
        
        if not obstacles:
            recommendations.append("No major obstacles detected on primary route")
            return recommendations
        
        high_severity = [obs for obs in obstacles if obs['severity'] == 'high']
        if high_severity:
            recommendations.append("High severity obstacles detected - strongly recommend alternative route")
        
        construction_obstacles = [obs for obs in obstacles if obs['type'] == 'construction']
        if construction_obstacles:
            recommendations.append("Construction zones ahead - allow extra travel time")
        
        total_delay = sum(obs['estimated_delay'] for obs in obstacles)
        if total_delay > 20:
            recommendations.append(f"Total estimated delay: {total_delay} minutes - consider alternative timing")
        
        return recommendations
    
    def _get_fallback_traffic_data(self, route_points):
        """Fallback traffic data when analysis fails"""
        return {
            'route_points': route_points,
            'traffic_segments': [{'location': point, 'congestion_level': 'moderate', 'estimated_delay_minutes': 5} for point in route_points],
            'total_estimated_delay': 5 * len(route_points),
            'overall_traffic_level': 'moderate',
            'recommendations': ['Unable to get live traffic data - allow extra time'],
            'timestamp': datetime.now().isoformat(),
            'note': 'Fallback traffic data'
        }
    
    def _get_fallback_obstacles(self):
        """Fallback obstacle data"""
        return {
            'obstacles_found': 0,
            'obstacles': [],
            'total_estimated_delay': 0,
            'recommendations': ['No obstacle data available - drive carefully'],
            'scan_timestamp': datetime.now().isoformat(),
            'note': 'Fallback obstacle data'
        }
    
    def _get_fallback_alternatives(self, origin, destination):
        """Fallback alternative routes"""
        return {
            'origin': origin,
            'destination': destination,
            'alternatives_found': 1,
            'alternatives': [{
                'route_id': 'FALLBACK_1',
                'route_name': 'Standard Route',
                'estimated_time_minutes': 45,
                'traffic_level': 'moderate'
            }],
            'timestamp': datetime.now().isoformat(),
            'note': 'Fallback route data'
        }
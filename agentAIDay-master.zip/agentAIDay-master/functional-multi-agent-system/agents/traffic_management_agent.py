# Add logging for debugging
import logging
import os
import sys

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Validate imports
try:
    logger.info("Attempting to import google.adk...")
    from google.adk import Agent
    logger.info("✓ google.adk imported successfully")
except ImportError as e:
    logger.error(f"✗ Failed to import google.adk: {e}")
    # Fallback to a basic Agent class
    class Agent:
        def __init__(self, name=None):
            self.name = name
            logger.info(f"Using fallback Agent class for {name}")

try:
    import googlemaps
    logger.info("✓ googlemaps imported successfully")
except ImportError as e:
    logger.error(f"✗ Failed to import googlemaps: {e}")
    sys.exit(1)

try:
    from google.cloud import pubsub_v1
    logger.info("✓ google.cloud.pubsub_v1 imported successfully")
except ImportError as e:
    logger.error(f"✗ Failed to import google.cloud.pubsub_v1: {e}")

try:
    import vertexai
    from vertexai.generative_models import GenerativeModel
    logger.info("✓ vertexai imported successfully")
except ImportError as e:
    logger.error(f"✗ Failed to import vertexai: {e}")

class TrafficManagementAgent(Agent):
    def __init__(self):
        logger.info("Initializing TrafficManagementAgent...")
        super().__init__(name="traffic_management_agent")
        
        # Validate environment variables and set API key
        maps_api_key = os.environ.get('GOOGLE_MAPS_API_KEY', 'AIzaSyDwtWrBw3YAjEo55GY0jxlhZto8vV3XiAA')
        if not maps_api_key:
            logger.error("✗ GOOGLE_MAPS_API_KEY environment variable not set")
            raise ValueError("GOOGLE_MAPS_API_KEY environment variable is required")
        logger.info(f"✓ Using Google Maps API key: {maps_api_key[:8]}...")
        
        # Initialize Google Maps client (use private field to avoid Pydantic conflicts)
        try:
            self._maps_client = googlemaps.Client(key=maps_api_key)
            logger.info("✓ Google Maps client initialized")
        except Exception as e:
            logger.error(f"✗ Failed to initialize Google Maps client: {e}")
            raise
        
        # Initialize Vertex AI
        try:
            # Set up Vertex AI project (you may need to set these env vars)
            project_id = os.environ.get('GOOGLE_CLOUD_PROJECT')
            location = os.environ.get('GOOGLE_CLOUD_LOCATION', 'us-central1')
            if project_id:
                vertexai.init(project=project_id, location=location)
                logger.info(f"✓ Vertex AI initialized for project {project_id}")
            else:
                logger.warning("⚠ GOOGLE_CLOUD_PROJECT not set, using default Vertex AI settings")
            
            self._model = GenerativeModel("gemini-2.0-flash")
            logger.info("✓ Gemini model initialized")
        except Exception as e:
            logger.error(f"✗ Failed to initialize Vertex AI/Gemini: {e}")
            self._model = None

    async def analyze_route(self, origin, destination):
        """Analyze route using REAL Google Maps data with live traffic"""
        logger.info(f"🚗 Analyzing REAL route from {origin} to {destination}")
        
        try:
            import datetime
            now = datetime.datetime.now()
            
            # Step 1: Make REAL Google Maps Directions API call
            logger.info(f"📡 Making Google Maps Directions API call...")
            
            try:
                # Request with alternatives and traffic data
                directions_result = self._maps_client.directions(
                    origin,
                    destination,
                    mode="driving",
                    departure_time=now,
                    traffic_model="best_guess",
                    alternatives=True  # Get alternative routes
                )
                
                if not directions_result:
                    logger.error("❌ No routes returned from Google Maps API")
                    return {
                        "error": "No route found between these locations",
                        "route": None,
                        "ai_insights": "Please check location names and try again",
                        "travel_time": "Unknown"
                    }
                
                logger.info(f"✅ Google Maps returned {len(directions_result)} route(s)")
                
                # Step 2: Extract REAL traffic data
                primary_route = directions_result[0]
                leg = primary_route['legs'][0]
                
                # Get REAL duration data
                normal_duration = leg['duration']['value']  # seconds in free flow
                duration_text = leg['duration']['text']
                
                # Get REAL traffic-aware duration
                traffic_duration = leg.get('duration_in_traffic', {}).get('value', normal_duration)
                traffic_duration_text = leg.get('duration_in_traffic', {}).get('text', duration_text)
                
                # Calculate REAL delay
                delay_seconds = traffic_duration - normal_duration
                delay_minutes = delay_seconds / 60
                delay_percentage = (delay_seconds / normal_duration) * 100 if normal_duration > 0 else 0
                
                # Get REAL distance
                distance_value = leg['distance']['value']  # meters
                distance_text = leg['distance']['text']
                
                # Extract route details
                start_address = leg['start_address']
                end_address = leg['end_address']
                
                logger.info(f"📊 REAL traffic data extracted:")
                logger.info(f"   Distance: {distance_text} ({distance_value}m)")
                logger.info(f"   Normal time: {duration_text} ({normal_duration}s)")
                logger.info(f"   Current time: {traffic_duration_text} ({traffic_duration}s)")
                logger.info(f"   Traffic delay: {delay_minutes:.1f} minutes ({delay_percentage:.1f}%)")
                
                # Step 3: Analyze traffic conditions based on REAL data
                traffic_condition = self._analyze_real_traffic_condition(delay_percentage, delay_minutes)
                
                # Step 4: Generate AI insights with REAL data
                ai_insights = await self._generate_real_traffic_insights(
                    origin, destination, distance_text, duration_text,
                    traffic_duration_text, delay_minutes, delay_percentage,
                    traffic_condition, len(directions_result)
                )
                
                # Step 5: Return structured REAL data
                return {
                    "route": directions_result,
                    "ai_insights": ai_insights,
                    "travel_time": traffic_duration_text,
                    "traffic_analysis": {
                        "normal_duration": duration_text,
                        "current_duration": traffic_duration_text,
                        "delay_minutes": round(delay_minutes, 1),
                        "delay_percentage": round(delay_percentage, 1),
                        "traffic_condition": traffic_condition,
                        "distance": distance_text,
                        "alternatives_available": len(directions_result) > 1,
                        "data_timestamp": now.isoformat(),
                        "source": "Google Maps Directions API (REAL DATA)"
                    }
                }
                
            except Exception as api_error:
                logger.error(f"❌ Google Maps API Error: {str(api_error)}")
                
                # Provide specific error guidance
                error_msg = str(api_error).upper()
                if "REQUEST_DENIED" in error_msg:
                    guidance = "🔑 API key not authorized. Please enable Directions API in Google Cloud Console."
                elif "ZERO_RESULTS" in error_msg:
                    guidance = "📍 No route found. Please check location names."
                elif "OVER_QUERY_LIMIT" in error_msg:
                    guidance = "📊 API quota exceeded. Check billing in Google Cloud Console."
                elif "INVALID_REQUEST" in error_msg:
                    guidance = "❓ Invalid request. Please check location format."
                else:
                    guidance = "🌐 Check API key permissions and internet connection."
                
                # When API fails, provide mock route data so frontend can still render map
                logger.warning("🔄 Google Maps API failed, generating mock route data for map rendering...")
                mock_route_data = self._create_mock_route_data(origin, destination)
                
                return {
                    "error": f"Google Maps API Error: {str(api_error)}",
                    "route": mock_route_data,  # Provide mock route for map rendering
                    "ai_insights": f"Cannot fetch real traffic data. {guidance} Using estimated route for visualization.",
                    "travel_time": "15-25 minutes (estimated)",
                    "traffic_analysis": {
                        "normal_duration": "15 minutes",
                        "current_duration": "20 minutes (estimated)",
                        "delay_minutes": 5,
                        "delay_percentage": 33,
                        "traffic_condition": "estimated",
                        "distance": "8-12 km (estimated)",
                        "alternatives_available": False,
                        "data_timestamp": now.isoformat(),
                        "source": "Mock data (Google Maps API unavailable)"
                    }
                }
            
        except Exception as e:
            logger.error(f"❌ Route analysis failed: {e}")
            return {
                "error": f"Analysis failed: {str(e)}",
                "route": None,
                "ai_insights": "Unable to analyze route. Please try again.",
                "travel_time": "Unknown"
            }
    
    def _analyze_real_traffic_condition(self, delay_percentage, delay_minutes):
        """Analyze traffic condition based on REAL delay data"""
        if delay_percentage <= 5:
            return "excellent"
        elif delay_percentage <= 15:
            return "good"
        elif delay_percentage <= 25:
            return "moderate"
        elif delay_percentage <= 40:
            return "heavy"
        else:
            return "severe"
    
    async def _generate_real_traffic_insights(self, origin, destination, distance,
                                            normal_time, current_time, delay_minutes,
                                            delay_percentage, condition, num_alternatives):
        """Generate AI insights using REAL traffic data"""
        
        try:
            if self._model:
                traffic_prompt = f"""
                Analyze this REAL traffic data for Bengaluru route:
                
                Route: {origin} → {destination}
                Distance: {distance}
                Normal travel time: {normal_time}
                Current travel time: {current_time}
                Traffic delay: {delay_minutes:.1f} minutes ({delay_percentage:.1f}% slower)
                Traffic condition: {condition}
                Alternative routes available: {num_alternatives - 1}
                
                Provide practical insights:
                1. Current traffic assessment
                2. Departure time recommendations
                3. Route optimization tips
                4. Expected delays and causes
                
                Keep it concise and actionable.
                """
                
                response = self._model.generate_content(traffic_prompt)
                if response and response.text:
                    return response.text
            
            # Fallback insights based on REAL data
            condition_messages = {
                "excellent": "🟢 Excellent traffic conditions!",
                "good": "🟡 Good traffic conditions",
                "moderate": "🟠 Moderate traffic delays",
                "heavy": "🔴 Heavy traffic conditions",
                "severe": "⚫ Severe traffic congestion"
            }
            
            insights = f"""
🚗 REAL TRAFFIC ANALYSIS

{condition_messages.get(condition, "Traffic analysis")}

📊 Current Conditions:
• Distance: {distance}
• Travel time: {current_time} (normally {normal_time})
• Traffic delay: +{delay_minutes:.1f} minutes ({delay_percentage:.1f}% slower)

💡 Recommendations:
"""
            
            if delay_percentage <= 15:
                insights += "• Good time to travel - minimal delays expected\n"
            elif delay_percentage <= 25:
                insights += "• Consider leaving 10-15 minutes earlier\n"
            else:
                insights += "• Significant delays - consider alternative timing or routes\n"
            
            if num_alternatives > 1:
                insights += f"• {num_alternatives - 1} alternative route(s) available\n"
            
            insights += "• Check live traffic updates before departure\n"
            insights += f"• Data updated: {datetime.datetime.now().strftime('%H:%M')}"
            
            return insights
            
        except Exception as e:
            logger.error(f"AI insights generation failed: {e}")
            return f"Traffic delay: +{delay_minutes:.1f} minutes. Current conditions: {condition}."
    
    def _create_mock_route_data(self, origin, destination):
        """Create mock route data for map rendering when Google Maps API fails"""
        import datetime
        
        logger.info(f"🎭 Creating mock route data for {origin} -> {destination}")
        
        # Create realistic mock route data that exactly mimics Google Maps Directions API response
        mock_route = [{
            "bounds": {
                "northeast": {"lat": 12.9716, "lng": 77.5946},
                "southwest": {"lat": 12.9352, "lng": 77.6245}
            },
            "copyrights": "Mock data for development",
            "legs": [{
                "distance": {
                    "text": "8.5 km",
                    "value": 8500
                },
                "duration": {
                    "text": "20 mins",
                    "value": 1200
                },
                "duration_in_traffic": {
                    "text": "25 mins",
                    "value": 1500
                },
                "end_address": f"{destination}, Bengaluru, Karnataka, India",
                "end_location": {"lat": 12.9352, "lng": 77.6245},
                "start_address": f"{origin}, Bengaluru, Karnataka, India",
                "start_location": {"lat": 12.9716, "lng": 77.5946},
                "steps": [
                    {
                        "distance": {"text": "2.1 km", "value": 2100},
                        "duration": {"text": "5 mins", "value": 300},
                        "end_location": {"lat": 12.9616, "lng": 77.6046},
                        "html_instructions": f"Head southeast from {origin}",
                        "polyline": {"points": "mock_polyline_segment_1"},
                        "start_location": {"lat": 12.9716, "lng": 77.5946},
                        "travel_mode": "DRIVING",
                        "maneuver": "straight"
                    },
                    {
                        "distance": {"text": "4.2 km", "value": 4200},
                        "duration": {"text": "8 mins", "value": 480},
                        "end_location": {"lat": 12.9452, "lng": 77.6145},
                        "html_instructions": "Continue straight",
                        "polyline": {"points": "mock_polyline_segment_2"},
                        "start_location": {"lat": 12.9616, "lng": 77.6046},
                        "travel_mode": "DRIVING",
                        "maneuver": "straight"
                    },
                    {
                        "distance": {"text": "2.2 km", "value": 2200},
                        "duration": {"text": "7 mins", "value": 420},
                        "end_location": {"lat": 12.9352, "lng": 77.6245},
                        "html_instructions": f"Arrive at {destination}",
                        "polyline": {"points": "mock_polyline_segment_3"},
                        "start_location": {"lat": 12.9452, "lng": 77.6145},
                        "travel_mode": "DRIVING"
                    }
                ],
                "traffic_speed_entry": [],
                "via_waypoint": []
            }],
            "overview_polyline": {
                "points": "mock_encoded_polyline_data_for_overview"
            },
            "summary": "Mock Route via Main Roads",
            "warnings": ["This is mock route data for development purposes"],
            "waypoint_order": [],
            "fare": None,
            "geocoded_waypoints": [
                {
                    "geocoder_status": "OK",
                    "place_id": "mock_place_id_origin",
                    "types": ["premise"]
                },
                {
                    "geocoder_status": "OK",
                    "place_id": "mock_place_id_destination",
                    "types": ["premise"]
                }
            ]
        }]
        
        logger.info(f"✅ Mock route data created successfully")
        return mock_route
    
    async def detect_incident(self, traffic_data):
        logger.info(f"Detecting incidents in traffic data: {traffic_data}")
        
        try:
            # ACTUAL incident detection logic
            congestion_level = traffic_data.get('congestion_level', 0)
            logger.info(f"Congestion level: {congestion_level}")
            
            if congestion_level > 0.8:
                alert = await self.create_alert("High congestion detected", traffic_data)
                await self.notify_emergency_agent(alert)
                logger.info("✓ High congestion alert created and sent")
                return alert
            
            logger.info("No incidents detected")
            return None
            
        except Exception as e:
            logger.error(f"✗ Incident detection failed: {e}")
            return None
    
    async def create_alert(self, message, data=None):
        """Create an alert with timestamp and relevant data"""
        import time
        
        alert = {
            "id": f"ALERT_{int(time.time())}",
            "timestamp": time.time(),
            "message": message,
            "agent": self.name,
            "data": data or {},
            "status": "active"
        }
        
        logger.info(f"Created alert: {alert['id']} - {message}")
        return alert
    
    async def notify_emergency_agent(self, alert):
        """Notify emergency response agent about an alert"""
        try:
            # In a real implementation, this would use Pub/Sub or direct API calls
            logger.info(f"Notifying emergency agent about alert: {alert['id']}")
            
            # Simulate notification (replace with actual Pub/Sub or API call)
            notification = {
                "target_agent": "emergency_response_agent",
                "alert": alert,
                "priority": "high" if "High congestion" in alert['message'] else "medium"
            }
            
            logger.info(f"✓ Emergency agent notified: {notification}")
            return True
            
        except Exception as e:
            logger.error(f"✗ Failed to notify emergency agent: {e}")
            return False
    
    async def request_from_agent(self, agent_name, request_data):
        """Make a request to another agent"""
        try:
            logger.info(f"Making request to {agent_name}: {request_data}")
            
            # In a real implementation, this would use inter-agent communication
            # For now, return a mock response
            response = {
                "agent": agent_name,
                "request": request_data,
                "response": "Mock response from " + agent_name,
                "status": "success"
            }
            
            logger.info(f"✓ Request to {agent_name} completed")
            return response
            
        except Exception as e:
            logger.error(f"✗ Request to {agent_name} failed: {e}")
            return {"error": str(e), "status": "failed"}

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import logging
import asyncio
import googlemaps
from agents.traffic_management_agent import TrafficManagementAgent
from agents.emergency_response_agent import EmergencyResponseAgent
from agents.master_route_intelligence_agent import MasterRouteIntelligenceAgent
from agents.weather_agent import WeatherAgent
from agents.route_obstacle_agent import RouteObstacleAgent
from agents.air_quality_agent import AirQualityAgent

# Import parking finder agent
import sys
import os
agents_path = os.path.join(os.path.dirname(__file__), '..', 'agents')
sys.path.append(agents_path)

try:
    from parking_finder_agent import ParkingFinderAgent
    PARKING_AGENT_AVAILABLE = True
    print("✅ ParkingFinderAgent imported successfully")
except ImportError as e:
    print(f"⚠️ ParkingFinderAgent not available: {e}")
    PARKING_AGENT_AVAILABLE = False

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# API Models
class RouteRequest(BaseModel):
    origin: str
    destination: str

class ObstacleAreaRequest(BaseModel):
    north_lat: float = Field(..., ge=-90, le=90, description="Northern boundary latitude")
    south_lat: float = Field(..., ge=-90, le=90, description="Southern boundary latitude")
    east_lng: float = Field(..., ge=-180, le=180, description="Eastern boundary longitude")
    west_lng: float = Field(..., ge=-180, le=180, description="Western boundary longitude")
    include_resolved: bool = Field(False, description="Include resolved obstacles")

class IntelligentRouteRequest(BaseModel):
    origin: str
    destination: str
    transport_mode: str = 'car'  # 'car', 'bike', 'walking'
    prioritize: str = 'time'  # 'time', 'safety', 'health'

class ObstacleResponse(BaseModel):
    success: bool = Field(..., description="Whether the request was successful")
    message: str = Field(..., description="Response message")
    obstacles: Optional[List[Dict[str, Any]]] = Field(None, description="List of obstacles")

class IncidentRequest(BaseModel):
    type: str
    location: str
    description: str

class ParkingRequest(BaseModel):
    destination: str
    radius: int = 1000  # Search radius in meters
    max_results: int = 10

app = FastAPI(
    title="Multi-Agent Traffic Management System",
    description="API for traffic management and emergency response coordination",
    version="1.0.0"
)

# Configure CORS for development
origins = [
    "http://localhost:3000",  # React frontend
    "http://localhost:8000",  # FastAPI docs
    "http://localhost:8006",  # Main API
    "http://localhost:8007",  # Obstacle API
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
    max_age=3600
)

# Initialize agents
traffic_agent = TrafficManagementAgent()
emergency_agent = EmergencyResponseAgent()
weather_agent = WeatherAgent()
air_quality_agent = AirQualityAgent()
master_agent = MasterRouteIntelligenceAgent()

# Initialize obstacle management agent with project configuration
try:
    from obstacle_management_agent import ObstacleManagementAgent
    obstacle_agent = ObstacleManagementAgent(
        project_id="planar-beach-467107-n1",
        dataset_id="traffic_management"
    )
    print("✅ Initialized ObstacleManagementAgent with sample data support")
except Exception as e:
    print(f"⚠️ Error initializing ObstacleManagementAgent: {e}")
    raise

# Initialize parking agent if available
parking_agent = None
if PARKING_AGENT_AVAILABLE:
    try:
        parking_agent = ParkingFinderAgent(api_key="AIzaSyC-VQzmR1aLxXJsFYtYKZN6yyGr_hIxRic")
        print("✅ ParkingFinderAgent initialized successfully")
    except Exception as e:
        print(f"⚠️ Failed to initialize ParkingFinderAgent: {e}")
        parking_agent = None

@app.on_event("startup")
async def startup_event():
    logger.info("Starting Multi-Agent System API")
    logger.info("✓ Traffic Management Agent initialized")
    logger.info("✓ Emergency Response Agent initialized")
    logger.info("✓ Weather Agent initialized")
    logger.info("✓ Route Obstacle Agent initialized")
    logger.info("✓ Air Quality Agent initialized")
    logger.info("✓ Master Route Intelligence Agent initialized")

@app.get("/")
async def root():
    return {
        "status": "healthy",
        "message": "Multi-Agent Traffic Management System API",
        "version": "1.0.0"
    }

@app.post("/api/traffic/route")
async def get_route(request: RouteRequest):
    """Get optimal route with traffic analysis"""
    try:
        logger.info(f"Processing route request: {request.origin} -> {request.destination}")
        result = await traffic_agent.analyze_route(
            request.origin,
            request.destination
        )
        logger.info(f"Route analysis completed successfully")
        return result
    except Exception as e:
        logger.error(f"Route analysis failed: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to analyze route: {str(e)}"
        )

@app.post("/api/emergency/incident")
async def report_incident(request: IncidentRequest):
    """Report and process emergency incident"""
    try:
        logger.info(f"Processing emergency: {request.type} at {request.location}")
        result = await emergency_agent.process_emergency(
            request.type,
            request.location,
            request.description
        )
        logger.info("Emergency processed successfully")
        return result
    except Exception as e:
        logger.error(f"Emergency processing failed: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to process emergency: {str(e)}"
        )

@app.get("/api/agents/status")
async def get_agents_status():
    """Get status of all agent subsystems"""
    try:
        status = {
            "traffic_agent": {
                "status": "active",
                "last_action": "N/A",
                "api_quota": traffic_agent._maps_client.queries_per_second if hasattr(traffic_agent, '_maps_client') else "N/A"
            },
            "emergency_agent": {
                "status": "active",
                "last_action": "N/A",
                "priority_levels": emergency_agent._priority_levels if hasattr(emergency_agent, '_priority_levels') else {}
            },
            "weather_agent": {
                "status": "active",
                "last_action": "N/A",
                "capabilities": ["current_weather", "forecast", "traffic_impact"]
            },
            "obstacle_agent": {
                "status": "active",
                "last_action": "N/A",
                "capabilities": ["live_traffic", "obstacles", "alternatives"]
            },
            "air_quality_agent": {
                "status": "active",
                "last_action": "N/A",
                "capabilities": ["air_quality_monitoring", "health_risk_assessment", "cleaner_routes"]
            },
            "master_agent": {
                "status": "active",
                "last_action": "N/A",
                "capabilities": ["intelligent_routing", "multi_agent_coordination", "risk_analysis", "health_optimization"]
            }
        }
        return status
    except Exception as e:
        logger.error(f"Failed to get agent status: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get agent status: {str(e)}"
        )

# New intelligent route endpoint
@app.post("/api/intelligent/route")
async def get_intelligent_route(request: IntelligentRouteRequest):
    """Get intelligent route analysis using all agents"""
    try:
        logger.info(f"Processing intelligent route request: {request.origin} -> {request.destination} (Mode: {request.transport_mode})")
        
        # Use the master agent for comprehensive analysis
        result = await master_agent.get_intelligent_route(
            request.origin,
            request.destination,
            preferences={
                'prioritize': request.prioritize,
                'transport_mode': request.transport_mode,
                'weather_sensitivity': 'medium',
                'air_quality_priority': request.transport_mode in ['bike', 'walking']
            }
        )
        
        logger.info("Intelligent route analysis completed successfully")
        return result
        
    except Exception as e:
        logger.error(f"Intelligent route analysis failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Air quality endpoint
@app.post("/api/air-quality")
async def get_air_quality(request: IntelligentRouteRequest):
    """Get air quality analysis for route"""
    try:
        logger.info(f"Getting air quality for route: {request.origin} -> {request.destination}")
        
        origin_air_quality = await air_quality_agent.get_air_quality_data(request.origin, request.transport_mode)
        destination_air_quality = await air_quality_agent.get_air_quality_data(request.destination, request.transport_mode)
        route_analysis = await air_quality_agent.get_route_air_quality_analysis(
            request.origin, request.destination, [request.origin, request.destination], request.transport_mode
        )
        
        # Get cleaner alternatives if needed
        cleaner_routes = None
        if route_analysis.get('overall_risk_level') in ['medium', 'high']:
            cleaner_routes = await air_quality_agent.suggest_cleaner_routes(
                request.origin, request.destination, request.transport_mode
            )
        
        return {
            'origin_air_quality': origin_air_quality,
            'destination_air_quality': destination_air_quality,
            'route_analysis': route_analysis,
            'cleaner_alternatives': cleaner_routes,
            'transport_mode': request.transport_mode
        }
        
    except Exception as e:
        logger.error(f"Air quality request failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Weather endpoint
@app.post("/api/weather")
async def get_weather_info(request: RouteRequest):
    """Get weather information for route"""
    try:
        logger.info(f"Getting weather for route: {request.origin} -> {request.destination}")
        
        origin_weather = await weather_agent.get_current_weather(request.origin)
        destination_weather = await weather_agent.get_current_weather(request.destination)
        forecast = await weather_agent.get_weather_forecast(request.origin, hours=6)
        
        return {
            'origin_weather': origin_weather,
            'destination_weather': destination_weather,
            'forecast': forecast
        }
        
    except Exception as e:
        logger.error(f"Weather request failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Obstacles endpoint
@app.post("/api/obstacles/area")
async def get_obstacles_in_area(request: ObstacleAreaRequest):
    """Get all obstacles within a geographic bounding box"""
    try:
        # Validate coordinates
        if request.north_lat <= request.south_lat:
            return ObstacleResponse(
                success=False,
                message="North latitude must be greater than south latitude"
            )
            
        if request.east_lng <= request.west_lng:
            return ObstacleResponse(
                success=False,
                message="East longitude must be greater than west longitude"
            )
            
        # Use obstacle agent to get data (will provide sample data if BigQuery fails)
        obstacles = await obstacle_agent.get_obstacles_in_area(
            north_lat=request.north_lat,
            south_lat=request.south_lat,
            east_lng=request.east_lng,
            west_lng=request.west_lng,
            include_resolved=request.include_resolved
        )
        
        return ObstacleResponse(
            success=True,
            message=f"Found {len(obstacles)} obstacles in the area",
            obstacles=obstacles
        )
        
    except Exception as e:
        logger.error(f"Error getting obstacles: {e}")
        return ObstacleResponse(
            success=False,
            message=f"Error getting obstacles: {str(e)}"
        )

@app.post("/api/obstacles/route")
async def get_route_obstacles(request: RouteRequest):
    """Get obstacles and live traffic data for route"""
    try:
        logger.info(f"Scanning obstacles for route: {request.origin} -> {request.destination}")
        
        # Get route details from Google Maps
        gmaps = googlemaps.Client(key="AIzaSyC-VQzmR1aLxXJsFYtYKZN6yyGr_hIxRic")
        directions = gmaps.directions(request.origin, request.destination)
        
        if not directions:
            return {
                'success': False,
                'message': 'Could not find route between given locations',
                'obstacles': [],
                'live_traffic': {},
                'alternatives': []
            }
        
        # Extract route bounds
        bounds = directions[0]['bounds']
        south_lat = bounds['southwest']['lat']
        west_lng = bounds['southwest']['lng']
        north_lat = bounds['northeast']['lat']
        east_lng = bounds['northeast']['lng']
        
        # Get obstacles in route area
        obstacles = await obstacle_agent.get_obstacles_in_area(
            north_lat=north_lat,
            south_lat=south_lat,
            east_lng=east_lng,
            west_lng=west_lng,
            include_resolved=False
        )
        
        # Filter obstacles close to the route
        route_obstacles = []
        for obstacle in obstacles:
            # Simple distance check for now
            if obstacle.get('priority') in ['CRITICAL', 'HIGH']:
                route_obstacles.append(obstacle)
        
        return {
            'success': True,
            'obstacles': route_obstacles,
            'live_traffic': {
                'congestion_level': 'MEDIUM',
                'estimated_delay_minutes': 15,
                'road_conditions': 'Normal'
            },
            'alternatives': [
                {
                    'route_name': 'Alternative 1',
                    'estimated_time': '35 mins',
                    'obstacle_count': len(route_obstacles) - 1,
                    'congestion_level': 'LOW'
                }
            ]
        }
        
    except Exception as e:
        logger.error(f"Obstacle scanning failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Parking finder endpoint
@app.post("/find-parking")
async def find_parking(request: ParkingRequest):
    """Find parking options near a destination"""
    logger.info(f"Finding parking near: {request.destination}")
    
    if not parking_agent:
        raise HTTPException(
            status_code=503,
            detail="Parking finder service is not available. Please ensure Google Places API is configured."
        )
    
    try:
        # First, geocode the destination to get coordinates
        import googlemaps
        gmaps = googlemaps.Client(key="AIzaSyC-VQzmR1aLxXJsFYtYKZN6yyGr_hIxRic")
        
        geocode_result = gmaps.geocode(request.destination)
        if not geocode_result:
            raise HTTPException(status_code=400, detail=f"Could not find location: {request.destination}")
        
        location = geocode_result[0]['geometry']['location']
        destination_lat = location['lat']
        destination_lng = location['lng']
        formatted_address = geocode_result[0]['formatted_address']
        
        logger.info(f"Geocoded {request.destination} to: {destination_lat}, {destination_lng}")
        
        # Search for parking options
        parking_recommendations = await parking_agent.get_parking_recommendations(
            destination_lat=destination_lat,
            destination_lng=destination_lng,
            destination_name=formatted_address
        )
        
        logger.info(f"Found {parking_recommendations.get('total_options', 0)} parking options")
        return parking_recommendations
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error finding parking: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error finding parking: {str(e)}")
"""
FastAPI endpoints for Real-Time Obstacle Reporting and Management System
"""

from fastapi import FastAPI, HTTPException, File, UploadFile, Form, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncio
import base64
import json
from datetime import datetime
import sys
import os

# Add the agents directory to the path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'agents'))

from obstacle_management_agent import ObstacleManagementAgent

# Pydantic models for request/response validation
class ObstacleReportRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90, description="GPS latitude coordinate")
    longitude: float = Field(..., ge=-180, le=180, description="GPS longitude coordinate")
    obstacle_type: str = Field(..., description="Type of obstacle")
    description: str = Field(..., min_length=1, max_length=500, description="Description of the obstacle")
    image_base64: Optional[str] = Field(None, description="Base64 encoded image data")
    user_id: Optional[str] = Field(None, description="ID of reporting user")
    reporter_name: Optional[str] = Field(None, description="Name of reporter")
    contact_info: Optional[str] = Field(None, description="Contact information")
    location_name: Optional[str] = Field(None, description="Named location (will be geocoded if provided)")

class ObstacleLocationRequest(BaseModel):
    location_name: str = Field(..., description="Named location to find coordinates for")

class ObstacleAreaRequest(BaseModel):
    north_lat: float = Field(..., ge=-90, le=90)
    south_lat: float = Field(..., ge=-90, le=90)
    east_lng: float = Field(..., ge=-180, le=180)
    west_lng: float = Field(..., ge=-180, le=180)
    include_resolved: bool = Field(False, description="Include resolved obstacles")

class ObstacleStatusUpdate(BaseModel):
    obstacle_id: str = Field(..., description="Unique obstacle identifier")
    new_status: str = Field(..., description="New status: VERIFIED, IN_PROGRESS, RESOLVED, FALSE_REPORT")
    estimated_clear_time: Optional[str] = Field(None, description="Estimated resolution time (ISO format)")
    notes: Optional[str] = Field(None, description="Additional notes")

class RouteObstacleRequest(BaseModel):
    origin_lat: float = Field(..., ge=-90, le=90)
    origin_lng: float = Field(..., ge=-180, le=180)
    dest_lat: float = Field(..., ge=-90, le=90)
    dest_lng: float = Field(..., ge=-180, le=180)
    buffer_meters: int = Field(500, ge=50, le=2000, description="Search buffer distance in meters")

class ObstacleResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
    obstacles: Optional[List[Dict[str, Any]]] = None

# Initialize FastAPI app
app = FastAPI(
    title="Real-Time Obstacle Management API",
    description="Comprehensive traffic obstacle reporting and management system",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this properly for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize obstacle management agent
obstacle_agent = ObstacleManagementAgent(
    project_id="planar-beach-467107-n1",
    dataset_id="traffic_management"
)

@app.on_event("startup")
async def startup_event():
    """Initialize the obstacle management system on startup"""
    print("🚀 Starting Real-Time Obstacle Management API...")
    print("📊 BigQuery dataset: traffic_management")
    print("☁️ Cloud Storage bucket: planar-beach-467107-n1-obstacle-images")

@app.get("/", response_model=Dict[str, str])
async def root():
    """API health check endpoint"""
    return {
        "status": "active",
        "service": "Real-Time Obstacle Management API",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/api/obstacles/geocode", response_model=ObstacleResponse)
async def geocode_location(request: ObstacleLocationRequest):
    """
    Geocode a named location to get coordinates
    """
    try:
        import googlemaps
        
        gmaps = googlemaps.Client(key="AIzaSyC-VQzmR1aLxXJsFYtYKZN6yyGr_hIxRic")
        
        # Geocode the location (bias towards Bengaluru)
        geocode_result = gmaps.geocode(
            f"{request.location_name}, Bengaluru, Karnataka, India"
        )
        
        if not geocode_result:
            # Try without Bengaluru bias
            geocode_result = gmaps.geocode(request.location_name)
        
        if not geocode_result:
            return ObstacleResponse(
                success=False,
                message=f"Could not find location: {request.location_name}"
            )
        
        location = geocode_result[0]['geometry']['location']
        formatted_address = geocode_result[0]['formatted_address']
        
        return ObstacleResponse(
            success=True,
            message="Location found successfully",
            data={
                "latitude": location['lat'],
                "longitude": location['lng'],
                "formatted_address": formatted_address,
                "place_id": geocode_result[0].get('place_id'),
                "location_type": geocode_result[0]['geometry'].get('location_type')
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Geocoding error: {str(e)}")

@app.post("/api/obstacles/report", response_model=ObstacleResponse)
async def report_obstacle(request: ObstacleReportRequest):
    """
    Report a new traffic obstacle with optional photo upload
    """
    try:
        # Validate obstacle type
        valid_types = [
            "pothole", "road_closure", "accident", "construction", 
            "debris", "flooding", "broken_signal", "fallen_tree", "vehicle_breakdown"
        ]
        
        if request.obstacle_type not in valid_types:
            return ObstacleResponse(
                success=False,
                message=f"Invalid obstacle type. Must be one of: {', '.join(valid_types)}"
            )
        
        # If location_name is provided, geocode it first
        latitude = request.latitude
        longitude = request.longitude
        
        if request.location_name:
            try:
                import googlemaps
                gmaps = googlemaps.Client(key="AIzaSyC-VQzmR1aLxXJsFYtYKZN6yyGr_hIxRic")
                
                geocode_result = gmaps.geocode(
                    f"{request.location_name}, Bengaluru, Karnataka, India"
                )
                
                if geocode_result:
                    location = geocode_result[0]['geometry']['location']
                    latitude = location['lat']
                    longitude = location['lng']
                    print(f"📍 Geocoded '{request.location_name}' to {latitude}, {longitude}")
                
            except Exception as e:
                print(f"⚠️ Geocoding failed, using provided coordinates: {str(e)}")
        
        # Report the obstacle
        result = await obstacle_agent.report_obstacle(
            latitude=latitude,
            longitude=longitude,
            obstacle_type=request.obstacle_type,
            description=request.description,
            image_base64=request.image_base64,
            user_id=request.user_id,
            reporter_name=request.reporter_name,
            contact_info=request.contact_info
        )
        
        if result["success"]:
            return ObstacleResponse(
                success=True,
                message=f"Obstacle reported successfully with ID: {result['obstacle_id']}",
                data=result
            )
        else:
            return ObstacleResponse(
                success=False,
                message=f"Failed to report obstacle: {result.get('error', 'Unknown error')}"
            )
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reporting obstacle: {str(e)}")

@app.post("/api/obstacles/area", response_model=ObstacleResponse)
async def get_obstacles_in_area(request: ObstacleAreaRequest):
    """
    Get all obstacles within a geographic bounding box
    """
    try:
        # Validate coordinates
        if request.north_lat <= request.south_lat:
            return ObstacleResponse(
                success=False,
                message="North latitude must be greater than south latitude"
            )
        
        if request.east_lng <= request.west_lng:
            return ObstacleResponse(
                success=False,
                message="East longitude must be greater than west longitude"
            )
        
        obstacles = await obstacle_agent.get_obstacles_in_area(
            north_lat=request.north_lat,
            south_lat=request.south_lat,
            east_lng=request.east_lng,
            west_lng=request.west_lng,
            include_resolved=request.include_resolved
        )
        
        return ObstacleResponse(
            success=True,
            message=f"Found {len(obstacles)} obstacles in the specified area",
            obstacles=obstacles
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting obstacles: {str(e)}")

@app.put("/api/obstacles/status", response_model=ObstacleResponse)
async def update_obstacle_status(request: ObstacleStatusUpdate):
    """
    Update the resolution status of an obstacle
    """
    try:
        # Validate status
        valid_statuses = ["REPORTED", "VERIFIED", "IN_PROGRESS", "RESOLVED", "FALSE_REPORT"]
        
        if request.new_status not in valid_statuses:
            return ObstacleResponse(
                success=False,
                message=f"Invalid status. Must be one of: {', '.join(valid_statuses)}"
            )
        
        result = await obstacle_agent.update_obstacle_status(
            obstacle_id=request.obstacle_id,
            new_status=request.new_status,
            estimated_clear_time=request.estimated_clear_time,
            notes=request.notes
        )
        
        if result["success"]:
            return ObstacleResponse(
                success=True,
                message=f"Obstacle {request.obstacle_id} status updated to {request.new_status}",
                data=result
            )
        else:
            return ObstacleResponse(
                success=False,
                message=f"Failed to update obstacle status: {result.get('error', 'Unknown error')}"
            )
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating obstacle status: {str(e)}")

@app.post("/api/obstacles/route", response_model=ObstacleResponse)
async def get_obstacles_on_route(request: RouteObstacleRequest):
    """
    Get obstacles that might affect a specific route
    """
    try:
        obstacles = await obstacle_agent.get_obstacles_on_route(
            origin_lat=request.origin_lat,
            origin_lng=request.origin_lng,
            dest_lat=request.dest_lat,
            dest_lng=request.dest_lng,
            buffer_meters=request.buffer_meters
        )
        
        return ObstacleResponse(
            success=True,
            message=f"Found {len(obstacles)} obstacles affecting the route",
            obstacles=obstacles
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting route obstacles: {str(e)}")

@app.get("/api/obstacles/types", response_model=Dict[str, Any])
async def get_obstacle_types():
    """
    Get available obstacle types and their properties
    """
    return {
        "obstacle_types": obstacle_agent.obstacle_types,
        "valid_statuses": ["REPORTED", "VERIFIED", "IN_PROGRESS", "RESOLVED", "FALSE_REPORT"],
        "priority_levels": ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
    }

@app.get("/api/obstacles/stats", response_model=Dict[str, Any])
async def get_obstacle_statistics():
    """
    Get general statistics about obstacles in the system
    """
    try:
        from google.cloud import bigquery
        
        client = bigquery.Client(project="planar-beach-467107-n1")
        
        # Query for statistics
        query = """
        SELECT 
            COUNT(*) as total_obstacles,
            COUNT(DISTINCT obstacle_type) as distinct_types,
            AVG(severity) as avg_severity,
            COUNT(CASE WHEN resolution_status = 'RESOLVED' THEN 1 END) as resolved_count,
            COUNT(CASE WHEN verified = true THEN 1 END) as verified_count,
            COUNT(CASE WHEN priority = 'CRITICAL' THEN 1 END) as critical_count,
            MIN(reported_timestamp) as earliest_report,
            MAX(reported_timestamp) as latest_report
        FROM `planar-beach-467107-n1.traffic_management.obstacles`
        """
        
        results = client.query(query).result()
        
        stats = {}
        for row in results:
            stats = dict(row)
            break
        
        # Query for obstacle type breakdown
        type_query = """
        SELECT 
            obstacle_type,
            COUNT(*) as count,
            AVG(severity) as avg_severity,
            COUNT(CASE WHEN resolution_status = 'RESOLVED' THEN 1 END) as resolved_count
        FROM `planar-beach-467107-n1.traffic_management.obstacles`
        GROUP BY obstacle_type
        ORDER BY count DESC
        """
        
        type_results = client.query(type_query).result()
        
        type_breakdown = []
        for row in type_results:
            type_breakdown.append(dict(row))
        
        return {
            "overall_stats": stats,
            "type_breakdown": type_breakdown,
            "generated_at": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting statistics: {str(e)}")

# Health check endpoint for monitoring
@app.get("/health")
async def health_check():
    """Simple health check for monitoring and load balancing"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "service": "obstacle-management-api"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8007)
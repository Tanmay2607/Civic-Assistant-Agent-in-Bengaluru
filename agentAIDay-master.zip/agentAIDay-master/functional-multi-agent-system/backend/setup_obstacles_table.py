"""
BigQuery table setup for Real-Time Obstacle Reporting System
Creates the obstacles table with proper schema for tracking traffic obstacles
"""

from google.cloud import bigquery
import os
import json

def create_obstacles_table():
    """Create the obstacles table in BigQuery with comprehensive schema"""
    
    # Set up credentials explicitly
    import os
    from pathlib import Path
    
    # Try different possible paths for the credentials file
    possible_paths = [
        "planar-beach-467107-n1-83bdc68ba222.json",
        "../planar-beach-467107-n1-83bdc68ba222.json",
        "../../planar-beach-467107-n1-83bdc68ba222.json",
        os.path.join(os.path.dirname(__file__), "..", "planar-beach-467107-n1-83bdc68ba222.json"),
        os.path.join(os.path.dirname(__file__), "planar-beach-467107-n1-83bdc68ba222.json")
    ]
    
    credentials_path = None
    for path in possible_paths:
        abs_path = os.path.abspath(path)
        if os.path.exists(abs_path):
            credentials_path = abs_path
            break
    
    if not credentials_path:
        print("❌ Could not find Google Cloud credentials file")
        print("Looking for: planar-beach-467107-n1-83bdc68ba222.json")
        print("Searched in:")
        for path in possible_paths:
            print(f"  - {os.path.abspath(path)}")
        return False
    
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credentials_path
    print(f"✅ Found credentials at: {credentials_path}")
    
    # Initialize BigQuery client
    client = bigquery.Client(project="planar-beach-467107-n1")
    project_id = "planar-beach-467107-n1"
    dataset_id = "traffic_management"
    table_id = "obstacles"
    
    # Create dataset if it doesn't exist
    try:
        dataset_ref = client.dataset(dataset_id)
        dataset = client.get_dataset(dataset_ref)
        print(f"✅ Dataset {dataset_id} already exists")
    except Exception:
        print(f"📊 Creating dataset {dataset_id}...")
        dataset = bigquery.Dataset(dataset_ref)
        dataset.location = "US"
        dataset.description = "Traffic management data including obstacles and route analysis"
        dataset = client.create_dataset(dataset, timeout=30)
        print(f"✅ Created dataset {dataset.dataset_id}")
    
    # Define the full table reference
    table_ref = client.dataset(dataset_id).table(table_id)
    
    # Define the schema
    schema = [
        bigquery.SchemaField("obstacle_id", "STRING", mode="REQUIRED", description="Unique identifier for the obstacle"),
        bigquery.SchemaField("user_id", "STRING", mode="NULLABLE", description="ID of user who reported the obstacle"),
        bigquery.SchemaField("latitude", "FLOAT", mode="REQUIRED", description="GPS latitude coordinate"),
        bigquery.SchemaField("longitude", "FLOAT", mode="REQUIRED", description="GPS longitude coordinate"),
        bigquery.SchemaField("address", "STRING", mode="NULLABLE", description="Human-readable address from reverse geocoding"),
        bigquery.SchemaField("obstacle_type", "STRING", mode="REQUIRED", description="Type of obstacle: pothole, road_closure, accident, construction, debris, flooding, broken_signal"),
        bigquery.SchemaField("description", "STRING", mode="NULLABLE", description="User-provided description of the obstacle"),
        bigquery.SchemaField("severity", "INTEGER", mode="NULLABLE", description="AI-analyzed severity score (1-10 scale)"),
        bigquery.SchemaField("image_url", "STRING", mode="NULLABLE", description="Cloud Storage public URL for uploaded photo"),
        bigquery.SchemaField("reported_timestamp", "TIMESTAMP", mode="REQUIRED", description="When the obstacle was first reported"),
        bigquery.SchemaField("resolution_status", "STRING", mode="REQUIRED", description="Current status: REPORTED, VERIFIED, IN_PROGRESS, RESOLVED, FALSE_REPORT"),
        bigquery.SchemaField("resolved_timestamp", "TIMESTAMP", mode="NULLABLE", description="When the obstacle was marked as resolved"),
        bigquery.SchemaField("verified", "BOOLEAN", mode="REQUIRED", description="Whether the obstacle has been verified by authorities"),
        bigquery.SchemaField("impact_radius_meters", "INTEGER", mode="NULLABLE", description="Estimated impact radius in meters"),
        bigquery.SchemaField("priority", "STRING", mode="NULLABLE", description="Priority level: LOW, MEDIUM, HIGH, CRITICAL"),
        bigquery.SchemaField("weather_conditions", "STRING", mode="NULLABLE", description="Weather conditions when reported"),
        bigquery.SchemaField("reporter_name", "STRING", mode="NULLABLE", description="Name of person who reported (optional)"),
        bigquery.SchemaField("contact_info", "STRING", mode="NULLABLE", description="Contact information for follow-up"),
        bigquery.SchemaField("estimated_clear_time", "TIMESTAMP", mode="NULLABLE", description="Estimated time when obstacle will be cleared"),
        bigquery.SchemaField("additional_metadata", "JSON", mode="NULLABLE", description="Additional metadata as JSON"),
    ]
    
    # Create the table
    table = bigquery.Table(table_ref, schema=schema)
    table.description = "Real-time traffic obstacle reporting and tracking system"
    
    # Set table clustering for optimal query performance
    table.clustering_fields = ["obstacle_type", "resolution_status", "verified"]
    
    # Set table partitioning by reported_timestamp for time-based queries
    table.time_partitioning = bigquery.TimePartitioning(
        type_=bigquery.TimePartitioningType.DAY,
        field="reported_timestamp"
    )
    
    try:
        table = client.create_table(table, exists_ok=True)
        print(f"✅ Successfully created table {table.project}.{table.dataset_id}.{table.table_id}")
        print(f"📊 Table has {len(table.schema)} columns")
        print(f"🔄 Partitioned by: {table.time_partitioning.field}")
        print(f"🗂️ Clustered by: {', '.join(table.clustering_fields)}")
        return True
    except Exception as e:
        print(f"❌ Error creating table: {str(e)}")
        return False

def create_sample_obstacle_data():
    """Insert sample obstacle data for testing and demonstration"""
    
    client = bigquery.Client()
    project_id = "planar-beach-467107-n1"
    dataset_id = "traffic_management"
    table_id = "obstacles"
    
    # Sample data for Bengaluru locations
    sample_obstacles = [
        {
            "obstacle_id": "OBS_001",
            "user_id": "user123",
            "latitude": 12.9716,
            "longitude": 77.5946,
            "address": "MG Road, Bengaluru, Karnataka, India",
            "obstacle_type": "pothole",
            "description": "Large pothole causing traffic slow down",
            "severity": 7,
            "image_url": "https://storage.googleapis.com/sample-images/pothole_001.jpg",
            "reported_timestamp": "2024-01-27 10:30:00",
            "resolution_status": "VERIFIED",
            "resolved_timestamp": None,
            "verified": True,
            "impact_radius_meters": 50,
            "priority": "HIGH",
            "weather_conditions": "Clear",
            "reporter_name": "John Doe",
            "contact_info": "+91-9876543210",
            "estimated_clear_time": None,
            "additional_metadata": json.dumps({"vehicle_type": "car", "traffic_level": "heavy"})
        },
        {
            "obstacle_id": "OBS_002", 
            "user_id": "user456",
            "latitude": 12.9352,
            "longitude": 77.6245,
            "address": "Electronic City, Bengaluru, Karnataka, India",
            "obstacle_type": "construction",
            "description": "Road construction blocking one lane",
            "severity": 8,
            "image_url": "https://storage.googleapis.com/sample-images/construction_002.jpg",
            "reported_timestamp": "2024-01-27 09:15:00",
            "resolution_status": "IN_PROGRESS",
            "resolved_timestamp": None,
            "verified": True,
            "impact_radius_meters": 200,
            "priority": "CRITICAL",
            "weather_conditions": "Sunny",
            "reporter_name": "Jane Smith",
            "contact_info": "jane@example.com",
            "estimated_clear_time": "2024-01-28 18:00:00",
            "additional_metadata": json.dumps({"construction_type": "road_widening", "contractor": "XYZ Construction"})
        },
        {
            "obstacle_id": "OBS_003",
            "user_id": "user789",
            "latitude": 12.9698,
            "longitude": 77.7500,
            "address": "Whitefield, Bengaluru, Karnataka, India", 
            "obstacle_type": "accident",
            "description": "Minor fender bender, vehicles being cleared",
            "severity": 5,
            "image_url": "https://storage.googleapis.com/sample-images/accident_003.jpg",
            "reported_timestamp": "2024-01-27 11:45:00",
            "resolution_status": "RESOLVED",
            "resolved_timestamp": "2024-01-27 12:30:00",
            "verified": True,
            "impact_radius_meters": 100,
            "priority": "MEDIUM",
            "weather_conditions": "Partly Cloudy",
            "reporter_name": "Traffic Police",
            "contact_info": "traffic.control@bengaluru.gov.in",
            "estimated_clear_time": "2024-01-27 12:30:00",
            "additional_metadata": json.dumps({"police_case_id": "TC2024001", "vehicles_involved": 2})
        }
    ]
    
    # Insert the sample data
    table_ref = client.dataset(dataset_id).table(table_id)
    table = client.get_table(table_ref)
    
    try:
        errors = client.insert_rows_json(table, sample_obstacles)
        if errors == []:
            print(f"✅ Successfully inserted {len(sample_obstacles)} sample obstacles")
            return True
        else:
            print(f"❌ Errors inserting sample data: {errors}")
            return False
    except Exception as e:
        print(f"❌ Error inserting sample data: {str(e)}")
        return False

def verify_table_creation():
    """Verify that the table was created correctly and has data"""
    
    client = bigquery.Client()
    project_id = "planar-beach-467107-n1"
    dataset_id = "traffic_management"
    table_id = "obstacles"
    
    # Query to check table structure and data
    query = f"""
    SELECT 
        COUNT(*) as total_obstacles,
        COUNT(DISTINCT obstacle_type) as distinct_types,
        COUNT(DISTINCT resolution_status) as distinct_statuses,
        MIN(reported_timestamp) as earliest_report,
        MAX(reported_timestamp) as latest_report
    FROM `{project_id}.{dataset_id}.{table_id}`
    """
    
    try:
        results = client.query(query).result()
        for row in results:
            print(f"📊 Table Verification Results:")
            print(f"   Total obstacles: {row.total_obstacles}")
            print(f"   Obstacle types: {row.distinct_types}")
            print(f"   Status types: {row.distinct_statuses}")
            print(f"   Date range: {row.earliest_report} to {row.latest_report}")
        return True
    except Exception as e:
        print(f"❌ Error verifying table: {str(e)}")
        return False

if __name__ == "__main__":
    print("🚀 Setting up BigQuery obstacles table...")
    
    # Create the table
    if create_obstacles_table():
        print("\n📝 Inserting sample obstacle data...")
        
        # Insert sample data
        if create_sample_obstacle_data():
            print("\n🔍 Verifying table setup...")
            
            # Verify everything worked
            verify_table_creation()
            
            print("\n✅ Obstacle tracking system database setup complete!")
            print("💡 Ready to integrate with Traffic Management Agent")
        else:
            print("❌ Failed to insert sample data")
    else:
        print("❌ Failed to create obstacles table")
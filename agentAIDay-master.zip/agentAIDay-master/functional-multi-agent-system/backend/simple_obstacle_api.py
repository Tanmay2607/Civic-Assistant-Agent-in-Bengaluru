"""
Simplified FastAPI endpoints for Real-Time Obstacle Reporting
Works without BigQuery for testing purposes
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import uuid
import json
from datetime import datetime

# Pydantic models for request/response validation
class ObstacleReportRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90, description="GPS latitude coordinate")
    longitude: float = Field(..., ge=-180, le=180, description="GPS longitude coordinate")
    obstacle_type: str = Field(..., description="Type of obstacle")
    description: str = Field(..., min_length=1, max_length=500, description="Description of the obstacle")
    image_base64: Optional[str] = Field(None, description="Base64 encoded image data")
    user_id: Optional[str] = Field(None, description="ID of reporting user")
    reporter_name: Optional[str] = Field(None, description="Name of reporter")
    contact_info: Optional[str] = Field(None, description="Contact information")
    location_name: Optional[str] = Field(None, description="Named location (will be geocoded if provided)")

class ObstacleLocationRequest(BaseModel):
    location_name: str = Field(..., description="Named location to find coordinates for")

class ObstacleAreaRequest(BaseModel):
    north_lat: float = Field(..., ge=-90, le=90)
    south_lat: float = Field(..., ge=-90, le=90)
    east_lng: float = Field(..., ge=-180, le=180)
    west_lng: float = Field(..., ge=-180, le=180)
    include_resolved: bool = Field(False, description="Include resolved obstacles")

class ObstacleResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
    obstacles: Optional[List[Dict[str, Any]]] = None

# Initialize FastAPI app
app = FastAPI(
    title="Real-Time Obstacle Management API (Testing Mode)",
    description="Simplified obstacle reporting system for testing",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for testing (replace with BigQuery in production)
obstacles_storage = []

# Sample obstacle data
sample_obstacles = [
    {
        "obstacle_id": "OBS_001",
        "user_id": "user123",
        "latitude": 12.9716,
        "longitude": 77.5946,
        "address": "MG Road, Bengaluru, Karnataka, India",
        "obstacle_type": "pothole",
        "description": "Large pothole causing traffic slow down",
        "severity": 7,
        "image_url": "https://via.placeholder.com/300x200?text=Pothole",
        "reported_timestamp": "2024-01-27T10:30:00Z",
        "resolution_status": "VERIFIED",
        "resolved_timestamp": None,
        "verified": True,
        "impact_radius_meters": 50,
        "priority": "HIGH",
        "weather_conditions": "Clear",
        "reporter_name": "John Doe",
        "contact_info": "+91-9876543210",
        "estimated_clear_time": None,
        "additional_metadata": {"vehicle_type": "car", "traffic_level": "heavy"}
    },
    {
        "obstacle_id": "OBS_002",
        "user_id": "user456",
        "latitude": 12.9352,
        "longitude": 77.6245,
        "address": "Electronic City, Bengaluru, Karnataka, India",
        "obstacle_type": "construction",
        "description": "Road construction blocking one lane",
        "severity": 8,
        "image_url": "https://via.placeholder.com/300x200?text=Construction",
        "reported_timestamp": "2024-01-27T09:15:00Z",
        "resolution_status": "IN_PROGRESS",
        "resolved_timestamp": None,
        "verified": True,
        "impact_radius_meters": 200,
        "priority": "CRITICAL",
        "weather_conditions": "Sunny",
        "reporter_name": "Jane Smith",
        "contact_info": "jane@example.com",
        "estimated_clear_time": "2024-01-28T18:00:00Z",
        "additional_metadata": {"construction_type": "road_widening", "contractor": "XYZ Construction"}
    },
    {
        "obstacle_id": "OBS_003",
        "user_id": "user789",
        "latitude": 12.9165,
        "longitude": 77.6229,
        "address": "Silk Board Junction, Bengaluru, Karnataka, India",
        "obstacle_type": "road_closure",
        "description": "Complete road closure due to metro construction",
        "severity": 9,
        "image_url": "https://via.placeholder.com/300x200?text=Road+Closure",
        "reported_timestamp": "2024-01-27T08:00:00Z",
        "resolution_status": "REPORTED",
        "resolved_timestamp": None,
        "verified": False,
        "impact_radius_meters": 500,
        "priority": "CRITICAL",
        "weather_conditions": "Clear",
        "reporter_name": "Traffic Police",
        "contact_info": "traffic@bengaluru.gov.in",
        "estimated_clear_time": "2024-01-29T18:00:00Z",
        "additional_metadata": {"authority": "BMRCL", "project": "metro_expansion"}
    },
    {
        "obstacle_id": "OBS_004",
        "user_id": "user101",
        "latitude": 12.9698,
        "longitude": 77.7500,
        "address": "Whitefield, Bengaluru, Karnataka, India",
        "obstacle_type": "flooding",
        "description": "Water logging on main road due to heavy rains",
        "severity": 6,
        "image_url": "https://via.placeholder.com/300x200?text=Flooding",
        "reported_timestamp": "2024-01-27T07:30:00Z",
        "resolution_status": "VERIFIED",
        "resolved_timestamp": None,
        "verified": True,
        "impact_radius_meters": 300,
        "priority": "HIGH",
        "weather_conditions": "Heavy Rain",
        "reporter_name": "Resident Association",
        "contact_info": "+91-9988776655",
        "estimated_clear_time": "2024-01-27T16:00:00Z",
        "additional_metadata": {"water_level": "moderate", "drainage_issue": True}
    },
    {
        "obstacle_id": "OBS_005",
        "user_id": "user202",
        "latitude": 12.9591,
        "longitude": 77.6476,
        "address": "Koramangala, Bengaluru, Karnataka, India",
        "obstacle_type": "broken_signal",
        "description": "Traffic signal malfunction during peak hours",
        "severity": 5,
        "image_url": "https://via.placeholder.com/300x200?text=Signal+Issue",
        "reported_timestamp": "2024-01-27T08:45:00Z",
        "resolution_status": "RESOLVED",
        "resolved_timestamp": "2024-01-27T12:00:00Z",
        "verified": True,
        "impact_radius_meters": 100,
        "priority": "MEDIUM",
        "weather_conditions": "Clear",
        "reporter_name": "Traffic Volunteer",
        "contact_info": "+91-8877665544",
        "estimated_clear_time": None,
        "additional_metadata": {"signal_type": "main_intersection", "repair_status": "completed"}
    }
]

# Initialize with sample data
obstacles_storage.extend(sample_obstacles)

def calculate_severity(obstacle_type: str, description: str) -> int:
    """Simple severity calculation"""
    base_severity = {
        "pothole": 5,
        "road_closure": 9,
        "accident": 7,
        "construction": 6,
        "debris": 4,
        "flooding": 8,
        "broken_signal": 7,
        "fallen_tree": 6,
        "vehicle_breakdown": 4
    }.get(obstacle_type, 5)
    
    # Simple keyword analysis
    description_lower = description.lower()
    if "major" in description_lower or "severe" in description_lower:
        base_severity += 2
    elif "minor" in description_lower or "small" in description_lower:
        base_severity -= 1
        
    return max(1, min(10, base_severity))

def determine_priority(severity: int) -> str:
    """Determine priority based on severity"""
    if severity >= 8:
        return "CRITICAL"
    elif severity >= 6:
        return "HIGH"
    elif severity >= 4:
        return "MEDIUM"
    else:
        return "LOW"

@app.on_event("startup")
async def startup_event():
    """Initialize the obstacle management system on startup"""
    print("🚀 Starting Real-Time Obstacle Management API (Testing Mode)...")
    print(f"📊 Sample obstacles loaded: {len(obstacles_storage)}")

@app.get("/", response_model=Dict[str, str])
async def root():
    """API health check endpoint"""
    return {
        "status": "active",
        "service": "Real-Time Obstacle Management API (Testing)",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/api/obstacles/geocode", response_model=ObstacleResponse)
async def geocode_location(request: ObstacleLocationRequest):
    """
    Mock geocoding service for testing
    """
    # Simple mock geocoding for Bengaluru locations
    location_map = {
        "koramangala": {"lat": 12.9352, "lng": 77.6245},
        "mg road": {"lat": 12.9716, "lng": 77.5946},
        "electronic city": {"lat": 12.8456, "lng": 77.6603},
        "whitefield": {"lat": 12.9698, "lng": 77.7500},
        "silk board": {"lat": 12.9165, "lng": 77.6229}
    }
    
    location_key = request.location_name.lower()
    for key, coords in location_map.items():
        if key in location_key:
            return ObstacleResponse(
                success=True,
                message="Location found successfully",
                data={
                    "latitude": coords["lat"],
                    "longitude": coords["lng"],
                    "formatted_address": f"{request.location_name}, Bengaluru, Karnataka, India",
                    "place_id": f"mock_place_id_{key}",
                    "location_type": "APPROXIMATE"
                }
            )
    
    return ObstacleResponse(
        success=False,
        message=f"Could not find location: {request.location_name}"
    )

@app.post("/api/obstacles/report", response_model=ObstacleResponse)
async def report_obstacle(request: ObstacleReportRequest):
    """
    Report a new traffic obstacle
    """
    try:
        # Generate unique obstacle ID
        obstacle_id = f"OBS_{uuid.uuid4().hex[:8].upper()}"
        
        # Calculate severity and priority
        severity = calculate_severity(request.obstacle_type, request.description)
        priority = determine_priority(severity)
        
        # Create obstacle record
        obstacle_record = {
            "obstacle_id": obstacle_id,
            "user_id": request.user_id or f"user_{uuid.uuid4().hex[:8]}",
            "latitude": request.latitude,
            "longitude": request.longitude,
            "address": f"{request.latitude:.4f}, {request.longitude:.4f}",
            "obstacle_type": request.obstacle_type,
            "description": request.description,
            "severity": severity,
            "image_url": "https://via.placeholder.com/300x200?text=User+Photo" if request.image_base64 else None,
            "reported_timestamp": datetime.utcnow().isoformat(),
            "resolution_status": "REPORTED",
            "resolved_timestamp": None,
            "verified": False,
            "impact_radius_meters": 50 + (severity * 10),
            "priority": priority,
            "weather_conditions": "Clear",
            "reporter_name": request.reporter_name,
            "contact_info": request.contact_info,
            "estimated_clear_time": None,
            "additional_metadata": {
                "ai_confidence": 0.85,
                "auto_generated": True,
                "version": "1.0"
            }
        }
        
        # Store in memory
        obstacles_storage.append(obstacle_record)
        
        print(f"✅ Successfully reported obstacle {obstacle_id}")
        
        return ObstacleResponse(
            success=True,
            message=f"Obstacle reported successfully with ID: {obstacle_id}",
            data={
                "obstacle_id": obstacle_id,
                "severity": severity,
                "priority": priority,
                "address": obstacle_record["address"],
                "estimated_impact_radius": obstacle_record["impact_radius_meters"]
            }
        )
        
    except Exception as e:
        print(f"❌ Error reporting obstacle: {str(e)}")
        return ObstacleResponse(
            success=False,
            message=f"Failed to report obstacle: {str(e)}"
        )

@app.post("/api/obstacles/area", response_model=ObstacleResponse)
async def get_obstacles_in_area(request: ObstacleAreaRequest):
    """
    Get all obstacles within a geographic bounding box
    """
    try:
        # Filter obstacles by geographic bounds
        filtered_obstacles = []
        
        for obstacle in obstacles_storage:
            lat = obstacle["latitude"]
            lng = obstacle["longitude"]
            
            if (request.south_lat <= lat <= request.north_lat and 
                request.west_lng <= lng <= request.east_lng):
                
                # Filter by resolution status if needed
                if not request.include_resolved and obstacle["resolution_status"] == "RESOLVED":
                    continue
                    
                filtered_obstacles.append(obstacle)
        
        return ObstacleResponse(
            success=True,
            message=f"Found {len(filtered_obstacles)} obstacles in the specified area",
            obstacles=filtered_obstacles
        )
        
    except Exception as e:
        print(f"❌ Error getting obstacles in area: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error getting obstacles: {str(e)}")

@app.get("/api/obstacles/types", response_model=Dict[str, Any])
async def get_obstacle_types():
    """
    Get available obstacle types and their properties
    """
    return {
        "obstacle_types": {
            "pothole": {"base_severity": 5, "impact_radius": 30, "description": "Road surface hole"},
            "road_closure": {"base_severity": 9, "impact_radius": 500, "description": "Complete road blockage"},
            "accident": {"base_severity": 7, "impact_radius": 200, "description": "Vehicle collision"},
            "construction": {"base_severity": 6, "impact_radius": 300, "description": "Construction work"},
            "debris": {"base_severity": 4, "impact_radius": 50, "description": "Objects on road"},
            "flooding": {"base_severity": 8, "impact_radius": 1000, "description": "Water on road"},
            "broken_signal": {"base_severity": 7, "impact_radius": 100, "description": "Traffic light malfunction"},
            "fallen_tree": {"base_severity": 6, "impact_radius": 150, "description": "Tree blocking road"},
            "vehicle_breakdown": {"base_severity": 4, "impact_radius": 100, "description": "Broken down vehicle"}
        },
        "valid_statuses": ["REPORTED", "VERIFIED", "IN_PROGRESS", "RESOLVED", "FALSE_REPORT"],
        "priority_levels": ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
    }

@app.get("/health")
async def health_check():
    """Simple health check for monitoring and load balancing"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "service": "obstacle-management-api",
        "obstacles_count": len(obstacles_storage)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8007)
import React, { useState, useEffect, useRef } from 'react';
import './App.css';
import ObstacleReporting from './ObstacleReporting';
import ObstacleMap from './ObstacleMap';

// Google Maps component
const GoogleMapComponent = ({ route, origin, destination }) => {
  const mapRef = useRef(null);
  const [map, setMap] = useState(null);
  const [status, setStatus] = useState('Loading Google Maps...');
  
  useEffect(() => {
    console.log('🗺️ GoogleMapComponent mounted');
    
    const initializeMap = () => {
      if (!window.google || !window.google.maps) {
        setStatus('❌ Google Maps API not loaded');
        return;
      }
      
      if (!mapRef.current) {
        setStatus('❌ Map container not found');
        return;
      }
      
      try {
        console.log('🚀 Creating Google Map...');
        const googleMap = new window.google.maps.Map(mapRef.current, {
          center: { lat: 12.9716, lng: 77.5946 },
          zoom: 12,
          mapTypeControl: true,
          streetViewControl: false,
          fullscreenControl: true
        });
        
        setMap(googleMap);
        setStatus('✅ Map loaded successfully!');
        console.log('✅ Google Map created successfully');
        
      } catch (error) {
        console.error('❌ Map creation failed:', error);
        setStatus(`❌ Map creation failed: ${error.message}`);
      }
    };
    
    // Check if Google Maps is already loaded
    if (window.google && window.google.maps) {
      initializeMap();
    } else {
      // Wait for Google Maps to load
      const checkInterval = setInterval(() => {
        if (window.google && window.google.maps) {
          clearInterval(checkInterval);
          initializeMap();
        }
      }, 100);
      
      // Cleanup interval after 10 seconds
      setTimeout(() => {
        clearInterval(checkInterval);
        if (!map) {
          setStatus('❌ Google Maps API failed to load within 10 seconds');
        }
      }, 10000);
      
      return () => clearInterval(checkInterval);
    }
  }, []);
  
  useEffect(() => {
    if (map && origin && destination) {
      console.log('🗺️ Rendering route for:', origin, '->', destination);
      renderRouteOnMap(origin, destination, map);
    }
  }, [map, origin, destination]);
  
  const renderRouteOnMap = (origin, destination, map) => {
    // Clear any existing route renderers and markers
    if (window.directionsRenderer) {
      window.directionsRenderer.setMap(null);
    }
    if (window.mapMarkers) {
      window.mapMarkers.forEach(marker => marker.setMap(null));
    }
    window.mapMarkers = [];
    
    // Try Directions API first for route path
    const directionsService = new window.google.maps.DirectionsService();
    const directionsRenderer = new window.google.maps.DirectionsRenderer({
      suppressMarkers: false,
      polylineOptions: {
        strokeColor: '#4285F4',
        strokeWeight: 6,
        strokeOpacity: 0.8
      }
    });
    
    console.log('🛣️ Attempting to get directions from Google Maps API...');
    
    directionsService.route({
      origin: origin + ", Bengaluru, Karnataka, India",
      destination: destination + ", Bengaluru, Karnataka, India",
      travelMode: window.google.maps.TravelMode.DRIVING,
      avoidHighways: false,
      avoidTolls: false
    }, (result, status) => {
      console.log('📡 Directions API response status:', status);
      
      if (status === 'OK') {
        // Success! Show the route path
        directionsRenderer.setDirections(result);
        directionsRenderer.setMap(map);
        window.directionsRenderer = directionsRenderer;
        
        console.log('✅ Route path rendered successfully!');
        setStatus('✅ Route path displayed with directions!');
        
        // Log route details
        const route = result.routes[0];
        if (route && route.legs[0]) {
          console.log(`📏 Distance: ${route.legs[0].distance.text}`);
          console.log(`⏱️ Duration: ${route.legs[0].duration.text}`);
        }
        
      } else {
        console.warn(`⚠️ Directions API failed (${status}), falling back to markers...`);
        
        if (status === 'REQUEST_DENIED') {
          setStatus('⚠️ Directions API not enabled - showing markers only');
        } else if (status === 'ZERO_RESULTS') {
          setStatus('⚠️ No route found - showing markers only');
        } else {
          setStatus(`⚠️ Directions failed (${status}) - showing markers only`);
        }
        
        // Fallback to marker-only approach
        addMarkersOnly(origin, destination, map);
      }
    });
  };
  
  const addMarkersOnly = (origin, destination, map) => {
    const geocoder = new window.google.maps.Geocoder();
    
    console.log('📍 Falling back to markers-only approach...');
    
    // Geocode and add origin marker
    geocoder.geocode({ address: origin + ", Bengaluru, Karnataka, India" }, (results, status) => {
      if (status === 'OK') {
        const originMarker = new window.google.maps.Marker({
          position: results[0].geometry.location,
          map: map,
          title: `Origin: ${origin}`,
          icon: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
        });
        window.mapMarkers = window.mapMarkers || [];
        window.mapMarkers.push(originMarker);
        
        // Geocode and add destination marker
        geocoder.geocode({ address: destination + ", Bengaluru, Karnataka, India" }, (results2, status2) => {
          if (status2 === 'OK') {
            const destMarker = new window.google.maps.Marker({
              position: results2[0].geometry.location,
              map: map,
              title: `Destination: ${destination}`,
              icon: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'
            });
            window.mapMarkers.push(destMarker);
            
            // Fit map to show both markers
            const bounds = new window.google.maps.LatLngBounds();
            bounds.extend(results[0].geometry.location);
            bounds.extend(results2[0].geometry.location);
            map.fitBounds(bounds);
            
            console.log('✅ Markers placed successfully!');
            setStatus('✅ Map with origin/destination markers');
          } else {
            console.error('❌ Destination geocoding failed:', status2);
            setStatus(`❌ Destination geocoding failed: ${status2}`);
          }
        });
      } else {
        console.error('❌ Origin geocoding failed:', status);
        setStatus(`❌ Origin geocoding failed: ${status}`);
      }
    });
  };

  return (
    <div style={{ position: 'relative' }}>
      <div style={{
        padding: '10px',
        background: '#f8f9fa',
        border: '1px solid #dee2e6',
        borderRadius: '4px',
        marginBottom: '10px',
        fontSize: '14px'
      }}>
        <strong>Status:</strong> {status}
        <br/>
        <small>
          <a href="/api-key-validator.html" target="_blank" style={{color: '#dc3545', fontWeight: 'bold'}}>
            🔑 API Key Validator
          </a>
          {' | '}
          <a href="/simple-test.html" target="_blank" style={{color: '#007bff'}}>
            🧪 Simple Test
          </a>
          {' | '}
          <a href="/maps-test.html" target="_blank" style={{color: '#007bff'}}>
            📋 Advanced Test
          </a>
        </small>
        <br/>
        <small style={{color: '#6c757d'}}>
          <strong>Current API Key:</strong> AIzaSyC-VQzmR1aLxXJsFYtYKZN6yyGr_hIxRic
        </small>
      </div>
      <div
        ref={mapRef}
        style={{
          width: '100%',
          height: '400px',
          borderRadius: '8px',
          border: '2px solid #007bff',
          backgroundColor: '#f8f9fa'
        }}
      />
    </div>
  );
};

const TrafficAgent = () => {
  const [route, setRoute] = useState(null);
  const [insights, setInsights] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lastQuery, setLastQuery] = useState({ origin: '', destination: '', transport_mode: 'car' });
  const [transportMode, setTransportMode] = useState('car');
  const [activeTab, setActiveTab] = useState('route'); // 'route', 'obstacles', 'report', 'parking'
  const [parkingOptions, setParkingOptions] = useState(null);
  const [parkingLoading, setParkingLoading] = useState(false);

  const searchParkingNearDestination = async (destination) => {
    if (!destination) {
      return;
    }

    setParkingLoading(true);
    setParkingOptions(null);

    try {
      console.log('🅿️ Searching for parking near destination...');
      
      const response = await fetch('http://localhost:8006/find-parking', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          destination: destination,
          radius: 1000, // 1km search radius
          max_results: 10
        }),
      });

      const data = await response.json();
      console.log('🅿️ Parking search complete:', data);

      if (data.success) {
        setParkingOptions(data);
      } else {
        console.warn('⚠️ Parking search failed:', data.message);
      }
    } catch (error) {
      console.error('❌ Parking search failed:', error);
    } finally {
      setParkingLoading(false);
    }
  };

  const analyzeRoute = async (origin, destination) => {
    if (!origin.trim() || !destination.trim()) {
      setError('Please enter both origin and destination');
      return;
    }
    
    setLoading(true);
    setError(null);
    setLastQuery({ origin, destination, transport_mode: transportMode });
    
    try {
      console.log('🚀 Sending intelligent route request...', { origin, destination, transport_mode: transportMode });
      
      const response = await fetch('http://localhost:8006/api/intelligent/route', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin,
          destination,
          transport_mode: transportMode,
          prioritize: 'time'
        })
      });

      console.log('📡 Response status:', response.status);
      const data = await response.json();
      console.log('📋 Complete API Response:', JSON.stringify(data, null, 2));
      
      // Log the route data structure specifically
      if (data.traffic_analysis?.route) {
        console.log('🗺️ Route data found in traffic_analysis.route:', data.traffic_analysis.route);
      } else {
        console.log('❌ No route data found in traffic_analysis.route');
      }
      
      if (data.error) {
        setError(data.error);
        setRoute(null);
        setInsights('No intelligent insights available');
      } else {
        // Extract route data from intelligent response
        const routeData = data.traffic_analysis?.route || null;
        setRoute(routeData);
        
        // Create comprehensive insights from all agent data
        const comprehensiveInsights = formatIntelligentInsights(data);
        setInsights(comprehensiveInsights);
        setError(null);
      }
    } catch (error) {
      console.error('Intelligent route analysis failed:', error);
      setError('Failed to connect to backend. Please check if the server is running on port 8006.');
      setRoute(null);
      setInsights(null);
    } finally {
      setLoading(false);
    }
  };

  const formatIntelligentInsights = (data) => {
    let insights = "🧠 INTELLIGENT ROUTE ANALYSIS\n\n";
    
    // Primary recommendation
    if (data.intelligent_recommendations?.primary_recommendation) {
      insights += `${data.intelligent_recommendations.primary_recommendation}\n\n`;
    }
    
    // Weather conditions
    if (data.weather_conditions?.origin_weather) {
      const weather = data.weather_conditions.origin_weather;
      insights += `🌤️ WEATHER CONDITIONS:\n`;
      insights += `• Current: ${weather.condition} (${weather.temperature}°C)\n`;
      insights += `• Visibility: ${weather.visibility_km} km\n`;
      insights += `• Traffic Impact: ${weather.traffic_impact}\n\n`;
    }
    
    // Air quality analysis
    if (data.air_quality_analysis?.route_analysis) {
      const airQuality = data.air_quality_analysis.route_analysis;
      insights += `🌬️ AIR QUALITY ANALYSIS:\n`;
      insights += `• Overall Risk Level: ${airQuality.overall_risk_level.toUpperCase()}\n`;
      insights += `• Route Suitable: ${airQuality.route_suitable ? '✅ YES' : '❌ NO'}\n`;
      insights += `• Transport Mode: ${airQuality.transport_mode.toUpperCase()}\n`;
      if (airQuality.health_recommendations?.length > 0) {
        insights += `• Health Recommendations:\n`;
        airQuality.health_recommendations.forEach(rec => {
          insights += `  - ${rec}\n`;
        });
      }
      insights += `\n`;
    }
    
    // Real traffic analysis
    if (data.traffic_analysis?.traffic_analysis) {
      const traffic = data.traffic_analysis.traffic_analysis;
      insights += `🚗 REAL TRAFFIC ANALYSIS:\n`;
      insights += `• Normal time: ${traffic.normal_duration}\n`;
      insights += `• Current time: ${traffic.current_duration}\n`;
      insights += `• Traffic delay: +${traffic.delay_minutes} minutes (${traffic.delay_percentage}% slower)\n`;
      insights += `• Condition: ${traffic.traffic_condition.toUpperCase()}\n`;
      insights += `• Data source: ${traffic.source}\n`;
      insights += `• Updated: ${new Date(traffic.data_timestamp).toLocaleTimeString()}\n\n`;
    }
    
    // Fallback traffic analysis
    if (data.correlation_analysis?.travel_time_factors?.length > 0) {
      insights += `🚗 TRAFFIC FACTORS:\n`;
      data.correlation_analysis.travel_time_factors.forEach(factor => {
        insights += `• ${factor}\n`;
      });
      insights += `\n`;
    }
    
    // Risk factors
    if (data.correlation_analysis?.risk_factors?.length > 0) {
      insights += `⚠️ RISK FACTORS:\n`;
      data.correlation_analysis.risk_factors.forEach(risk => {
        insights += `• ${risk}\n`;
      });
      insights += `\n`;
    }
    
    // Alternative routes
    if (data.intelligent_recommendations?.alternative_options?.length > 0) {
      insights += `🛣️ ALTERNATIVE ROUTES:\n`;
      data.intelligent_recommendations.alternative_options.forEach((alt, index) => {
        insights += `• ${alt.route_name}: ${alt.estimated_time} minutes\n`;
        if (alt.benefits?.length > 0) {
          insights += `  Benefits: ${alt.benefits.join(', ')}\n`;
        }
      });
      insights += `\n`;
    }
    
    // Safety tips
    if (data.intelligent_recommendations?.safety_tips?.length > 0) {
      insights += `🛡️ SAFETY RECOMMENDATIONS:\n`;
      data.intelligent_recommendations.safety_tips.forEach(tip => {
        insights += `• ${tip}\n`;
      });
      insights += `\n`;
    }
    
    // Confidence score
    if (data.confidence_score) {
      insights += `📊 Analysis Confidence: ${Math.round(data.confidence_score * 100)}%\n`;
    }
    
    return insights;
  };

  return (
    <div className="agent-panel">
      <div className="panel-header">
        <h3>🧠 Intelligent Multi-Agent Traffic Management</h3>
        <p className="agent-description">
          Powered by Weather • Traffic • Obstacles • Emergency • Master Intelligence
        </p>
      </div>
      
      {/* Tab Navigation */}
      <div className="tab-navigation">
        <button
          className={`tab-btn ${activeTab === 'route' ? 'active' : ''}`}
          onClick={() => setActiveTab('route')}
        >
          🛣️ Route Analysis
        </button>
        <button
          className={`tab-btn ${activeTab === 'obstacles' ? 'active' : ''}`}
          onClick={() => setActiveTab('obstacles')}
        >
          🚧 Live Obstacles
        </button>
        <button
          className={`tab-btn ${activeTab === 'parking' ? 'active' : ''}`}
          onClick={() => setActiveTab('parking')}
        >
          🅿️ Find Parking
        </button>
        <button
          className={`tab-btn ${activeTab === 'report' ? 'active' : ''}`}
          onClick={() => setActiveTab('report')}
        >
          📤 Report Obstacle
        </button>
      </div>
      
      {/* Tab Content */}
      <div className="tab-content">
        {activeTab === 'route' && (
          <div className="route-analysis-tab">
            <div className="route-input">
              <div className="input-group">
                <input type="text" placeholder="Origin (e.g., Koramangala)" id="origin" />
                <input type="text" placeholder="Destination (e.g., Electronic City)" id="destination" />
              </div>
              
              <div className="transport-mode-selector">
                <label>🚗 Transport Mode:</label>
                <div className="mode-buttons">
                  <button
                    className={`mode-btn ${transportMode === 'car' ? 'active' : ''}`}
                    onClick={() => setTransportMode('car')}
                    type="button"
                  >
                    🚗 Car
                  </button>
                  <button
                    className={`mode-btn ${transportMode === 'bike' ? 'active' : ''}`}
                    onClick={() => setTransportMode('bike')}
                    type="button"
                  >
                    🚴 Bike
                  </button>
                  <button
                    className={`mode-btn ${transportMode === 'walking' ? 'active' : ''}`}
                    onClick={() => setTransportMode('walking')}
                    type="button"
                  >
                    🚶 Walking
                  </button>
                </div>
                {transportMode === 'bike' && (
                  <div className="air-quality-notice">
                    ⚠️ Air quality analysis will be prioritized for bike travel
                  </div>
                )}
                {transportMode === 'walking' && (
                  <div className="air-quality-notice">
                    ⚠️ Air quality and health factors will be prioritized
                  </div>
                )}
              </div>
              
              <button
                onClick={() => analyzeRoute(
                  document.getElementById('origin').value,
                  document.getElementById('destination').value
                )}
                disabled={loading}
                className="analyze-btn"
              >
                {loading ? 'Analyzing...' : 'Analyze Intelligent Route'}
              </button>
            </div>

            {error && (
              <div className="error-box">
                <h4>⚠️ Error:</h4>
                <p>{error}</p>
                <div className="error-details">
                  <small>Backend Status: Check if server is running on http://localhost:8006</small>
                </div>
              </div>
            )}

            {loading && (
              <div className="loading-box">
                <p>🔄 Analyzing route and gathering insights...</p>
                <div className="loading-steps">
                  <small>• Fetching route data...</small><br/>
                  <small>• Processing with AI...</small><br/>
                  <small>• Generating insights...</small>
                </div>
              </div>
            )}

            {insights && !loading && (
              <div className="insights-box">
                <h4>🤖 AI Insights:</h4>
                <p style={{ whiteSpace: 'pre-line' }}>{insights}</p>
              </div>
            )}

            {route && !loading && (
              <div className="route-details">
                <h4>📍 Route Details:</h4>
                <div className="route-info">
                  <p>🛣️ Distance: {route[0]?.legs[0]?.distance?.text || 'N/A'}</p>
                  <p>⏱️ Duration: {route[0]?.legs[0]?.duration?.text || 'N/A'}</p>
                  <p className="note">Note: Duration may vary based on traffic conditions</p>
                </div>
              </div>
            )}

            {(route || (lastQuery.origin && lastQuery.destination)) && !loading && (
              <div className="map-section">
                <h4>🗺️ Route Map:</h4>
                <div className="map-container">
                  <GoogleMapComponent
                    route={route}
                    origin={lastQuery.origin}
                    destination={lastQuery.destination}
                  />
                </div>
                {route && (
                  <div className="route-summary-box">
                    <h5>📊 Route Summary</h5>
                    <div className="summary-grid">
                      <div className="summary-item">
                        <span className="label">Distance:</span>
                        <span className="value">{route[0]?.legs[0]?.distance?.text || 'N/A'}</span>
                      </div>
                      <div className="summary-item">
                        <span className="label">Duration:</span>
                        <span className="value">{route[0]?.legs[0]?.duration?.text || 'N/A'}</span>
                      </div>
                      <div className="summary-item">
                        <span className="label">Status:</span>
                        <span className="value success">✅ Route calculated</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'obstacles' && (
          <div className="obstacles-tab">
            <h4>🚧 Live Traffic Obstacles</h4>
            <p>Real-time view of reported obstacles in Bengaluru</p>
            <div className="map-container" style={{ height: '600px', position: 'relative' }}>
              {window.google ? (
                <ObstacleMap viewMode="live" />
              ) : (
                <div className="loading-message" style={{ textAlign: 'center', padding: '20px' }}>
                  <div className="loading-spinner"></div>
                  <p>Loading Google Maps... Please wait</p>
                  <small>If map doesn't load, please check console for errors</small>
                </div>
              )}
            </div>
          </div>
        )}
        
        {activeTab === 'parking' && (
          <div className="parking-tab">
            <h4>🅿️ Find Parking Near Your Destination</h4>
            <div className="parking-search-section">
              <div className="search-input-group">
                <input
                  type="text"
                  placeholder="Enter destination (e.g., MG Road, Bengaluru)"
                  id="parking-destination"
                  className="parking-destination-input"
                />
                <button
                  onClick={() => searchParkingNearDestination(
                    document.getElementById('parking-destination').value
                  )}
                  disabled={parkingLoading}
                  className="search-parking-btn"
                >
                  {parkingLoading ? '🔍 Searching...' : '🅿️ Find Parking'}
                </button>
              </div>
              
              {parkingLoading && (
                <div className="parking-loading">
                  <div className="loading-spinner"></div>
                  <p>🔍 Searching for parking options...</p>
                </div>
              )}
              
              {parkingOptions && (
                <div className="parking-results">
                  <div className="parking-summary">
                    <h5>📊 Search Results</h5>
                    <p>Found {parkingOptions.total_options} parking options near {parkingOptions.destination}</p>
                    
                    {parkingOptions.insights && parkingOptions.insights.length > 0 && (
                      <div className="parking-insights">
                        <h6>💡 Insights:</h6>
                        {parkingOptions.insights.map((insight, index) => (
                          <div key={index} className="insight-item">{insight}</div>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <div className="parking-categories">
                    {parkingOptions.recommendations.free_options?.length > 0 && (
                      <div className="parking-category">
                        <h6>💰 Free Parking</h6>
                        <div className="parking-list">
                          {parkingOptions.recommendations.free_options.map((parking, index) => (
                            <div key={index} className="parking-item">
                              <div className="parking-header">
                                <span className="parking-name">{parking.name}</span>
                                <span className="parking-distance">{parking.distance_text}</span>
                              </div>
                              <div className="parking-details">
                                <span className="parking-type">{parking.parking_type.description}</span>
                                <span className="walking-time">🚶 {parking.walking_time.text}</span>
                                <span className={`availability ${parking.availability.status.toLowerCase()}`}>
                                  {parking.availability.status} Availability
                                </span>
                              </div>
                              {parking.address && <div className="parking-address">{parking.address}</div>}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {parkingOptions.recommendations.nearby_options?.length > 0 && (
                      <div className="parking-category">
                        <h6>📍 Nearby Options</h6>
                        <div className="parking-list">
                          {parkingOptions.recommendations.nearby_options.map((parking, index) => (
                            <div key={index} className="parking-item">
                              <div className="parking-header">
                                <span className="parking-name">{parking.name}</span>
                                <span className="parking-distance">{parking.distance_text}</span>
                              </div>
                              <div className="parking-details">
                                <span className="parking-cost">{parking.cost_estimate.description}</span>
                                <span className="walking-time">🚶 {parking.walking_time.text}</span>
                                <span className={`availability ${parking.availability.status.toLowerCase()}`}>
                                  {parking.availability.status} Availability
                                </span>
                                {parking.rating > 0 && (
                                  <span className="parking-rating">⭐ {parking.rating.toFixed(1)}</span>
                                )}
                              </div>
                              {parking.address && <div className="parking-address">{parking.address}</div>}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {parkingOptions.recommendations.budget_friendly?.length > 0 && (
                      <div className="parking-category">
                        <h6>💵 Budget Friendly</h6>
                        <div className="parking-list">
                          {parkingOptions.recommendations.budget_friendly.map((parking, index) => (
                            <div key={index} className="parking-item">
                              <div className="parking-header">
                                <span className="parking-name">{parking.name}</span>
                                <span className="parking-distance">{parking.distance_text}</span>
                              </div>
                              <div className="parking-details">
                                <span className="parking-cost">{parking.cost_estimate.description}</span>
                                <span className="walking-time">🚶 {parking.walking_time.text}</span>
                                <span className={`availability ${parking.availability.status.toLowerCase()}`}>
                                  {parking.availability.status} Availability
                                </span>
                                {parking.rating > 0 && (
                                  <span className="parking-rating">⭐ {parking.rating.toFixed(1)}</span>
                                )}
                              </div>
                              {parking.address && <div className="parking-address">{parking.address}</div>}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
        
        {activeTab === 'report' && (
          <div className="report-tab">
            <ObstacleReporting />
          </div>
        )}
      </div>
    </div>
  );
};

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Multi-Agent City Management Dashboard</h1>
      </header>
      <div className="dashboard-container">
        <TrafficAgent />
      </div>
    </div>
  );
}

export default App;

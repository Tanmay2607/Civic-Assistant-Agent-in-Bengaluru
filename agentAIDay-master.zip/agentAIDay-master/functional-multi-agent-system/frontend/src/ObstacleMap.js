import React, { useState, useEffect, useRef } from 'react';
import './ObstacleMap.css';

const debug = (msg, ...args) => console.log(`📍 [Obstacles] ${msg}`, ...args);

const ObstacleMap = ({ viewMode = 'live' }) => {
  const mapRef = useRef(null);
  const [map, setMap] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Initialize map after DOM is ready
  useEffect(() => {
    let mounted = true;
    let initInterval;

    // Wait for 500ms to ensure DOM is ready
    setTimeout(() => {
      if (!mounted) return;

      debug('Starting map initialization...');
      let attempts = 0;
      const maxAttempts = 50;

      const tryInit = () => {
        if (!mounted) return false;
        
        attempts++;
        debug(`Initialization attempt ${attempts}...`);

        // Check container
        const container = mapRef.current;
        if (!container) {
          debug('Map container not ready');
          return false;
        }

        // Check Google Maps
        if (!window.google?.maps) {
          debug('Google Maps not loaded');
          return false;
        }

        try {
          // Create map instance
          const mapInstance = new window.google.maps.Map(container, {
            center: { lat: 12.9716, lng: 77.5946 },
            zoom: 12,
            mapTypeControl: true,
            streetViewControl: false,
            fullscreenControl: true,
            gestureHandling: 'cooperative',
            styles: [{ featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] }]
          });

          // Set bounds
          const bounds = new window.google.maps.LatLngBounds(
            { lat: 12.8, lng: 77.4 },
            { lat: 13.1, lng: 77.8 }
          );
          mapInstance.fitBounds(bounds);

          if (mounted) {
            setMap(mapInstance);
            setLoading(false);
            debug('Map initialized successfully');
          }
          return true;

        } catch (err) {
          debug('Map creation failed:', err);
          if (mounted) {
            setError(err.message);
            setLoading(false);
          }
          return false;
        }
      };

      // Try initialization with interval
      initInterval = setInterval(() => {
        if (attempts >= maxAttempts) {
          clearInterval(initInterval);
          if (mounted) {
            setError('Failed to initialize map after multiple attempts');
            setLoading(false);
          }
          return;
        }

        if (tryInit()) {
          clearInterval(initInterval);
        }
      }, 100);
    }, 500);

    // Cleanup
    return () => {
      mounted = false;
      if (initInterval) {
        clearInterval(initInterval);
      }
    };
  }, []);

  if (loading) {
    return (
      <div className="obstacle-map-loading">
        <div className="loading-spinner" />
        <p>Loading Obstacle Map</p>
        <div className="status">
          {window.google?.maps ? '✓ Maps API Ready' : 'Loading Maps API...'}
        </div>
        <div className="debug-info">
          <small>Container: {mapRef.current ? '✓ Ready' : 'Waiting...'}</small>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="obstacle-map-error">
        <h3>
          <span>❌</span>
          Map Error
        </h3>
        <p>{error}</p>
        <div className="debug-status">
          <div>Maps API: {window.google?.maps ? '✓ Loaded' : '✗ Not Loaded'}</div>
          <div>Container: {mapRef.current ? '✓ Ready' : '✗ Missing'}</div>
        </div>
        <button onClick={() => window.location.reload()} className="retry-btn">
          <span>🔄</span>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="obstacle-map-container">
      <div className="map-wrapper">
        <div 
          ref={mapRef}
          className="obstacle-map"
          style={{
            width: '100%',
            height: '600px',
            visibility: map ? 'visible' : 'hidden'
          }}
        />
      </div>
    </div>
  );
};

export default ObstacleMap;
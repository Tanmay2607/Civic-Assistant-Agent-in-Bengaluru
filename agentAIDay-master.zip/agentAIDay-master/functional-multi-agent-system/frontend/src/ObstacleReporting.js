import React, { useState, useEffect, useRef } from 'react';
import './ObstacleReporting.css';

const ObstacleReporting = () => {
  const [obstacleData, setObstacleData] = useState({
    latitude: '',
    longitude: '',
    obstacle_type: 'pothole',
    description: '',
    reporter_name: '',
    contact_info: '',
    location_name: ''
  });
  
  const [capturedImage, setCapturedImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitResult, setSubmitResult] = useState(null);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [locationError, setLocationError] = useState(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);
  
  const obstacleTypes = [
    { value: 'pothole', label: '🕳️ Pothole', description: 'Road surface hole' },
    { value: 'road_closure', label: '🚧 Road Closure', description: 'Complete road blockage' },
    { value: 'accident', label: '🚗 Accident', description: 'Vehicle collision' },
    { value: 'construction', label: '🏗️ Construction', description: 'Construction work' },
    { value: 'debris', label: '🗑️ Debris', description: 'Objects blocking road' },
    { value: 'flooding', label: '🌊 Flooding', description: 'Water on road' },
    { value: 'broken_signal', label: '🚦 Broken Signal', description: 'Traffic light malfunction' },
    { value: 'fallen_tree', label: '🌳 Fallen Tree', description: 'Tree blocking road' },
    { value: 'vehicle_breakdown', label: '🚙 Breakdown', description: 'Broken down vehicle' }
  ];
  
  useEffect(() => {
    // Get current location on component mount
    getCurrentLocation();
  }, []);
  
  const getCurrentLocation = () => {
    setIsLoadingLocation(true);
    setLocationError(null);
    
    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by this browser');
      setIsLoadingLocation(false);
      return;
    }
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy
        };
        
        setCurrentLocation(location);
        setObstacleData(prev => ({
          ...prev,
          latitude: location.latitude.toFixed(6),
          longitude: location.longitude.toFixed(6)
        }));
        
        setIsLoadingLocation(false);
        console.log('📍 Current location obtained:', location);
      },
      (error) => {
        let errorMessage = 'Failed to get location';
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'Location access denied by user';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Location information unavailable';
            break;
          case error.TIMEOUT:
            errorMessage = 'Location request timed out';
            break;
        }
        
        setLocationError(errorMessage);
        setIsLoadingLocation(false);
        console.error('❌ Geolocation error:', error);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      }
    );
  };
  
  const geocodeLocation = async (locationName) => {
    if (!locationName.trim()) return;
    
    try {
      setIsLoadingLocation(true);
      
      const response = await fetch('http://localhost:8007/api/obstacles/geocode', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ location_name: locationName })
      });
      
      const result = await response.json();
      
      if (result.success) {
        setObstacleData(prev => ({
          ...prev,
          latitude: result.data.latitude.toFixed(6),
          longitude: result.data.longitude.toFixed(6)
        }));
        
        setCurrentLocation({
          latitude: result.data.latitude,
          longitude: result.data.longitude,
          address: result.data.formatted_address
        });
        
        setLocationError(null);
        console.log('📍 Location geocoded:', result.data);
      } else {
        setLocationError(result.message);
      }
    } catch (error) {
      setLocationError('Failed to geocode location');
      console.error('❌ Geocoding error:', error);
    } finally {
      setIsLoadingLocation(false);
    }
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setObstacleData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleLocationNameSubmit = (e) => {
    e.preventDefault();
    geocodeLocation(obstacleData.location_name);
  };
  
  const handleImageCapture = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      alert('Please select a valid image file');
      return;
    }
    
    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('Image size must be less than 5MB');
      return;
    }
    
    const reader = new FileReader();
    
    reader.onload = (event) => {
      const base64String = event.target.result;
      
      // Remove data URL prefix to get just base64
      const base64Data = base64String.split(',')[1];
      
      setCapturedImage(base64Data);
      setImagePreview(base64String);
      
      console.log('📷 Image captured and converted to base64');
    };
    
    reader.readAsDataURL(file);
  };
  
  const clearImage = () => {
    setCapturedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };
  
  const validateForm = () => {
    if (!obstacleData.latitude || !obstacleData.longitude) {
      return 'Location coordinates are required';
    }
    
    if (!obstacleData.description.trim()) {
      return 'Description is required';
    }
    
    if (obstacleData.description.length < 10) {
      return 'Description must be at least 10 characters';
    }
    
    return null;
  };
  
  const submitObstacleReport = async () => {
    const validationError = validateForm();
    if (validationError) {
      setSubmitResult({
        success: false,
        message: validationError
      });
      return;
    }
    
    setIsSubmitting(true);
    setSubmitResult(null);
    
    try {
      const reportData = {
        ...obstacleData,
        latitude: parseFloat(obstacleData.latitude),
        longitude: parseFloat(obstacleData.longitude),
        image_base64: capturedImage,
        user_id: `user_${Date.now()}` // Simple user ID generation
      };
      
      console.log('📤 Submitting obstacle report:', {
        ...reportData,
        image_base64: capturedImage ? '[IMAGE_DATA]' : null
      });
      
      const response = await fetch('http://localhost:8007/api/obstacles/report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(reportData)
      });
      
      const result = await response.json();
      
      setSubmitResult(result);
      
      if (result.success) {
        // Reset form on success
        setObstacleData({
          latitude: '',
          longitude: '',
          obstacle_type: 'pothole',
          description: '',
          reporter_name: '',
          contact_info: '',
          location_name: ''
        });
        clearImage();
        
        console.log('✅ Obstacle report submitted successfully:', result);
      } else {
        console.error('❌ Obstacle report failed:', result);
      }
      
    } catch (error) {
      setSubmitResult({
        success: false,
        message: `Network error: ${error.message}`
      });
      console.error('❌ Submit error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="obstacle-reporting">
      <div className="reporting-header">
        <h2>🚧 Report Traffic Obstacle</h2>
        <p>Help improve traffic conditions by reporting obstacles on the road</p>
      </div>
      
      {/* Location Section */}
      <div className="form-section">
        <h3>📍 Location</h3>
        
        <div className="location-input-group">
          <form onSubmit={handleLocationNameSubmit} className="location-name-form">
            <input
              type="text"
              name="location_name"
              value={obstacleData.location_name}
              onChange={handleInputChange}
              placeholder="Enter location name (e.g., MG Road, Koramangala)"
              className="location-name-input"
            />
            <button 
              type="submit" 
              disabled={isLoadingLocation}
              className="geocode-btn"
            >
              📍 Find
            </button>
          </form>
          
          <div className="location-divider">OR</div>
          
          <button 
            onClick={getCurrentLocation}
            disabled={isLoadingLocation}
            className="current-location-btn"
          >
            {isLoadingLocation ? '⏳ Getting Location...' : '🎯 Use Current Location'}
          </button>
        </div>
        
        <div className="coordinate-inputs">
          <div className="coordinate-group">
            <label>Latitude:</label>
            <input
              type="number"
              name="latitude"
              value={obstacleData.latitude}
              onChange={handleInputChange}
              step="0.000001"
              placeholder="12.9716"
              className="coordinate-input"
            />
          </div>
          
          <div className="coordinate-group">
            <label>Longitude:</label>
            <input
              type="number"
              name="longitude"
              value={obstacleData.longitude}
              onChange={handleInputChange}
              step="0.000001"
              placeholder="77.5946"
              className="coordinate-input"
            />
          </div>
        </div>
        
        {locationError && (
          <div className="error-message">
            ⚠️ {locationError}
          </div>
        )}
        
        {currentLocation && (
          <div className="location-display">
            <strong>📍 Current Location:</strong>
            <div>Lat: {currentLocation.latitude.toFixed(6)}, Lng: {currentLocation.longitude.toFixed(6)}</div>
            {currentLocation.address && <div>{currentLocation.address}</div>}
            {currentLocation.accuracy && <div>Accuracy: ±{currentLocation.accuracy.toFixed(0)}m</div>}
          </div>
        )}
      </div>
      
      {/* Obstacle Details Section */}
      <div className="form-section">
        <h3>🚧 Obstacle Details</h3>
        
        <div className="obstacle-type-grid">
          {obstacleTypes.map(type => (
            <label key={type.value} className="obstacle-type-option">
              <input
                type="radio"
                name="obstacle_type"
                value={type.value}
                checked={obstacleData.obstacle_type === type.value}
                onChange={handleInputChange}
              />
              <div className="obstacle-type-card">
                <div className="obstacle-type-label">{type.label}</div>
                <div className="obstacle-type-description">{type.description}</div>
              </div>
            </label>
          ))}
        </div>
        
        <div className="description-group">
          <label>Description *</label>
          <textarea
            name="description"
            value={obstacleData.description}
            onChange={handleInputChange}
            placeholder="Describe the obstacle in detail (minimum 10 characters)..."
            rows="4"
            className="description-textarea"
          />
          <div className="character-count">
            {obstacleData.description.length}/500 characters
          </div>
        </div>
      </div>
      
      {/* Photo Section */}
      <div className="form-section">
        <h3>📷 Photo (Optional)</h3>
        
        <div className="photo-upload-section">
          {!imagePreview ? (
            <div className="photo-upload-options">
              <div className="upload-option">
                <input
                  type="file"
                  ref={cameraInputRef}
                  accept="image/*"
                  capture="environment"
                  onChange={handleImageCapture}
                  style={{ display: 'none' }}
                />
                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  className="camera-btn"
                >
                  📸 Take Photo
                </button>
              </div>
              
              <div className="upload-divider">OR</div>
              
              <div className="upload-option">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleImageCapture}
                  style={{ display: 'none' }}
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="gallery-btn"
                >
                  🖼️ Choose from Gallery
                </button>
              </div>
            </div>
          ) : (
            <div className="image-preview-section">
              <img src={imagePreview} alt="Obstacle" className="image-preview" />
              <button onClick={clearImage} className="remove-image-btn">
                ❌ Remove Image
              </button>
            </div>
          )}
        </div>
      </div>
      
      {/* Reporter Information Section */}
      <div className="form-section">
        <h3>👤 Reporter Information (Optional)</h3>
        
        <div className="reporter-inputs">
          <div className="input-group">
            <label>Name:</label>
            <input
              type="text"
              name="reporter_name"
              value={obstacleData.reporter_name}
              onChange={handleInputChange}
              placeholder="Your name"
              className="reporter-input"
            />
          </div>
          
          <div className="input-group">
            <label>Contact:</label>
            <input
              type="text"
              name="contact_info"
              value={obstacleData.contact_info}
              onChange={handleInputChange}
              placeholder="Phone or email"
              className="reporter-input"
            />
          </div>
        </div>
      </div>
      
      {/* Submit Section */}
      <div className="submit-section">
        <button
          onClick={submitObstacleReport}
          disabled={isSubmitting}
          className="submit-btn"
        >
          {isSubmitting ? '⏳ Submitting...' : '📤 Report Obstacle'}
        </button>
        
        {submitResult && (
          <div className={`submit-result ${submitResult.success ? 'success' : 'error'}`}>
            <strong>{submitResult.success ? '✅' : '❌'}</strong>
            <span>{submitResult.message}</span>
            
            {submitResult.success && submitResult.data && (
              <div className="success-details">
                <div>Obstacle ID: <code>{submitResult.data.obstacle_id}</code></div>
                <div>Severity: {submitResult.data.severity}/10</div>
                <div>Priority: {submitResult.data.priority}</div>
                {submitResult.data.address && <div>Address: {submitResult.data.address}</div>}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ObstacleReporting;
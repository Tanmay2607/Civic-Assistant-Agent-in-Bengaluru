// Logging utilities
const debug = (msg, ...args) => console.log(`🗺️ [GoogleMaps] ${msg}`, ...args);
const error = (msg, ...args) => console.error(`❌ [GoogleMaps] ${msg}`, ...args);

// Initialize Google Maps
export const initializeGoogleMaps = async (mapRef, onSuccess, onError) => {
  if (!mapRef.current) {
    error('Map container not found');
    onError('Map container not found');
    return null;
  }

  try {
    // Wait for Google Maps to be available
    if (!window.google?.maps) {
      error('Google Maps not loaded');
      onError('Google Maps not loaded');
      return null;
    }

    debug('Creating map instance...');
    const bengaluruCenter = { lat: 12.9716, lng: 77.5946 };
    const mapOptions = {
      center: bengaluruCenter,
      zoom: 12,
      mapTypeControl: true,
      streetViewControl: false,
      fullscreenControl: true,
      gestureHandling: 'cooperative',
      styles: [{ featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] }]
    };

    const map = new window.google.maps.Map(mapRef.current, mapOptions);

    // Set initial bounds for Bengaluru
    const bengaluruBounds = new window.google.maps.LatLngBounds(
      { lat: 12.8, lng: 77.4 },
      { lat: 13.1, lng: 77.8 }
    );
    map.fitBounds(bengaluruBounds);

    debug('Map initialized successfully');
    onSuccess(map);
    return map;

  } catch (err) {
    error('Map initialization failed:', err);
    onError(`Failed to initialize map: ${err.message}`);
    return null;
  }
};

// Check Google Maps availability with timeout
export const waitForGoogleMaps = (timeout = 10000) => {
  return new Promise((resolve, reject) => {
    if (window.google?.maps) {
      resolve(window.google.maps);
      return;
    }

    const startTime = Date.now();
    const checkInterval = setInterval(() => {
      if (window.google?.maps) {
        clearInterval(checkInterval);
        resolve(window.google.maps);
        return;
      }

      if (Date.now() - startTime > timeout) {
        clearInterval(checkInterval);
        reject(new Error('Google Maps failed to load after timeout'));
      }
    }, 100);
  });
};
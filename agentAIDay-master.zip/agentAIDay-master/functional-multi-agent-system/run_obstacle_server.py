"""
Obstacle Management Server Runner
Launches the FastAPI server for Real-Time Obstacle Reporting and Management System
"""

import os
import sys
import subprocess
import time
from pathlib import Path

def setup_environment():
    """Set up environment variables and paths"""
    
    # Set Google Cloud credentials
    service_account_path = "planar-beach-467107-n1-83bdc68ba222.json"
    if os.path.exists(service_account_path):
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = service_account_path
        print(f"✅ Google Cloud credentials set: {service_account_path}")
    else:
        print(f"⚠️ Warning: Service account file not found: {service_account_path}")
    
    # Set Google Cloud project
    os.environ.setdefault('GOOGLE_CLOUD_PROJECT', 'planar-beach-467107-n1')
    
    # Set Google Maps API key
    os.environ.setdefault('GOOGLE_MAPS_API_KEY', 'AIzaSyC-VQzmR1aLxXJsFYtYKZN6yyGr_hIxRic')
    
    # Add backend directory to Python path
    backend_path = Path(__file__).parent / "backend"
    if str(backend_path) not in sys.path:
        sys.path.insert(0, str(backend_path))
    
    print("🌍 Environment variables configured:")
    print(f"   GOOGLE_CLOUD_PROJECT: {os.environ.get('GOOGLE_CLOUD_PROJECT')}")
    print(f"   GOOGLE_MAPS_API_KEY: {os.environ.get('GOOGLE_MAPS_API_KEY')[:20]}...")

def check_dependencies():
    """Check if required dependencies are installed"""
    
    required_packages = [
        'fastapi',
        'uvicorn',
        'google-cloud-bigquery',
        'google-cloud-storage',
        'googlemaps',
        'pillow',
        'pydantic'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
            print(f"✅ {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"❌ {package}")
    
    if missing_packages:
        print(f"\n⚠️ Missing packages: {', '.join(missing_packages)}")
        print("\nYour script is using a Python environment that is missing these packages.")
        print("To fix this, run the following command in your terminal:")
        
        # Construct the precise installation command using the current Python executable
        install_command = f'"{sys.executable}" -m pip install {" ".join(missing_packages)}'
        
        print("\n" + "="*60)
        print(f"  {install_command}")
        print("="*60 + "\n")
        
        print("This ensures the packages are installed in the correct environment.")
        return False
    
    print("✅ All required dependencies are installed")
    return True

def setup_bigquery_table():
    """Set up the BigQuery table for obstacles"""
    
    try:
        print("\n📊 Setting up BigQuery obstacle table...")
        
        # Import and run the setup script
        sys.path.insert(0, str(Path(__file__).parent / "backend"))
        from setup_obstacles_table import create_obstacles_table, create_sample_obstacle_data
        
        # Create table
        if create_obstacles_table():
            print("✅ BigQuery table created successfully")
            
            # Add sample data
            if create_sample_obstacle_data():
                print("✅ Sample obstacle data inserted")
            else:
                print("⚠️ Failed to insert sample data (table might already have data)")
        else:
            print("⚠️ Table creation failed (might already exist)")
            
        return True
        
    except Exception as e:
        print(f"❌ BigQuery setup error: {str(e)}")
        print("💡 Make sure Google Cloud credentials are properly configured")
        return False

def start_obstacle_server():
    """Start the FastAPI obstacle management server"""
    
    try:
        print("\n🚀 Starting Obstacle Management API server...")
        print("📡 Server will be available at: http://localhost:8007")
        print("📖 API docs will be available at: http://localhost:8007/docs")
        print("\n⏳ Starting server... (Press Ctrl+C to stop)")
        
        # Change to backend directory
        backend_dir = Path(__file__).parent / "backend"
        os.chdir(backend_dir)
        
        # Start the server
        subprocess.run([
            sys.executable, "-m", "uvicorn", 
            "obstacle_api:app", 
            "--host", "0.0.0.0", 
            "--port", "8007", 
            "--reload"
        ])
        
    except KeyboardInterrupt:
        print("\n\n🛑 Server stopped by user")
    except Exception as e:
        print(f"\n❌ Server error: {str(e)}")

def main():
    """Main function to set up and run the obstacle management system"""
    
    print("🚧 Real-Time Obstacle Management System")
    print("=" * 50)
    
    # Step 1: Setup environment
    print("\n1️⃣ Setting up environment...")
    setup_environment()
    
    # Step 2: Check dependencies
    print("\n2️⃣ Checking dependencies...")
    if not check_dependencies():
        print("\n❌ Please install missing dependencies before continuing")
        return
    
    # Step 3: Setup BigQuery
    print("\n3️⃣ Setting up BigQuery database...")
    if not setup_bigquery_table():
        print("\n⚠️ BigQuery setup had issues, but continuing...")
    
    # Step 4: Start server
    print("\n4️⃣ Starting API server...")
    time.sleep(2)  # Brief pause
    start_obstacle_server()

if __name__ == "__main__":
    main()
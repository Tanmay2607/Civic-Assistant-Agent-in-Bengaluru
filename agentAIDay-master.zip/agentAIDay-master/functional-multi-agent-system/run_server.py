#!/usr/bin/env python3
"""
Script to run the server with environment variables set
"""
import os
import subprocess
import sys
import signal
import time
from pathlib import Path

class ServerRunner:
    def __init__(self):
        self.process = None
        self.setup_signals()
        
    def setup_signals(self):
        """Set up signal handlers"""
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
    
    def signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        print("\n🛑 Shutting down server...")
        if self.process:
            self.process.terminate()
            self.process.wait()
        sys.exit(0)
    
    def load_env_file(self):
        """Load environment variables from .env file"""
        env_file = Path(__file__).parent / '.env'
        if env_file.exists():
            with open(env_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        os.environ[key.strip()] = value.strip()
            print("✅ Environment variables loaded from .env file")
        else:
            print("⚠️ No .env file found, using default values")
            
    def setup_credentials(self):
        """Setup Google Cloud credentials"""
        credentials_path = Path(__file__).parent.parent / 'planar-beach-467107-n1-83bdc68ba222.json'
        if credentials_path.exists():
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = str(credentials_path)
            print(f"✅ Google Cloud credentials set: {credentials_path.name}")
        else:
            print("⚠️ Google Cloud credentials file not found")

        # Set up environment variables with fallbacks
        os.environ.setdefault('GOOGLE_CLOUD_PROJECT', 'planar-beach-467107-n1')
        os.environ.setdefault('GOOGLE_CLOUD_LOCATION', 'us-central1')
        os.environ.setdefault('GOOGLE_MAPS_API_KEY', 'AIzaSyC-VQzmR1aLxXJsFYtYKZN6yyGr_hIxRic')
    
    def print_config(self):
        """Print current configuration"""
        print("\n📋 Environment Configuration:")
        print(f"   • Project: {os.environ.get('GOOGLE_CLOUD_PROJECT')}")
        print(f"   • Location: {os.environ.get('GOOGLE_CLOUD_LOCATION')}")
        print(f"   • Maps API: {'Set' if os.environ.get('GOOGLE_MAPS_API_KEY') != 'demo_key_for_testing_replace_with_real_key' else 'Demo key (limited functionality)'}")
        print(f"   • Credentials: {'Set' if os.environ.get('GOOGLE_APPLICATION_CREDENTIALS') else 'Not set'}")
        print("")
        print("ℹ️  Note: For full functionality, set a valid GOOGLE_MAPS_API_KEY in .env file")
        print("    Get one from: https://console.cloud.google.com/apis/credentials")
        print("")

    def run(self):
        """Run the server"""
        try:
            # Initialize environment
            self.load_env_file()
            self.setup_credentials()
            
            print("\n🚀 Starting Multi-Agent System Backend Server...")
            print("📍 Server will be available at: http://localhost:8006")
            print("📋 API Documentation: http://localhost:8006/docs")
            print("📊 Agent Status: http://localhost:8006/api/agents/status")
            print("🔗 Route API: http://localhost:8006/api/traffic/route")
            print("🚨 Emergency API: http://localhost:8006/api/emergency/incident")
            print("")
            
            self.print_config()
            
            # Start server process
            self.process = subprocess.Popen([
                sys.executable, '-m', 'uvicorn',
                'backend.main:app',
                '--host', '0.0.0.0',
                '--port', '8006',
                '--reload'
            ], cwd=os.path.dirname(__file__))
            
            print("\n🚀 Server started! Press Ctrl+C to stop.")
            
            # Keep the script running
            while True:
                if self.process.poll() is not None:
                    print("\n⚠️ Server process ended unexpectedly")
                    break
                time.sleep(1)
                
        except KeyboardInterrupt:
            print("\n🛑 Server stopped by user")
            if self.process:
                self.process.terminate()
                self.process.wait()
        except Exception as e:
            print(f"❌ Server failed to start: {e}")
            if self.process:
                self.process.terminate()
                self.process.wait()

def main():
    """Main entry point"""
    runner = ServerRunner()
    runner.run()

if __name__ == "__main__":
    main()
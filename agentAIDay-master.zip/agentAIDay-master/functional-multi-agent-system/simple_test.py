#!/usr/bin/env python3
"""
Simple test script to validate core fixes without requiring valid API keys
"""
import logging
import os
import sys

# Set up environment variables to avoid API key issues
os.environ['GOOGLE_MAPS_API_KEY'] = 'test_key_for_validation'
os.environ['GOOGLE_CLOUD_PROJECT'] = 'test-project'

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_imports():
    """Test that imports work and basic initialization succeeds"""
    logger.info("=== Testing Core Imports and Initialization ===")
    
    try:
        # Test EmergencyResponseAgent (this should work without API keys)
        from agents.emergency_response_agent import EmergencyResponseAgent
        
        emergency_agent = EmergencyResponseAgent()
        logger.info(f"✓ EmergencyResponseAgent initialized: {emergency_agent.name}")
        
        # Test that priority levels work
        test_priority = emergency_agent._priority_levels.get('fire', 0)
        logger.info(f"✓ Priority levels accessible: fire={test_priority}")
        
        return True
        
    except Exception as e:
        logger.error(f"✗ Import/initialization test failed: {e}")
        return False

def test_backend_imports():
    """Test backend imports work"""
    logger.info("=== Testing Backend Imports ===")
    
    try:
        # Add current directory to path
        sys.path.insert(0, os.path.dirname(__file__))
        
        # Test that backend can import (may fail on agent initialization but imports should work)
        try:
            from backend.main import app
            logger.info("✓ Backend FastAPI app imported successfully")
            return True
        except Exception as init_error:
            # If initialization fails due to API keys, that's expected
            if "Invalid API key" in str(init_error):
                logger.info("✓ Backend imports work (API key error expected)")
                return True
            else:
                raise init_error
                
    except Exception as e:
        logger.error(f"✗ Backend imports failed: {e}")
        return False

def main():
    """Run simple tests"""
    logger.info("Starting simple validation tests...")
    
    results = []
    results.append(test_imports())
    results.append(test_backend_imports())
    
    # Summary
    passed = sum(results)
    total = len(results)
    
    logger.info(f"\n=== SIMPLE TEST SUMMARY ===")
    logger.info(f"Tests passed: {passed}/{total}")
    
    if passed == total:
        logger.info("✓ Core fixes are working! The agents can be imported and initialized.")
        logger.info("ℹ Note: Full functionality requires valid Google Cloud API keys.")
        return True
    else:
        logger.error(f"✗ {total - passed} tests failed.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
import uvicorn
import os
import sys

# Add backend directory to path
backend_path = os.path.join(os.path.dirname(__file__), 'backend')
sys.path.append(backend_path)

if __name__ == "__main__":
    print("🚧 Starting Obstacle Management API Server")
    print("📡 Server will be available at: http://localhost:8007")
    print("📖 API docs at: http://localhost:8007/docs")
    print("🧪 Starting with sample data support")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8007,
        reload=True,
        workers=1
    )
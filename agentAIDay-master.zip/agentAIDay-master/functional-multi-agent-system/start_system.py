#!/usr/bin/env python3
"""
Simple startup script that sets environment variables and runs the server
"""
import os
import subprocess
import sys
from pathlib import Path

def main():
    # Set environment variables
    os.environ['GOOGLE_CLOUD_PROJECT'] = 'planar-beach-467107-n1'
    os.environ['GOOGLE_CLOUD_LOCATION'] = 'us-central1'
    os.environ['GOOGLE_MAPS_API_KEY'] = 'AIzaSyDwtWrBw3YAjEo55GY0jxlhZto8vV3XiAA'
    
    # Set credentials path
    credentials_path = Path(__file__).parent.parent / 'planar-beach-467107-n1-83bdc68ba222.json'
    if credentials_path.exists():
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = str(credentials_path)
        print(f"✅ Credentials set: {credentials_path}")
    
    print("🚀 Starting Multi-Agent System...")
    print("📍 Backend will be at: http://localhost:8006")
    print("📍 Frontend will be at: http://localhost:3000")
    print("")
    
    # Start the server
    try:
        subprocess.run([
            sys.executable, '-m', 'uvicorn',
            'backend.main:app',
            '--host', '0.0.0.0',
            '--port', '8006'
        ], cwd=Path(__file__).parent)
    except KeyboardInterrupt:
        print("\n🛑 Server stopped")

if __name__ == "__main__":
    main()
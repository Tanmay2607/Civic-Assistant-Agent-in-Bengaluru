#!/usr/bin/env python3
"""
Test script to validate the fixed agents
"""
import asyncio
import logging
import os
import sys

# Set up basic environment variables for testing
os.environ['GOOGLE_MAPS_API_KEY'] = 'test_key_for_validation'
os.environ['GOOGLE_CLOUD_PROJECT'] = 'test-project'
os.environ['GOOGLE_CLOUD_LOCATION'] = 'us-central1'

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def test_traffic_agent():
    """Test the TrafficManagementAgent"""
    logger.info("=== Testing TrafficManagementAgent ===")
    
    try:
        from agents.traffic_management_agent import TrafficManagementAgent
        
        # Test initialization
        agent = TrafficManagementAgent()
        logger.info("✓ TrafficManagementAgent initialized successfully")
        
        # Test analyze_route method (will fail due to invalid API key, but should not crash)
        result = await agent.analyze_route("New York", "Boston")
        logger.info(f"Route analysis result: {result}")
        
        # Test detect_incident method
        traffic_data = {"congestion_level": 0.9}
        incident_result = await agent.detect_incident(traffic_data)
        logger.info(f"Incident detection result: {incident_result}")
        
        return True
        
    except Exception as e:
        logger.error(f"✗ TrafficManagementAgent test failed: {e}")
        return False

async def test_emergency_agent():
    """Test the EmergencyResponseAgent"""
    logger.info("=== Testing EmergencyResponseAgent ===")
    
    try:
        from agents.emergency_response_agent import EmergencyResponseAgent
        
        # Test initialization
        agent = EmergencyResponseAgent()
        logger.info("✓ EmergencyResponseAgent initialized successfully")
        
        # Test process_emergency method
        result = await agent.process_emergency(
            "fire", 
            "123 Main St", 
            "Building fire reported"
        )
        logger.info(f"Emergency processing result: {result}")
        
        return True
        
    except Exception as e:
        logger.error(f"✗ EmergencyResponseAgent test failed: {e}")
        return False

async def test_backend_server():
    """Test that the backend can import and initialize"""
    logger.info("=== Testing Backend Server ===")
    
    try:
        # Change to the backend directory context
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), '.'))
        
        # Test imports (this will validate our fixes)
        from backend.main import app, traffic_agent, emergency_agent
        logger.info("✓ Backend imports successful")
        
        # Test that agents are initialized
        logger.info(f"Traffic agent name: {traffic_agent.name}")
        logger.info(f"Emergency agent name: {emergency_agent.name}")
        
        return True
        
    except Exception as e:
        logger.error(f"✗ Backend server test failed: {e}")
        return False

async def main():
    """Run all tests"""
    logger.info("Starting agent validation tests...")
    
    results = []
    
    # Test individual agents
    results.append(await test_traffic_agent())
    results.append(await test_emergency_agent())
    results.append(await test_backend_server())
    
    # Summary
    passed = sum(results)
    total = len(results)
    
    logger.info(f"\n=== TEST SUMMARY ===")
    logger.info(f"Tests passed: {passed}/{total}")
    
    if passed == total:
        logger.info("✓ All tests passed! The agents are working correctly.")
        return True
    else:
        logger.error(f"✗ {total - passed} tests failed. Please check the logs above.")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
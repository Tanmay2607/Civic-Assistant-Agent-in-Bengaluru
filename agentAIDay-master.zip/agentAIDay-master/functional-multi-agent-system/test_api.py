#!/usr/bin/env python3
"""
Script to test the running API endpoints
"""
import requests
import json
import time

BASE_URL = "http://localhost:8001"

def test_endpoint(method, endpoint, data=None):
    """Test an API endpoint"""
    url = f"{BASE_URL}{endpoint}"
    try:
        if method.upper() == "GET":
            response = requests.get(url, timeout=10)
        elif method.upper() == "POST":
            response = requests.post(url, json=data, timeout=10)
        
        print(f"✅ {method} {endpoint}: Status {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"   Response: {json.dumps(result, indent=2)[:200]}...")
        else:
            print(f"   Error: {response.text}")
        
        return response.status_code == 200
        
    except requests.exceptions.RequestException as e:
        print(f"❌ {method} {endpoint}: Connection failed - {e}")
        return False

def main():
    """Test all API endpoints"""
    print("🧪 Testing Multi-Agent System API Endpoints")
    print("=" * 50)
    
    # Wait a moment for server to be ready
    time.sleep(2)
    
    # Test endpoints
    tests = [
        ("GET", "/", None),
        ("GET", "/api/agents/status", None),
        ("POST", "/api/traffic/route", {
            "origin": "Koramangala, Bengaluru",
            "destination": "Electronic City, Bengaluru"
        }),
        ("POST", "/api/emergency/incident", {
            "type": "fire",
            "location": "MG Road, Bengaluru, Karnataka",
            "description": "Building fire reported on 3rd floor in commercial complex"
        })
    ]
    
    results = []
    for method, endpoint, data in tests:
        print(f"\n🔍 Testing {method} {endpoint}")
        success = test_endpoint(method, endpoint, data)
        results.append(success)
        time.sleep(1)  # Small delay between requests
    
    # Summary
    passed = sum(results)
    total = len(results)
    
    print(f"\n📊 API Test Summary")
    print("=" * 30)
    print(f"Tests passed: {passed}/{total}")
    
    if passed == total:
        print("🎉 All API endpoints are working!")
    else:
        print(f"⚠️ {total - passed} endpoints had issues")
    
    print(f"\n🌐 Server is running at: {BASE_URL}")
    print(f"📖 API Documentation: {BASE_URL}/docs")

if __name__ == "__main__":
    main()
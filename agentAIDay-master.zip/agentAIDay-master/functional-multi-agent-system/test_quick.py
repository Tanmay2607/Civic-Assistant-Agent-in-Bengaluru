#!/usr/bin/env python3
"""
Quick test script to check if server is running and API structure is valid
"""
import requests
import json
import logging
import time
from time import sleep

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def wait_for_server(port=8005, timeout=30):
    """Wait for server to be ready"""
    base_url = f"http://localhost:{port}"
    start_time = time.time()
    
    while time.time() - start_time < timeout:
        try:
            response = requests.get(base_url)
            if response.status_code == 200:
                logger.info("✓ Server is ready!")
                return True
        except:
            logger.info("Waiting for server to start...")
            sleep(1)
    
    return False

def test_server(port=8005):
    """Test basic server functionality"""
    base_url = f"http://localhost:{port}"
    
    # Wait for server to be ready
    if not wait_for_server(port):
        logger.error("Server failed to start within timeout")
        return False
    
    try:
        # Test root endpoint
        logger.info("Testing root endpoint...")
        response = requests.get(f"{base_url}/")
        assert response.status_code == 200, "Root endpoint should return 200"
        data = response.json()
        assert data["status"] == "healthy", "Server should report healthy status"
        logger.info("✓ Root endpoint working")
        
        # Test agent status
        logger.info("Testing agent status...")
        response = requests.get(f"{base_url}/api/agents/status")
        assert response.status_code == 200, "Status endpoint should return 200"
        data = response.json()
        assert "traffic_agent" in data, "Should include traffic agent status"
        assert "emergency_agent" in data, "Should include emergency agent status"
        logger.info("✓ Agent status working")
        
        # Test traffic route API with Bengaluru locations
        logger.info("Testing traffic route API...")
        route_data = {
            "origin": "Koramangala, Bengaluru",
            "destination": "Electronic City, Bengaluru"
        }
        response = requests.post(f"{base_url}/api/traffic/route", json=route_data)
        assert response.status_code == 200, "Route endpoint should return 200"
        logger.info("✓ Traffic route API working")
        
        return True
        
    except Exception as e:
        logger.error(f"Test failed: {str(e)}")
        return False

if __name__ == "__main__":
    success = test_server()
    if success:
        logger.info("🎉 All basic API tests passed!")
    else:
        logger.error("❌ API tests failed")
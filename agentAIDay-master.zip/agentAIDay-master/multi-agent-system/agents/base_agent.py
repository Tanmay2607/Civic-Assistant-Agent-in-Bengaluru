class BaseAgent:
    def __init__(self, name):
        self.name = name

    async def notify_agent(self, target_agent, message):
        # In a real implementation, this would use Pub/Sub
        print(f"Notifying {target_agent} with message: {message}")
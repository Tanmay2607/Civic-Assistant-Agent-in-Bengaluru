import json
import time
from google.cloud import pubsub_v1
from typing import Dict, Any
import re

class DataIntelligenceAgent:
    """Data Intelligence Layer Agent for smart data routing in city management system"""
    
    def __init__(self, project_id: str):
        """Initialize the Data Intelligence Agent
        
        Args:
            project_id (str): GCP project ID for Pub/Sub
        """
        self.publisher = pubsub_v1.PublisherClient()
        self.project_id = project_id
        
        # Define agent routing map
        self.agent_routes = {
            "traffic": "traffic-agent-topic",
            "emergency": "emergency-agent-topic", 
            "waste": "waste-management-topic",
            "citizen_complaint": "citizen-engagement-topic",
            "environmental": "environmental-monitoring-topic"
        }
        
        # Classification rules
        self.classification_rules = {
            "traffic": [
                r"accident",
                r"traffic",
                r"vehicle",
                r"road",
                r"highway"
            ],
            "emergency": [
                r"emergency",
                r"fire",
                r"medical",
                r"police",
                r"security"
            ],
            "waste": [
                r"waste",
                r"garbage",
                r"trash",
                r"bin",
                r"sanitation"
            ],
            "citizen_complaint": [
                r"complaint",
                r"noise",
                r"request",
                r"service",
                r"issue"
            ],
            "environmental": [
                r"air quality",
                r"temperature",
                r"humidity",
                r"pollution",
                r"weather",
                r"sensor"
            ]
        }
        
        # Decision log for system learning
        self.decision_log = []
    
    def classify_data(self, raw_data: Any) -> Dict:
        """Classify incoming data using rule-based approach
        
        Args:
            raw_data: Unstructured data to classify
            
        Returns:
            Dict containing classification results
        """
        try:
            # Convert data to string for pattern matching
            data_str = json.dumps(raw_data).lower()
            
            # Score each category based on matching patterns
            scores = {}
            for category, patterns in self.classification_rules.items():
                score = 0
                for pattern in patterns:
                    if re.search(pattern.lower(), data_str):
                        score += 1
                scores[category] = score / len(patterns)
            
            # Get category with highest score
            if not scores:
                raise ValueError("No matching patterns found in data")
                
            best_category = max(scores.items(), key=lambda x: x[1])
            
            classification_result = {
                "category": best_category[0],
                "confidence": best_category[1],
                "raw_data": raw_data,
                "timestamp": time.time()
            }
            
            # Log the classification decision
            self.decision_log.append(classification_result)
            
            return classification_result
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Classification failed: {str(e)}",
                "raw_data": raw_data,
                "timestamp": time.time()
            }
    
    def handle_uncertain_classification(self, classified_data: Dict) -> Dict:
        """Handle data with low classification confidence
        
        Args:
            classified_data: Data with classification results
            
        Returns:
            Dict containing handling results
        """
        print(f"Low confidence classification detected: {classified_data}")
        return {
            "status": "pending_review",
            "message": "Marked for human review due to low confidence",
            "data": classified_data
        }
    
    def route_to_agent(self, classified_data: Dict) -> Dict:
        """Route classified data to appropriate agent
        
        Args:
            classified_data: Data with classification results
            
        Returns:
            Dict containing routing results
        """
        category = classified_data["category"]
        confidence = classified_data["confidence"]
        
        # Only route if confidence is above threshold
        if confidence < 0.4:  # Lower threshold for rule-based approach
            return self.handle_uncertain_classification(classified_data)
        
        # Get target topic for the category
        target_topic = self.agent_routes.get(category)
        if not target_topic:
            return {
                "status": "error", 
                "message": f"No route found for category: {category}"
            }
            
        print(f"Would route to {category} agent via topic: {target_topic}")
        return {
            "status": "routed",
            "message": f"Successfully routed to {category} agent",
            "target_topic": target_topic
        }
from fastapi import FastAPI
from ..base_agent import BaseAgent

app = FastAPI()
agent = BaseAgent(name="emergency_response_agent")

@app.post("/invoke")
async def invoke(data: dict):
    # In a real implementation, this would be more sophisticated
    return await agent.notify_agent("traffic_management_agent", data)
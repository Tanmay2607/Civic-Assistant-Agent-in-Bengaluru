from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import httpx

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

AGENT_URLS = {
    "traffic_management_agent": "http://localhost:8001",
    "emergency_response_agent": "http://localhost:8002",
    "environmental_monitoring_agent": "http://localhost:8003",
}

@app.post("/invoke/{agent_name}")
async def invoke_agent(agent_name: str, data: dict):
    agent_url = AGENT_URLS.get(agent_name)
    if not agent_url:
        return {"error": "Agent not found"}
    
    async with httpx.AsyncClient() as client:
        response = await client.post(f"{agent_url}/invoke", json=data)
        return response.json()
import json
from agents.data_intelligence_agent import DataIntelligenceAgent
import functions_framework
import os

project_id = os.getenv('GOOGLE_CLOUD_PROJECT')
agent = DataIntelligenceAgent(project_id=project_id)

@functions_framework.http
def process_data(request):
    """HTTP Cloud Function for processing incoming city data.
    
    Args:
        request (flask.Request): The request object
        
    Returns:
        The response text, or any set of values that can be turned into a
        Response object using `make_response`
    """
    # Set CORS headers for the preflight request
    if request.method == 'OPTIONS':
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Max-Age': '3600'
        }
        return ('', 204, headers)

    # Set CORS headers for the main request
    headers = {
        'Access-Control-Allow-Origin': '*'
    }
    
    try:
        request_json = request.get_json(silent=True)
        
        if not request_json or 'data' not in request_json:
            return (json.dumps({
                'error': 'No data provided'
            }), 400, headers)
            
        # Process the data through our agent
        result = agent.classify_data(request_json['data'])
        
        if result.get('category'):
            # Route to appropriate agent
            routing_result = agent.route_to_agent(result)
            return (json.dumps(routing_result), 200, headers)
        
        return (json.dumps(result), 200, headers)
        
    except Exception as e:
        return (json.dumps({
            'error': str(e)
        }), 500, headers)
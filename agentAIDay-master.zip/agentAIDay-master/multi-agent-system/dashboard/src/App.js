import React, { useState } from 'react';
import './App.css';

function App() {
  const [agentStatus, setAgentStatus] = useState({
    traffic_management_agent: 'idle',
    emergency_response_agent: 'idle',
    environmental_monitoring_agent: 'idle',
  });

  const [communicationLogs, setCommunicationLogs] = useState([]);

  const invokeAgent = async (agentName, data) => {
    setAgentStatus({ ...agentStatus, [agentName]: 'running' });
    const response = await fetch(`http://localhost:8000/invoke/${agentName}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    const result = await response.json();
    setCommunicationLogs([...communicationLogs, { agentName, result }]);
    setAgentStatus({ ...agentStatus, [agentName]: 'idle' });
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Multi-Agent City Management Dashboard</h1>
      </header>
      <div className="dashboard-container">
        <div className="agent-tabs">
          <div className="agent-tab">
            <h2>Traffic Management Agent</h2>
            <p>Status: {agentStatus.traffic_management_agent}</p>
            <button onClick={() => invokeAgent('traffic_management_agent', { id: 1, severity: 8 })}>
              Simulate High Severity Incident
            </button>
          </div>
          <div className="agent-tab">
            <h2>Emergency Response Agent</h2>
            <p>Status: {agentStatus.emergency_response_agent}</p>
            <button onClick={() => invokeAgent('emergency_response_agent', { id: 1 })}>
              Simulate Incident
            </button>
          </div>
          <div className="agent-tab">
            <h2>Environmental Monitoring Agent</h2>
            <p>Status: {agentStatus.environmental_monitoring_agent}</p>
            <button onClick={() => invokeAgent('environmental_monitoring_agent', { id: 1 })}>
              Simulate Data
            </button>
          </div>
        </div>
        <div className="communication-logs">
          <h2>Communication Logs</h2>
          <ul>
            {communicationLogs.map((log, index) => (
              <li key={index}>
                <strong>{log.agentName}:</strong> {JSON.stringify(log.result)}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default App;

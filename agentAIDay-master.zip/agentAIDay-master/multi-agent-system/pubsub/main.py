from google.cloud import pubsub_v1

def create_topic(project_id, topic_id):
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)
    topic = publisher.create_topic(request={"name": topic_path})
    print(f"Topic created: {topic.name}")

def create_subscription(project_id, topic_id, subscription_id):
    publisher = pubsub_v1.PublisherClient()
    subscriber = pubsub_v1.SubscriberClient()
    topic_path = publisher.topic_path(project_id, topic_id)
    subscription_path = subscriber.subscription_path(project_id, subscription_id)
    with subscriber:
        subscription = subscriber.create_subscription(
            request={"name": subscription_path, "topic": topic_path}
        )
    print(f"Subscription created: {subscription.name}")

if __name__ == "__main__":
    project_id = "your-gcp-project-id"
    topics = [
        "traffic_management_agent_topic",
        "emergency_response_agent_topic",
        "environmental_monitoring_agent_topic",
    ]
    for topic_id in topics:
        create_topic(project_id, topic_id)
        create_subscription(project_id, topic_id, f"{topic_id}_subscription")
import json
import os
from dotenv import load_dotenv
from agents.data_intelligence_agent import DataIntelligenceAgent

def test_classification():
    """Test the data classification functionality"""
    # Load environment variables from .env file
    load_dotenv()
    
    # Get project configuration
    project_id = os.getenv("GOOGLE_CLOUD_PROJECT")
    
    if not project_id:
        raise ValueError(
            "Project ID not found. Please check .env file has GOOGLE_CLOUD_PROJECT set"
        )
    
    print(f"Using project ID: {project_id}")
    agent = DataIntelligenceAgent(project_id=project_id)
    
    # Test cases with different types of data
    test_cases = [
        {
            "description": "Traffic incident data",
            "data": {
                "location": "Main St & 5th Ave",
                "type": "accident",
                "vehicles_involved": 2,
                "timestamp": "2025-07-27T10:30:00Z"
            }
        },
        {
            "description": "Environmental sensor data",
            "data": {
                "sensor_id": "AQ001",
                "pm25": 35.2,
                "temperature": 24.5,
                "humidity": 65,
                "timestamp": "2025-07-27T10:30:00Z"
            }
        },
        {
            "description": "Citizen complaint",
            "data": {
                "complaint_id": "C12345",
                "category": "noise",
                "description": "Loud construction work during quiet hours",
                "location": "123 Oak Street",
                "timestamp": "2025-07-27T10:30:00Z"
            }
        },
        {
            "description": "Emergency situation",
            "data": {
                "emergency_id": "E789",
                "type": "fire",
                "severity": "high",
                "location": "456 Pine Ave",
                "timestamp": "2025-07-27T10:30:00Z"
            }
        },
        {
            "description": "Waste management",
            "data": {
                "bin_id": "B456",
                "status": "full",
                "waste_type": "garbage",
                "location": "789 Elm St",
                "timestamp": "2025-07-27T10:30:00Z"
            }
        }
    ]
    
    print("\nStarting classification tests...")
    
    for test_case in test_cases:
        print(f"\nTesting: {test_case['description']}")
        print(f"Input data: {json.dumps(test_case['data'], indent=2)}")
        
        # Test classification
        result = agent.classify_data(test_case['data'])
        
        print(f"Classification result:")
        print(json.dumps(result, indent=2))
        
        if result.get('status') == 'error':
            print(f"Error: {result.get('message')}")
            continue
            
        # Test routing
        if result.get('category'):
            routing_result = agent.route_to_agent(result)
            print(f"Routing result:")
            print(json.dumps(routing_result, indent=2))

def main():
    try:
        test_classification()
        print("\nAll tests completed successfully.")
    except Exception as e:
        print(f"\nTest failed with error: {str(e)}")
        print("\nTo run the tests, please ensure .env file contains:")
        print("1. GOOGLE_CLOUD_PROJECT=your-project-id")
        print("2. GOOGLE_APPLICATION_CREDENTIALS=path/to/service-account-key.json")

if __name__ == "__main__":
    main()